﻿using System.Data;

namespace Voxai.UnifiedPortal.DataAccess
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection();
    }

}
