﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Voxai.UnifiedPortal.Domain.Models
{
    [AttributeUsage(AttributeTargets.Class)]
    public class TableInfoAttribute : Attribute
    {
        public string Schema { get; }
        public string TableName { get; }

        public TableInfoAttribute(string schema, string tableName)
        {
            Schema = schema;
            TableName = tableName;
        }
    }

}
