﻿using Voxai.UnifiedPortal.Domain.Models;

namespace Voxai.UnifiedPortal
{
    /// <summary>
    /// A Company is the top level entity of an organization.
    /// </summary>
    /// 
    [TableInfo("adm", "company")]
    /// <summary>
    /// A Company is the top level entity of an organization.
    /// </summary>
    public class Company : TTCompany
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string CompanyDescription { get; set; }
        public string CompanyCreatedBy { get; set; }
        public DateTime CompanyCreatedDate { get; set; }
        public string CompanyUpdatedBy { get; set; }
        public DateTime CompanyUpdatedDate { get; set; }
        public int BuId { get; set; }
        public string BuName { get; set; }
        public string BuDescription { get; set; }
        public string BUDomain { get; set; }
        public string BuCreatedBy { get; set; }
        public DateTime BuCreatedDate { get; set; }
        public string BuUpdatedBy { get; set; }
        public DateTime BuUpdatedDate { get; set; }
    }

    public class TTCompany :AuditItem
    {
        public int Id { get; set; }//meaning no ID assigned
        public string CID { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string Description { get; set; }
        public string Domain { get; set; }
        public int? TenantId { get; set; }
        public string? OrgId { get; set; }
        public bool? IsDeleted { get; set; }
        public int? IntegrationType { get; set; }
    }


}
