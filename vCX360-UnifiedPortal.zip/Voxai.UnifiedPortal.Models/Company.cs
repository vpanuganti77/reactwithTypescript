﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Voxai.UnifiedPortal.Services.Models
{
    /// <summary>
    /// A Company is the top level entity of an organization.
    /// </summary>
    public class CompanyRequest : AuditNamedItem
    {
        public CompanyRequest()
        {

        }
        /// <summary>
        /// Extended Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="cid"></param>
        /// <param name="status"></param>
        /// <param name="desc"></param>
        /// <param name="domain"></param>
        /// <param name="units"></param>
        public CompanyRequest(int id, string name, string cid, string domain, string status, string desc = null) : base(id, name, desc)
        {
            Id = id;
            Cid = cid;
            Status = status;
            //BusinessUnits = units;
            Domain = domain;
        }

        /// <summary>
        /// Unique identifier for the Company
        /// </summary>
        public string Cid { get; set; }

        /// <summary>
        /// Unique Domain for the Company
        /// </summary>
        public string Domain { get; set; }
        /// <summary>
        /// (TBD) Custom status
        /// </summary>
        public string Status { get; set; }

        ///// <summary>
        /////Used for Genesys InstallWizard Default is True
        ///// </summary>
        //public bool IsProvisionNewBU { get; set; } = true;
        public bool? IsDeleted { get; set; } = false;

        /// <summary>
        /// (TBD) Custom status
        /// </summary>
        public int? TenantId { get; set; }


        /// <summary>
        /// (TBD) Custom status
        /// </summary>
        public string? OrgId { get; set; }

        /// <summary>
        /// (TBD) Custom status
        /// </summary>
        public int? IntegrationType { get; set; }

    }
}
