﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Voxai.UnifiedPortal.Services.Models
{
    /// <summary>
    /// Represents an entity with audit information.
    /// </summary>
    /// <remarks>
    /// Added to simplify adding audit information to entities, and to make sure the same properties are used across all entities.
    /// </remarks>
    public abstract class AuditNamedItem
    {

        /// <summary>
        /// The default constructor for NamedItem
        /// </summary>
        protected AuditNamedItem() { }
        /// <summary>
        /// Simple constructor for assigning Id, Name, and Desc Properties
        /// </summary>
        /// <param name="id">The Item Id, Required</param>
        /// <param name="name">The Item Name, Required</param>
        /// <param name="desc">The Item Description, Optional</param>
        protected AuditNamedItem(int id, string name, string desc = null)
        {
            Id = id;
            Name = name;
            Desc = desc;
        }

        public int Id { get; set; } = -1;//meaning no ID assigned

        /// <summary>
        /// The Name of the Item.
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// An optional description for the Item.
        /// </summary>
        public string Desc { get; set; }
        ///<summary>
        /// The user who created this entity.
        /// </summary>
        public string CreatedBy { get; set; }

        ///<summary>
        /// The date and time this entity was created.
        /// </summary>
        public DateTime CreatedDate { get; set; }

        ///<summary>
        /// The user who last modified this entity.
        /// </summary>
        public string ModifiedBy { get; set; }

        ///<summary>
        /// The date and time this entity was last modified.
        /// </summary>
        public DateTime? ModifiedDate { get; set; }
    }
}
