﻿CREATE TABLE [sec].[Feature]
(
	[Id]			INT         NOT NULL, --no sequence. fixed and unique.
	[CID]			VARCHAR(30) NOT NULL,
	[Name]			VARCHAR(50) NOT NULL, 
	[Enabled]		BIT			NOT NULL DEFAULT (1),
    [IsLicensable]	BIT			NOT NULL DEFAULT (1), 

    CONSTRAINT [PK_ProdFeature] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_Feature_CID] UNIQUE ([CID])
)

GO

CREATE INDEX [IX_Feature_CID] ON [sec].[Feature] ([CID])

GO

CREATE INDEX [IX_Feature_IsLicensable] ON [sec].[Feature] ([IsLicensable])
GO
