﻿--This table will be populated/updated by a script whenever a license file is updated/uploaded for a given BU
--Manually changing this (to add licensed features to a BU) will preclude any user from logging in to the portal, 
--as the data contained in this table will be validated every time a user logs in, by decrypting the actual 
--license file provided for a given BU (and stored in the License table)
CREATE TABLE [sec].[LicensedAppFeature]
(
	[ApplicationId]		INT NULL,
	[CompanyId]			INT NULL, --AS [adm].[GetCompanyIdForBUId](BusinessUnitId), --computed
	[BusinessUnitId]	INT NULL, --we do not license at the company level, only at BU level, so this can never be null
	[FeatureId]			INT NOT NULL,
	

	--CONSTRAINT [PK_LicensedFeature] PRIMARY KEY CLUSTERED ([BusinessUnitId],[FeatureId]),
	CONSTRAINT [FK_LicensedAppFeature_Application] FOREIGN KEY ([ApplicationId]) REFERENCES [adm].[Application]([Id]) ON DELETE CASCADE,
	
	CONSTRAINT [FK_LicensedAppFeature_Feature] FOREIGN KEY ([FeatureId]) REFERENCES [sec].[Feature]([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_LicensedAppFeature_BusinessUnit] FOREIGN KEY ([BusinessUnitId]) REFERENCES [adm].[BusinessUnit]([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_LicensedAppFeature_Company] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]) 
	
)
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_LicenseFeature ON [sec].[LicensedAppFeature]([ApplicationId], [FeatureId],CompanyId, BusinessUnitId)
GO

CREATE INDEX [IX_LicensedFeature_BusinessUnitId] ON [sec].[LicensedAppFeature] ([BusinessUnitId])

GO

CREATE INDEX [IX_LicensedFeature_FeatureId] ON [sec].[LicensedAppFeature] ([FeatureId])
