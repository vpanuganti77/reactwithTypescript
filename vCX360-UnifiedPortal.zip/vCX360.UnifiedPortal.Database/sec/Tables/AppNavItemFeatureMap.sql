﻿CREATE TABLE [sec].[AppNavItemFeatureMap]
(
	[ApplicationId] INT NOT NULL,
	[NavItemId]		INT NOT NULL,
	[FeatureId]		INT NOT NULL,

	CONSTRAINT [PK_NavItemFeatureMap] PRIMARY KEY CLUSTERED ([NavItemId], [FeatureId]),
	CONSTRAINT [FK_NavItemFeatureMap_NavItem] FOREIGN KEY ([NavItemId]) REFERENCES [sec].[NavItem]([Id]),
	CONSTRAINT [FK_NavItemFeatureMap_Feature] FOREIGN KEY ([FeatureId]) REFERENCES [sec].[Feature]([Id]),
	CONSTRAINT [FK_NavItemFeatureMap_ApplicationId] FOREIGN KEY ([ApplicationId]) REFERENCES [adm].[Application]([Id])

)

GO

CREATE INDEX [IX_NavItemFeatureMap_NavItemId] ON [sec].[AppNavItemFeatureMap] ([NavItemId])

GO

CREATE INDEX [IX_NavItemFeatureMap_FeatureId] ON [sec].[AppNavItemFeatureMap] ([FeatureId])


GO

CREATE INDEX [IX_NavItemFeatureMap_ApplicationId] ON [sec].[AppNavItemFeatureMap] ([ApplicationId])