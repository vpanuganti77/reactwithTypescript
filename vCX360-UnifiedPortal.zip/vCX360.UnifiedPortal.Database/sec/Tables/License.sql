﻿CREATE TABLE [sec].[License]
(
	[Id]				INT			 NOT NULL DEFAULT next value for [sec].[LicenseIdSeq],
	ApplicationId		Int,
	[Component]			VARCHAR(100) NOT NULL DEFAULT 'Portal',
	[CompanyId]			INT			 NULL,  --null for "global" licensable items, or for vConnector or other apps
	[BusinessUnitId]	INT			 NULL, --null for global, or for all BUs of a given company
	[Content]			VARCHAR(2000),
	[IsDeleted]			BIT				DEFAULT 0,
	--[IsActive] BIT NOT NULL DEFAULT (1), --only one per BU can be active at a given time
	[CreatedDate] DATETIME2(0) NOT NULL DEFAULT (getdate()),
	[UpdatedDate] DATETIME2(0),

	CONSTRAINT [PK_License] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [FK_License_Company] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]),
	CONSTRAINT [FK_License_BusinessUnit] FOREIGN KEY ([BusinessUnitId]) REFERENCES [adm].[BusinessUnit] ([Id]) on delete cascade
)
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_License_Active
ON [sec].[License](Component,CompanyId, BusinessUnitId)
--where IsActive=1 --will enforce that only one license for a given BU is active at any given time
GO


CREATE INDEX [IX_License_CompanyId] ON [sec].[License] ([CompanyId])

GO

CREATE INDEX [IX_License_BusinessUnitId] ON [sec].[License] ([BusinessUnitId])
