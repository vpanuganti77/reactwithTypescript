﻿CREATE TABLE [sec].[NavItem]
(
	[Id]			INT			   NOT NULL, --no sequence; fixed IDs
	[ParentId]		INT			   NULL, --NULL for top level items (self-referencing to help re-build the hierarchy)
	[DisplayName]	VARCHAR(100)   NOT NULL,	
	[NavLink]		VARCHAR(100)   NULL,
	[Description]	NVARCHAR(2000) NULL,
	[Tooltip]		VARCHAR(200)   NULL,
	[Order]			TINYINT		   NOT NULL DEFAULT 0,
	[Group]			TINYINT        NOT NULL DEFAULT 0,
	[Enabled]		BIT            NOT NULL DEFAULT 1,

	CONSTRAINT [PK_NavFeature] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [FK_NavFeature_NavFeature] FOREIGN KEY ([ParentId]) REFERENCES [sec].[NavItem]([Id])
)
