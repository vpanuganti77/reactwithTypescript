﻿CREATE TABLE [dbo].[FeatureRole]
(
	[RoleId]	INT NOT NULL,
	[FeatureId] INT NOT NULL,

	CONSTRAINT [PK_FeatureRole] PRIMARY KEY CLUSTERED ([RoleId] ASC, [FeatureId] ASC),
	CONSTRAINT [FK_FeatureRole_Role] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role] ([id]) ON DELETE CASCADE,
	CONSTRAINT [FK_FeatureRole_Feature] FOREIGN KEY ([FeatureId]) REFERENCES [sec].[Feature] ([id]) ON DELETE CASCADE
);
