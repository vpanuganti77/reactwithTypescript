﻿CREATE FUNCTION [sec].[GetAllFeaturesForLoggedInUser]
(
	@userName nvarchar(50)
)
RETURNS TABLE AS RETURN
(
	
SELECT NI.Id As NavItemId, NI.DisplayName As NavItemDisplayName, NI.Description As NavItemDescription, NI.Enabled As IsEnabled, 1 As BusinessUnitId, cast(F.Id as varchar(10)) + ':' + F.CID + ':' + 'False' As FeatureIds
FROM [sec].NavItem NI JOIN [sec].AppNavItemFeatureMap NIFM  ON NIFM.NavItemId = NI.Id JOIN [sec].Feature F ON F.Id = NIFM.FeatureId
); 
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttNavItemWithStatusAndBUIds]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetAllFeaturesForLoggedInUser',
    @level2type = NULL,
    @level2name = NULL
