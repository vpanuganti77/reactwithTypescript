﻿CREATE FUNCTION [sec].[GetLicenseUsageDetailForCD]
(
	@cobuCids ttString READONLY, --CSV CoCid,BuCid strings
	@includeLicense bit = 0
	--this is intended to support a variety of calls:
	--with empty input table or just (',') -> all license usages and user counts, including SysAdmins and all EAs, will be retrieved
	--with input like (',BuCid') -> license usage for that BU and the parent CO (for EA count) will be retrieved
	--with input like ('CoCid,BuCid') -> license usage for that BU +  parent CO (for EA count) will be retrieved
	--with input like ('CoCid,') -> license usage for all BUs of that company, including user count for EAs will be retrieved
	--the result always includes user count for SysAdmins (with NULL CoCid and BuCid)
)
RETURNS TABLE AS RETURN
(

	WITH cobuCidsCte0 as
	(
		select 			
			SUBSTRING(strval, 0, CHARINDEX(',', strval)) as CoCid,
			SUBSTRING(strval, CHARINDEX(',', strval)+1, 100) as BuCid
		from @cobuCids
	) -- select * from cobuCidsCte0
	, cobuCidsCte as
	(
		select '' as CoCid, '' as BuCid , 1 as IsEmpty
			where (not exists (select 1 from @cobuCids) or (select top 1 isnull(CoCid,'') from cobuCidsCte0) = '')
        union all
        select CID as CoCid, null as BuCid, 1 as IsEmpty from [adm].Company where 
			(not exists (select 1 from @cobuCids) or (select top 1 isnull(CoCid,'') from cobuCidsCte0) = '')
        union all
        select CoCid, BuCid, 0 as IsEmpty from cobuCidsCte0
        union all
        select CoCid, null as BuCid, 0 as IsEmpty from cobuCidsCte0
        union all
        select null as CoCid, null as BuCid, 0 as IsEmpty
	) -- select * from cobuCidsCte
	, cobuIdsCte as
	(
		select
			distinct co.CID as CoCid, co.Id as CompanyId, bu.CID as BuCid, bu.Id as BusinessUnitId
		from cobuCidsCte cb
		left join [adm].Company co on co.CID = cb.CoCid or (cb.CoCid = '')
		left join [adm].BusinessUnit bu on (bu.CID = cb.BuCid and co.Id = bu.CompanyId)  or (cb.BuCid = '' and co.Id = bu.CompanyId)
	) -- select * from cobuIdsCte order by companyId, BusinessUnitId

	, permissionRole as --helper view to associate (basic) ROLE NAME with Permission ID (instead of permission name)
	(
		select pr.PermissionId, r.[Name]
		from [dbo].RolePermission pr
		join [dbo].[Role] r on r.Id = pr.RoleId
		where r.RoleType = 0
	) -- SELECT * FROM permissionRole

	, userCte as --users and roles, possibly no users at all for a given company or BU (that was just created)
	(
		select
			c.CoCid, c.BuCid,
			cr.CompanyId, cr.BusinessUnitId, 
			ur.UserId, coalesce(max(rp.PermissionId), 15) as PermissionId ----for SysAdmin, permissionid is null (b/c it has no entry in CustomRole)
		from [dbo].CustomRole cr
		join [dbo].RolePermission rp on rp.RoleId = cr.RoleId
		right join [dbo].[Role] r on r.Id = cr.RoleId 
		left join [dbo].UserRole ur on ur.RoleId = r.Id
		join cobuIdsCte c on 
			(c.BusinessUnitId = cr.BusinessUnitId) or
			(c.CompanyId = cr.CompanyId and c.BusinessUnitId is null and cr.BusinessUnitId is null) or
			(c.CompanyId is null and cr.CompanyId is null)
		where r.RoleType > 0 
		-- and ur.UserId IS NOT NULL
		group by c.CoCid, c.BuCid, cr.companyid, cr.BusinessUnitId, ur.UserId
	)  -- select * from userCte;

	, userCountsCteT1 as -- users and roles, possibly no users at all for a given company or BU (that was just created)
	(
		select CoCid, BuCid, CompanyId, BusinessUnitId, PermissionId, count(UserId) as UserCnt  ----for SysAdmin, permissionid is null (b/c it has no entry in CustomRole)
		from userCte
		group by CoCid, BuCid, companyid, BusinessUnitId, PermissionId
	)  -- select * from userCountsCteT1;

	, userCountsCte as 
	(
		SELECT UCTET1.CoCid, UCTET1.BuCid, UCTET1.CompanyId, UCTET1.BusinessUnitId, -- P.Id As PermissionId, P.Name as Permission, U.UserCnt,
		CASE 
			WHEN (UCTET1.PermissionId = P.Id OR UCTET1.PermissionId = PR.PermissionId) THEN UCTET1.UserCnt ELSE 0
		END Cnt,
		CASE
			WHEN P.Id=1 THEN 'Viewer'
			WHEN P.Id=7 THEN 'Editor'
			WHEN P.Id=15 THEN 'Administrator'
			ELSE 'Invalid'
		END RoleName
		FROM userCountsCteT1 UCTET1
		LEFT JOIN [adm].[BusinessUnit] B ON  UCTET1.BusinessUnitId = B.Id 
		LEFT JOIN [adm].[Company] C ON UCTET1.CompanyId = C.Id
		LEFT JOIN [dbo].[Permission] P ON P.Id = UCTET1.PermissionId
		LEFT JOIN permissionRole PR on PR.PermissionId = UCTET1.PermissionId
		-- GROUP BY C.CID, B.CID, B.CompanyId, B.Id, cnt, RoleName
		-- Order by B.Id,P.Id, cnt DESC OFFSET 0 ROWS
	) -- select * from userCountsCte;

	--, userPermuissionsByBU as 
	--(
	--	SELECT UR.UserId, CR.CompanyId, CR.BusinessUnitId, -- CR.FeatureId, 
	--		   -- UR.RoleId, 
	--	       -- R.Name as RoleName, R.RoleType,  
	--		   MAX(P.Id) MaxPermissionId, 
	--		   CR.IsValid, CR.IsEnterpriseAdmin 
	--	FROM [adm].[UserRole] UR 
	--	JOIN [adm].[Role] R ON UR.RoleId = R.Id
	--	LEFT JOIN [adm].[CustomRole] CR ON R.Id = CR.RoleId
	--	JOIN [adm].[RolePermission] RP ON RP.RoleId=R.Id
	--	JOIN [adm].[Permission] P ON P.Id=RP.PermissionId
	--	WHERE R.RoleType IN (1, 4) AND (CR.FeatureId != 1 OR CR.FeatureId IS NULL)
	--	GROUP BY CR.CompanyId, CR.BusinessUnitId, UR.UserId, CR.IsValid, CR.IsEnterpriseAdmin 
	--) -- SELECT * FROM userPermuissionsByBU
	
	--, userCntsByBU as
	--(
	--	SELECT CompanyId, BusinessUnitId, MaxPermissionId, Count(UserId) UserCnt
	--	FROM userPermuissionsByBU
	--	GROUP BY CompanyId, BusinessUnitId, MaxPermissionId
	--) -- SELECT * FROM userCntsByBU
	
	-- SELECT B.CompanyId, C.CID as CompanyCid, B.Id BusinessUnitId, B.CID as BusinessUnitCid, P.*, U.*,

	-- , userCountsCte as
	-- (
	-- 	select
	-- 		c.CoCid, c.BuCid,
	-- 		c.CompanyId, c.BusinessUnitId, 
	-- 		count(distinct c.UserId) as cnt, 
	-- 		p.[Name] as RoleName 
	-- 	from userCte c
	-- 	join permissionRole p on p.PermissionId = c.PermissionId	
	-- 	group by c.CoCid, c.BuCid, c.companyid, c.BusinessUnitId, p.[Name]
	-- ) --select * from userCountsCte

	, usersAndFeaturesCte as 
	(
		select distinct u.*, l.Content,
		stuff((
						select ',' + IIF(lf.FeatureId = 0, null, f.[Cid]) 
						from userCountsCte u1
						left join [sec].LicensedAppFeature lf on lf.BusinessUnitId = u.BusinessUnitId
						left join [sec].Feature f on f.id = lf.FeatureId
						where u1.companyid = u.companyid and u1.BusinessUnitId = u.BusinessUnitId
						group by u1.companyid, u1.businessunitid, lf.featureid, f.cid				
						for xml path('')), 1, 1, '')
					 as FeatureCIDs
		from [sec].License l
		left join userCountsCte u on 	
		isnull(u.CompanyId,0) = isnull(l.CompanyId,0) and isnull(u.BusinessUnitId,0) = isnull(l.BusinessUnitId,0)	
		where  u.CompanyId is not null or
            (exists (select 1 from cobuCidsCte where IsEmpty=1) and  u.CompanyId is null and  
             u.BusinessUnitId is null and u.RoleName = 'Administrator')
		--left join userCountsCte u on 	
		--isnull(u.CompanyId,0) = isnull(l.CompanyId,0) and ((isnull(u.BusinessUnitId,0) = isnull(l.BusinessUnitId,0) OR l.BusinessUnitId IS NULL))
		--where  u.CompanyId is not null or l.companyId is null or l.BusinessUnitId is null or
  --          (exists (select 1 from cobuCidsCte where IsEmpty=1) and  u.CompanyId is null and  
  --           u.BusinessUnitId is null and u.RoleName = 'Administrator')
	)  -- select * from usersAndFeaturesCte 
	select 
			CoCid as CompanyCid,
			BuCID as BusinessUnitCid,
			FeatureCIDs as FeaturesCsv,
			Coalesce([Administrator], 0) as AdministratorUserCount,
			Coalesce([Editor], 0) as EditorUserCount,
			Coalesce([Basic], 0) as BasicUserCount,
			IIF(@includeLicense = 1, Content, null) as EncryptedLicense
			from (select CoCID, BuCID, FeatureCIDs, cnt, RoleName, Content from usersAndFeaturesCte) as Src
			pivot
			(
				sum(cnt) for RoleName in ([Administrator], [Editor], [Basic])
			) as piv

)
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttLicenseUsageDetail]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetLicenseUsageDetailForCD',
    @level2type = NULL,
    @level2name = NULL
