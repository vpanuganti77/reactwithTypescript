﻿CREATE FUNCTION [sec].[GetLicenseUsageDetailFromIds]
(
	@cobuIds [dbo].[ttIntIntTuple] READONLY, -- (CoId,BuId)
	@includeLicense bit = 0
	--this is intended to support a variety of calls:
	--with empty input table or just (',') -> all license usages and user counts, including SysAdmins and all EAs, will be retrieved
	--with input like (',BuCid') -> license usage for that BU and the parent CO (for EA count) will be retrieved
	--with input like ('CoCid,BuCid') -> license usage for that BU +  parent CO (for EA count) will be retrieved
	--with input like ('CoCid,') -> license usage for all BUs of that company, including user count for EAs will be retrieved
	--the result always includes user count for SysAdmins (with NULL CoCid and BuCid)
)
RETURNS TABLE AS RETURN
(
	with cobuIdsCte0 as
	(
		 select CompanyId as CoId, Id as BuId , 1 as IsEmpty
              from [adm].BusinessUnit
              where  (not exists (select 1 from @cobuIds) or (select top 1 isnull(Item1,0) from @cobuIds) = 0)
              union all

              select Id as CoId, null as BuId, 1 as IsEmpty
              from [adm].Company
              where  (not exists (select 1 from @cobuIds) or (select top 1 isnull(Item1,0) from @cobuIds) = 0)
              
              union all

              select Item1 as CoId, bu.id as BuId, 0 as IsEmpty
              from @cobuIds c
              join [adm].BusinessUnit bu 
                     on bu.CompanyId = c.Item1 and (c.Item2 is null or c.Item2 = bu.id)
       
              union all
              
              select distinct Item1 as CoId, null as BuId, 0 as IsEmpty from @cobuIds 
              
              union all
              
              select null as CoId, null as BuId, 0 as IsEmpty
	) -- select * from cobuIdsCte0
	, cobuIdsCte as
	(
		select distinct co.CID as CoCid, c.coId as CompanyId, bu.CID as BuCid, c.buId as BusinessUnitId
		from cobuIdsCte0 c
		left join [adm].Company co on co.Id = c.coId
		left join [adm].BusinessUnit bu on bu.Id = c.buId
	) -- select * from cobuIdsCte order by CompanyId, BusinessUnitId
	, permissionRole as --helper view to associate (basic) ROLE NAME with Permission ID (instead of permission name)
	(
		select pr.PermissionId, r.[Name]
		from [dbo].RolePermission pr
		join [dbo].[Role] r on r.Id = pr.RoleId
		where r.RoleType = 0
	)
	, userCte as --users and roles, possibly no users at all for a given company or BU (that was just created)
	(
		select
			c.CoCid, c.BuCid,
			cr.CompanyId, cr.BusinessUnitId, 
			ur.UserId, coalesce(max(rp.PermissionId), 15) as PermissionId ----for SysAdmin, permissionid is null (b/c it has no entry in CustomRole)
		from [dbo].CustomRole cr
		join [dbo].RolePermission rp on rp.RoleId = cr.RoleId
		right join [dbo].[Role] r on r.Id = cr.RoleId 
		left join [dbo].UserRole ur on ur.RoleId = r.Id
		join cobuIdsCte c on 
			(c.BusinessUnitId = cr.BusinessUnitId) or
			(c.CompanyId = cr.CompanyId and c.BusinessUnitId is null and cr.BusinessUnitId is null) or
			(c.CompanyId is null and cr.CompanyId is null)
		where r.RoleType > 0 
		group by c.CoCid, c.BuCid, cr.companyid, cr.BusinessUnitId, ur.UserId
	) -- select * from userCte;
	, userCountsCte as
	(
		select
			c.CoCid, c.BuCid,
			c.CompanyId, c.BusinessUnitId, 
			count(distinct c.UserId) as cnt, 
			p.[Name] as RoleName 
		from userCte c
		join permissionRole p on p.PermissionId = c.PermissionId	
		group by c.CoCid, c.BuCid, c.companyid, c.BusinessUnitId, p.[Name]
	) -- select * from userCountsCte
	, usersAndFeaturesCte as 
	(
		select distinct u.*, l.Content,
		stuff((
						select ',' + IIF(lf.FeatureId = 0, null, f.[Cid]) 
						from userCountsCte u1
						left join [sec].LicensedAppFeature lf on lf.BusinessUnitId = u.BusinessUnitId
						left join [sec].Feature f on f.id = lf.FeatureId
						where u1.companyid = u.companyid and u1.BusinessUnitId = u.BusinessUnitId
						group by u1.companyid, u1.businessunitid, lf.featureid, f.cid				
						for xml path('')), 1, 1, '')
					 as FeatureCIDs
		from [sec].License l
		join userCountsCte u on 	
		isnull(u.CompanyId,0) = isnull(l.CompanyId,0) and isnull(u.BusinessUnitId,0) = isnull(l.BusinessUnitId,0)	
		where  (
					((u.CompanyId is NULL AND l.CompanyId IS NULL) OR U.CompanyId=l.CompanyId) OR
					((u.BusinessUnitId is NULL AND l.BusinessUnitId IS NULL) OR U.BusinessUnitId=l.BusinessUnitId)
				) or
            (exists (select 1 from cobuIdsCte0 where IsEmpty=1) and  u.CompanyId is null and  
             u.BusinessUnitId is null and u.RoleName = 'Administrator')
	) -- select * from usersAndFeaturesCte 
	select 
			CoCid as CompanyCid,
			BuCID as BusinessUnitCid,
			FeatureCIDs as FeaturesCsv,
			Coalesce([Administrator], 0) as AdministratorUserCount,
			Coalesce([Editor], 0) as EditorUserCount,
			Coalesce([Basic], 0) as BasicUserCount,
			IIF(@includeLicense = 1, Content, null) as EncryptedLicense
			from (select CoCID, BuCID, FeatureCIDs, cnt, RoleName, Content from usersAndFeaturesCte) as Src
			pivot
			(
				sum(cnt) for RoleName in ([Administrator], [Editor], [Basic])
			) as piv
)
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttLicenseUsageDetail]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetLicenseUsageDetailFromIds',
    @level2type = NULL,
    @level2name = NULL