﻿CREATE FUNCTION [sec].[GetLicenseUsageDetailForBuCids]
(
	@buCids ttString READONLY
)
RETURNS TABLE AS RETURN
(
	with buLicensedFeaturesCte as
	( --get Licensed Features for the input BU CID
		select
			lf.ApplicationId as ApplicationId,bu.CID as BuCID, bu.Id as BusinessUnitId,
			f.CID as FeatureCID
		from [sec].LicensedAppFeature lf
		join [adm].BusinessUnit bu on bu.id = lf.BusinessUnitId
		join [sec].Feature f on f.Id = lf.FeatureId
		join @buCids on bu.CID = strVal
	) 
	, buUserCountsCte as 
	( --count users for the input BU, grouped by primite role types
		select 
			cte1.ApplicationId,cte1.BusinessUnitId, count(ur.UserId) as cnt, PermissionRoleId, r.[Name] as RoleName 
		from buLicensedFeaturesCte cte1
		join dbo.CustomRole cr on cr.BusinessUnitId = cte1.BusinessUnitId
		right join dbo.[Role] r on r.Id = cr.PermissionRoleId --right join to ensure all 3 basic role types come back in the result
		left join dbo.[UserRole] ur on ur.RoleId = cr.RoleId --left join because there may not be any users assigned to that custom role
		group by cte1.ApplicationId,cte1.BusinessUnitId, PermissionRoleId, r.[Name]
	)
	, rowResultCte as
	( --unify results from the two CTEs, tie them by BU ID; will return multiple rows per BU (one per primitive permission role)
		select distinct 
			cte1.ApplicationId,
			cte1.BuCID, 
			stuff((
				select ',' + FeatureCID 
				from buLicensedFeaturesCte f1	 
				where f1.BuCID = cte1.BuCID 
				for xml path('')), 1, 1, '')
			 as FeatureCIDs,
			 cte2.cnt, cte2.RoleName
		from buLicensedFeaturesCte cte1 
		join buUserCountsCte cte2 
			on cte2.BusinessUnitId = cte1.BusinessUnitId 
	) --select * from rowResultCte;
	--finally, pivot by (primitive) role name to return a single row per BU, with columns with user counts for each primitive role type
	select 
		ApplicationId,
		BuCID as BusinessUnitCid,
		FeatureCIDs as FeaturesCsv,
		[Administrator] as AdministratorUserCount,
		[Editor] as EditorUserCount,
		[Basic] as BasicUserCount
		from (select ApplicationId,BuCID, FeatureCIDs, cnt, RoleName from rowResultCte) as Src
		pivot
		(
			sum(cnt) for RoleName in ([Administrator], [Editor], [Basic])
		) as piv
)
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttLicenseUsageDetailForBu]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetLicenseUsageDetailForBuCids',
    @level2type = NULL,
    @level2name = NULL

