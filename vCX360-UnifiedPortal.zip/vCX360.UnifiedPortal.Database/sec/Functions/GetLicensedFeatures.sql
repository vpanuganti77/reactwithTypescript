﻿CREATE FUNCTION [sec].[GetLicensedFeatures]
(
)
RETURNS TABLE AS RETURN
(
	select CompanyId, BusinessUnitId, FeatureId
	from [sec].LicensedAppFeature
)
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttLicensedFeature]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetLicensedFeatures',
    @level2type = NULL,
    @level2name = NULL