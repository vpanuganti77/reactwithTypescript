﻿--Retrieves all ENABLED nav items with full detail, including Feature detail to which the nav items belongs to.
--Since a nav item can belong to multiple items, this TVF can return a given nav items multiple times, once
--for each Feature that it belongs to.
CREATE FUNCTION [sec].[GetAllNavItemsWithDetail]
(
)
RETURNS TABLE AS RETURN
(
	select 		
		n.Id as NavItemId,  n.DisplayName as NavItemDisplayName, n.[Description] as NavItemDescription, n.ParentId,
		n.NavLink, n.Tooltip, n.[Group], n.[Order],
		f.Id as FeatureId,	f.CID as FeatureCID, f.[Name] as FeatureName, f.IsLicensable
	from [sec].Feature f 
	join [sec].AppNavItemFeatureMap nf on nf.FeatureId = f.Id
	join [sec].NavItem n on n.Id = nf.NavItemId
	where f.Id > 0 and n.[Enabled] = 1
);
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttNavItemWithDetail]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetAllNavItemsWithDetail',
    @level2type = NULL,
    @level2name = NULL

