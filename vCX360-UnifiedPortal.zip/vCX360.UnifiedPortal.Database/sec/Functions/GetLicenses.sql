﻿CREATE FUNCTION [sec].[GetLicenses]
(
	@coCid varchar(64),
	@buCids ttString READONLY,
	@component varchar(100) = 'Portal'
)
RETURNS TABLE AS RETURN
(
	select 
		li.Id,
		Component,
		li.CompanyId,
		co.CID as CompanyCid,
		BusinessUnitId,
		bu.CID as BusinessUnitCid,
		Content, --encrypted license content
		li.CreatedDate,
		li.UpdatedDate
	from [sec].License li
	Left join [adm].BusinessUnit bu on bu.Id = li.BusinessUnitId
	Left join [adm].Company co on co.Id = li.CompanyId
	where 
	(@coCid is null or co.CID = @coCid)
		and Component = @component
		and
			(not exists (select 1 from @buCids) 
			 or 
			 bu.CID in (select strval from @buCids))
	 --Component = @component and 
	 --((@coCid is null and not exists (select 1 from @buCids)) -- for sysadmin
	 --or
	 --((@coCid is null and li.CompanyId is null)  or co.CID = @coCid)
	 --And 
	 --((not exists (select 1 from @buCids) and  li.BusinessUnitId is null)
	 -- or bu.CID in (select strval from @buCids)))
	 
		--and IsActive = 1
)
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttLicense]', 
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetLicenses',
    @level2type = NULL,
    @level2name = NULL
