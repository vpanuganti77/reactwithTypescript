﻿CREATE FUNCTION [sec].[GetAllFeaturesByBusinessUnitId]
(
	@businessUnitId int
)
RETURNS TABLE AS RETURN
(
	Select FeatureId, CompanyId, BusinessUnitId, FeatureCID, Feature, isEnable, IsLicensable 
    from [sec].[vw_GetLicenseFeatures] where BusinessUnitId = @businessUnitId

    Union

    Select FeatureId, CompanyId, @BusinessUnitId as BusinessUnitId, FeatureCID, Feature, isEnable, IsLicensable 
    from  [sec].[vw_GetNonLicenseFeatures] 
    
)
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[sec].[ttFeatureDetails]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'FUNCTION',
    @level1name = N'GetAllFeaturesByBusinessUnitId',
    @level2type = NULL,
    @level2name = NULL