﻿CREATE FUNCTION [sec].[IsValidRole]
(
	@roleId int
)
RETURNS BIT
AS
BEGIN
	declare @isValid bit = 0;

	select @isValid = IsValid from sec.CustomRoleWithValidFlag
	where RoleId = @roleId;

	return @isValid;
	
END
