﻿CREATE VIEW [sec].[CompositeRole]
WITH SCHEMABINDING
	AS 
with 
apCte as(
	Select Id, CID, [SuiteId] from [adm].[Application]
	union all
	select null as Id, null as CID, null as [SuiteId]
),
coCte as
(
	select distinct Id, CID, cba.ApplicationId from adm.Company c
	Join [adm].[CompanyBusinessUnitAppMap] cba on c.Id = cba.CompanyId
	union all
	select null as Id, null as CID, null ApplicationId
),
buCte as
(
	select Id, CID, CompanyId as coId from adm.BusinessUnit
	union all
	select null as Id, null as CID, null as coId
),
ftCte as
(
	select f.Id, f.CID, lf.BusinessUnitId, b.CompanyId, f.IsLicensable from sec.Feature f
	left join sec.LicensedAppFeature lf on lf.FeatureId = f.Id --left join, only if including both licensable and non-licensable features
	left join adm.BusinessUnit b on b.Id = lf.BusinessUnitId	
	where f.Id > 0
	union all
	select null as Id, null as CID, null as BusinessUnitId, null as CompanyId, null as IsLicensable
),
prCte as
(
	select Id, [Name] from dbo.[Role] 
	where [RoleType] < 2 --[name] in ('Basic', 'Editor', 'Administrator', 'SysAdmin')	
)
select 
	distinct dbo.BuildCustomRoleName(c.Id, b.Id, f.Id, null, p.Id, a.Id) as CustomRoleName,
	case 
		when c.Id is null then 'SysAdmin'
		when c.Id is not null and b.Id is null then 'EnterpriseAdmin'
		else 'BusinessUser'
	end as 'RoleType',
	c.Id as CoId, c.CID as CoCid, 
	b.Id as BuId, b.CID as BuCid, 
	f.Id as FeatureId, f.CID as FeatureCid,
	f.IsLicensable as IsFeatureLicensable,
	p.Id as RoleId, p.[Name] as RoleName
from coCte c, buCte b, ftCte f, prCte p, apCte a
where 
    (a.Id = c.ApplicationId) and
	(b.coId is null or b.coId = c.id) and 
	(f.IsLicensable = 0 or c.Id is null or (b.Id is null and c.Id = f.CompanyId) or  b.Id = f.BusinessUnitId) and
	(c.Id is not null or (c.Id is null and f.Id is null)) and --take out features for SysAdmin
	((p.[Name] = 'SysAdmin' and c.Id is null) or (p.[Name] <> 'SysAdmin' and c.Id is not null)) and
	(c.Id is null or (b.Id is null and p.[Name] = 'Administrator') or b.Id is not null)
group by c.Id, c.CID, b.Id, b.CID, f.Id, f.CID, f.IsLicensable, p.Id, p.[Name], a.SuiteId,a.Id
--order by c.id, b.id, f.id