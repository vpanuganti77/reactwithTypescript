﻿CREATE VIEW [sec].[CustomRoleWithValidFlag]
	AS 
with c1 as
(
	select RoleId, PermissionRoleId, CompanyId, BusinessUnitId, FeatureId, FeaturePartId
	from CustomRole --where isvalid = 0
)
select distinct c1.*, 
case when cr.CustomRoleName is null then 0 else 1 end as IsValid
from c1
left join sec.CompositeRole cr on
	(c1.CompanyId is null or cr.CoId = c1.CompanyId) and
	(c1.BusinessUnitId is null or cr.BuId = c1.BusinessUnitId) and
	(c1.FeatureId is null or cr.FeatureId = c1.FeatureId) and
	c1.PermissionRoleId = cr.RoleId;
