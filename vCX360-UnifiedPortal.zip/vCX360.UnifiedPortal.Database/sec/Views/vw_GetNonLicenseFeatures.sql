﻿CREATE VIEW [sec].[vw_GetNonLicenseFeatures]
	AS 	
Select f.id as FeatureId, Null as CompanyId, Null as BusinessUnitId,
f.CID as FeatureCID, f.Name as Feature, f.Enabled as isEnable, f.IsLicensable IsLicensable
from [sec].[Feature] f where IsLicensable=0 