﻿CREATE VIEW [sec].[vw_GetLicenseFeatures]
AS
Select lf.FeatureId as FeatureId, lf.CompanyId, lf.BusinessUnitId,
f.CID as FeatureCID, f.Name as Feature, f.Enabled as isEnable, f.IsLicensable IsLicensable
from [sec].[LicensedAppFeature] lf
Join [sec].[Feature] f on lf.FeatureId = f.Id 
