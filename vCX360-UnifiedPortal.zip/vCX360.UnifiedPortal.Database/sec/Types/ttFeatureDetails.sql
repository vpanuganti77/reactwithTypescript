﻿CREATE TYPE [sec].[ttFeatureDetails] AS TABLE
(
	FeatureId INT NOT NULL,
	CompanyId INT NOT NULL, 
	BusinessUnitId INT		   NOT NULL,	
	FeatureCID	   VARCHAR(64) NOT NULL,
	Feature		   VARCHAR(50) NOT NULL,
	IsEnabled	   BIT NOT NULL,
	IsLicensable   BIT NOT NULL
)
