﻿CREATE TYPE [sec].[ttLicense] AS TABLE
(
	Id				INT, 
	Component		varchar(100),
	CompanyId		int,
	CompanyCid		nvarchar(64),
	BusinessUnitId	int,
	BusinessUnitCid nvarchar(64),
	Content			varchar(2000),
	[IsDeleted]     BIT,
	CreatedDate		datetime2(0),
	UpdatedDate		datetime2(0)
)
