﻿CREATE TYPE [sec].[ttLicensedFeature] AS TABLE
(
	CompanyId		INT NOT NULL, 
	BusinessUnitId  INT NOT NULL,
	FeatureId		INT NOT NULL
)
