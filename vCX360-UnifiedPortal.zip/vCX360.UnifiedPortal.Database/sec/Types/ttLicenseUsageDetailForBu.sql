﻿CREATE TYPE [sec].[ttLicenseUsageDetailForBu] AS TABLE
(
	BusinessUnitCid varchar(64) not null,
	FeaturesCsv		varchar(500) not null,
	AdministratorUserCount int not null,
	EditorUserCount int not null,
	BasicUserCount  int not null
)
