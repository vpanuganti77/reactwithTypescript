﻿CREATE TYPE [sec].[ttNavItemWithStatusAndBUIds] AS TABLE
(
	NavItemId INT NOT NULL,
	NavItemDisplayName varchar(100) NOT NULL,
	NavItemDescription nvarchar(2000) ,
	IsEnabled BIT NOT NULL,
	--BusinessUnitIds varchar(MAX), --for SysAdmin, this can be very large - CSV of ALL BU IDs
	BusinessUnitId int,
	FeatureIdCids  varchar(500)
)
