﻿CREATE TYPE [sec].[ttLicenseUsageDetail] AS TABLE
(
	CompanyCid		varchar(64), --can be null (this may include sys admins)
	BusinessUnitCid varchar(64), --can be null (this may include sys admins and enterprise admins)
	FeaturesCsv		varchar(500), --can be null (because of above)
	AdministratorUserCount int not null, --for SysAdmin and Enterprise admin, the counts will be returned here
	EditorUserCount int not null, --only applicable at BU level
	BasicUserCount	int not null,  --only applicable at BU level
	EncryptedLicense varchar(2000) --only applicable at the BU level, if requested
)
