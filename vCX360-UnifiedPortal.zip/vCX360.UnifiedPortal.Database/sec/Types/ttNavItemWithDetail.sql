﻿CREATE TYPE [sec].[ttNavItemWithDetail] AS TABLE
(
	NavItemId INT NOT NULL,
	NavItemDisplayName varchar(100) NOT NULL,
	NavItemDescription nvarchar(2000) ,
	ParentId int,
	NavLink  varchar(100),
	Tooltip  varchar(200),
	[Group]  tinyint not null,
	[Order]  tinyint not null,
	--we always bring only the enabled nav items (before login)
	FeatureId    int not null,
	FeatureCID   varchar(30) not null,
	FeatureName  varchar(50) not null,
	IsLicensable bit not null
)
