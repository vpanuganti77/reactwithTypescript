﻿CREATE PROCEDURE [sec].[spSetupLicensedFeatures]
	@buFeatureIds [ttIntIntTuple] readonly,
	@isRemoval bit = null
AS
	if exists (select Item1 from @buFeatureIds except select Id from adm.BusinessUnit)
	Throw 51000, N'Setup licensed features: one or more invalid Business Unit IDs', 1; 

	if exists (select Item2 from @buFeatureIds except select Id from sec.Feature)
	Throw 51000, N'Setup licensed features: one or more invalid feature IDs', 1; 

	Declare @TranName nvarchar(50) = N'SetupLicensedFeaturesTx';
	Begin Transaction @TranName;

	-- Declare @companyId int
	-- Select @companyId = CompanyId from adm.BusinessUnit where id = (Select top 1 Item1 from @buFeatureIds)

	CREATE TABLE #LF (CompanyId INT NULL, BusinessUnitId INT NULL, FeatureId INT NOT NULL);
	INSERT INTO #LF  SELECT NULL, Item1, Item2 FROM @buFeatureIds;

	-- DECLARE @debug001 nvarchar(max) = (SELECT * FROM #LF FOR XML AUTO); print 'LF Before Update: ' + @debug001;
	UPDATE #LF SET CompanyId = B.CompanyId FROM #LF X JOIN [adm].[BusinessUnit] B ON X.BusinessUnitId = B.Id;
	-- DECLARE @debug002 nvarchar(max) = (SELECT * FROM #LF FOR XML AUTO); print 'LF Before Update: ' + @debug002;


	if @isRemoval is not null and @isRemoval = cast(1 as bit)
	begin
		--delete
		delete t
		from sec.LicensedAppFeature t
		join @buFeatureIds s
			on s.Item1 = t.BusinessUnitId and s.Item2 = t.FeatureId
	end
	else
	begin
		--add/or merge?
		merge [sec].[LicensedAppFeature] t
		using #LF s
		on t.BusinessUnitId = s.BusinessUnitId and t.FeatureId = s.FeatureId
		when not matched by target
			then insert (CompanyId, BusinessUnitId, FeatureId)
			values (s.CompanyId, s.BusinessUnitId, s.FeatureId)
		when not matched by source and t.BusinessUnitId in (select Item1 from @buFeatureIds)
			then delete;

		-- --add/or merge?
		-- merge [adm].[LicensedFeature] t
		-- using @buFeatureIds s
		-- on t.BusinessUnitId = s.Item1 and t.FeatureId = s.Item2
		-- when not matched by target
		-- 	then insert (CompanyId, BusinessUnitId, FeatureId)
		-- 	values (@companyId, Item1, Item2)
		-- when not matched by source and t.BusinessUnitId in (select Item1 from @buFeatureIds)
		-- 	then delete;
	end;

	--On Success
	Commit Transaction @TranName;



	--return the licensing BU-FEAT pairs after the update, for the input BU IDs
	select distinct CompanyId, BusinessUnitId, FeatureId
	from sec.LicensedAppFeature
	join @buFeatureIds x on x.Item1 = BusinessUnitId;

RETURN 0
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[adm].[ttLicensedFeature]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'PROCEDURE',
    @level1name = N'spSetupLicensedFeatures',
    @level2type = NULL,
    @level2name = NULL
