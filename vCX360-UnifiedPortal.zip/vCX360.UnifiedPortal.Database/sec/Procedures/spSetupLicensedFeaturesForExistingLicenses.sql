﻿
/*
	This script adds entries to [adm].LicensedFeature table based on System or Company Level License being present.
	This way, it attempts to eliminate the need to load Business Unit License for EACH & EVERY BusinessUnit which typically
	gets populated on upload of Business Unit level License.

	For the moment, this is ONLY enabled for CloudDashboard Solution
*/

CREATE PROCEDURE [sec].[spSetupLicensedFeaturesForExistingLicenses]
	@companyId int,
	@businessUnitId int
AS
	
	Declare @result [dbo].StProcResult;

	Set XACT_ABORT ON;

	DECLARE @IsProductCloudDashboard AS INT = (SELECT [adm].[IsProductCloudDashboard]());

	--Validate Company Id
	If(not exists(
		Select id
		From [adm].Company
		Where id = @companyId
		))
	Throw 51000, N'ERROR-spSetupLicensedFeaturesForExistingLicenses-Invalid Company Id', 1;

	--validate name (must be unique for a given company)
	if (not exists (select * from [adm].[BusinessUnit] where Id = @businessUnitId))
	throw 51000, N'ERROR-spSetupLicensedFeaturesForExistingLicenses-BusinessUnit does not exists (within the parent company)', 1;

	--validate if user (APP_NAME()) is SysAdmin or EAdmin for given company ID
	if not exists (select 1 from [adm].[IsEnterpriseAdminForCompany](@companyId))
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-UNAUTHORIZED The user is not a Sys Admin or an Enterprise Admin for this company to create BUs', 1;


	Declare @TranName nvarchar(20) = N'InsertSetupLicensedFeaturesForExistingLicensesTx';
	Begin Transaction @TranName;


	--add the default (None) licensed feature, to enable some level of access
	declare @buFeatIds ttIntIntTuple;
	IF @IsProductCloudDashboard = 1 AND 
	   EXISTS(SELECT * FROM [sec].License where CompanyId IS NULL AND BusinessUnitId IS NULL)	-- Presence of System License
	BEGIN
	    INSERT INTO @buFeatIds
		SELECT B.Id, F.Id
		FROM [adm].[BusinessUnit] B
		JOIN [sec].[Feature] F ON F.Id=F.Id AND (F.Id=0 OR (Enabled=1 AND IsLicensable=1));
	END;

	IF @IsProductCloudDashboard = 1 AND 
	   NOT EXISTS(SELECT * FROM [sec].License where CompanyId IS NULL AND BusinessUnitId IS NULL) AND	-- No System License
	   EXISTS(SELECT * FROM [sec].License where CompanyId=@companyId AND BusinessUnitId IS NULL)		    -- Presence of Company License
	BEGIN
	    INSERT INTO @buFeatIds
		SELECT B.Id, F.Id
		FROM [adm].[BusinessUnit] B
		JOIN [sec].[Feature] F ON F.Id=F.Id AND (F.Id=0 OR (Enabled=1 AND IsLicensable=1))
		WHERE B.CompanyId=@companyId;
	END;

	-- DECLARE @debug002 nvarchar(max) = (SELECT * FROM @buFeatIds FOR XML AUTO); print 'buFeatIds: ' + @debug002;
	IF @IsProductCloudDashboard = 1 
	BEGIN
		Exec [sec].[spSetupLicensedFeatures] @buFeatIds, 0;
	END;

	--On Success
	Commit Transaction @TranName;

	-- Select * From @result;
	Return;

RETURN 0
Go

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'PROCEDURE',
    @level1name = N'spSetupLicensedFeaturesForExistingLicenses',
    @level2type = NULL,
    @level2name = NULL
