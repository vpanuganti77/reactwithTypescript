﻿CREATE PROCEDURE [sec].[spSetupLicensedFeaturesFromCids]
	@buFeatureCsvCids [ttString] readonly, --each row is a CSV of 2 CIDs: 'buCid,featureCid'
	@isRemoval bit = null
AS
	--break CSVs apart and create one table with two string columns
	declare @buFeatureCids table (buCid nvarchar(64), featureCid nvarchar(64))
	insert into @buFeatureCids
	select
		substring(strVal, 1, CHARINDEX(',', strVal)-1) as buCid,
		substring(strVal, CHARINDEX(',', strVal)+1, 100) as featureCid
	from @buFeatureCsvCids;

	declare @buFeatureIds ttIntIntTuple; --to populate table of ID pairs (BU, Feature) based on CIDs
	insert into @buFeatureIds
	select
		bu.Id, f.Id
	from @buFeatureCids t
	join adm.BusinessUnit bu on bu.CID = t.buCid
	join sec.Feature f on f.CID = t.featureCid;

	
	exec [sec].[spSetupLicensedFeatures] @buFeatureIds, @isRemoval;

RETURN 0
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[adm].[ttLicensedFeature]',
    @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'PROCEDURE',
    @level1name = N'spSetupLicensedFeaturesFromCids',
    @level2type = NULL,
    @level2name = NULL
