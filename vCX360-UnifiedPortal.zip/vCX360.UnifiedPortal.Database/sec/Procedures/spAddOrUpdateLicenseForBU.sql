﻿CREATE PROCEDURE [sec].[spAddOrUpdateLicenseForBU]
	@coCid varchar(64),
	@buCid varchar(64),
	@component varchar(100) = 'Portal',
	@content varchar(2000)--,
	--@isActive bit = 1
AS
	declare @result dbo.StProcResult;
	set xact_abort on;

	declare @coId int = (select top(1) Id from adm.Company where CID = @coCid);
	declare @buId int = (select top(1) Id from adm.BusinessUnit where CID = @buCid);

	if @coId IS NULL AND @buId IS NOT NULL
	Throw 51000, N'ApplicationError: Add Or Update License - Invalid Company CID & BU CID Combination', 1; 

	--if @buId is null or @buCid is null
	--Throw 51000, N'ERROR-ADD-LICENSE-Invalid Business Unit CID', 1;
	--if @coId is null or @coCid is null
	--Throw 51000, N'ERROR-ADD-LICENSE-Invalid Company CID', 1;

	--set @isActive = coalesce(@isActive, 1);

	--if exists (
	--	select 1 from adm.License 
	--	where 
	--		CompanyId = @coId and BusinessUnitId = @buId and
	--		Component = @component and IsActive = 1 and @isActive = 1)
	--Throw 51000, N'ERROR-ADD-LICENSE-Cannot have more than one license active at a time for a given Business Unit and Component', 1;

	declare @TranName nvarchar(20) = N'InsertLicenseTx';
	Begin Transaction @TranName;

	declare @id int = (
		select top(1) Id from sec.License
		where 
		((@coId is null and CompanyId is null) or (CompanyId = @coId)) and	
		((@buid is null and BusinessUnitId is null) or (BusinessUnitId = @buid))			
		and Component = @component);

	if (@id is null)
		insert into [sec].[License]
		(Component, CompanyId, BusinessUnitId, Content)--, IsActive)
		output cast(0 as bit), inserted.Id, '[adm].[License]' into @result
		values
		(@component, @coId, @buId, @content)--, @isActive);
	else
		update [sec].[License]
		set
			Content = @content,
			UpdatedDate = getdate()
		output cast(0 as bit), @id, '[adm].[License]' into @result
		where
			Id = @id;

	commit transaction @TranName;

	select * from @result;
	return;

RETURN 0

go
exec sp_addextendedproperty
	@name = N'DM_RecordType',
	@value = N'[dbo].[StProcResult]',
	 @level0type = N'SCHEMA',
    @level0name = N'sec',
    @level1type = N'PROCEDURE',
    @level1name = N'spAddOrUpdateLicenseForBU',
    @level2type = NULL,
    @level2name = NULL
