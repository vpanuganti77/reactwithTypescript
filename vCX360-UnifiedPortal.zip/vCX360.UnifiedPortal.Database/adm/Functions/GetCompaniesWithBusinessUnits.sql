﻿CREATE FUNCTION [adm].[GetCompaniesWithBusinessUnits]
(
	@ids [dbo].[ttIntValue] READONLY
)
RETURNS TABLE AS RETURN
(
	SELECT 
		CompanyId, CompanyName, CompanyDescription, Domain,
		BuId, BuName, BuDescription, BUDomain
	from [adm].vw_CompanyBusinessUnit 
	where not exists (select * from @ids) or CompanyId in (select id from @ids)
);

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttCompanyWithBusinessUnit]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetCompaniesWithBusinessUnits',
    @level2type = NULL,
    @level2name = NULL