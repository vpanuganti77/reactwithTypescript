﻿CREATE FUNCTION [adm].[GetDomainById]
(
		@ids [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
	 Select * from [adm].[Domain]
     where not exists (select * from @ids) or Id in (select Id from @ids)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttDomain]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetDomainById'
    