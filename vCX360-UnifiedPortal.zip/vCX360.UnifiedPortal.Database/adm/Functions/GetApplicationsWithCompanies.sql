﻿CREATE FUNCTION [adm].[GetApplicationsWithCompanies]
(
	@ids [dbo].[ttIntValue] READONLY
)
RETURNS TABLE AS RETURN
(
	SELECT DISTINCT
		ap.Id as ApplicationId,
		ap.CID as ApplicationCID,
		ap.[Name] as ApplicationName,
		ap.[Type] as ApplicationType,
		ap.[Status] as AppStatus,
		ap.[Description] as AppDescription,
		ap.SuiteId as SuiteId,
		s.[Name] as SuiteName,
		ap.[IsDeleted],
		ap.[CreatedBy] ,
		ap.[CreatedDate] ,
		ap.[UpdatedBy] ,
		ap.[UpdatedDate] ,
		
		c.Id as CompanyId, 
		c.CID as CompanyCID,
		c.[Name] as CompanyName, 
		c.[Description] as CompanyDescription, 
		c.Domain as CompanyDomain,
		c.[Status],
		
		c.[TenantId],
		t.[TenantName],
		c.[OrgId],
		c.[IntegrationType]

	FROM [adm].[Company] c 
	JOIN [adm].[CompanyBusinessUnitAppMap] cba ON c.Id = cba.CompanyId
	JOIN [adm].[Application] ap ON  ap.Id = cba.ApplicationId
	JOIN [adm].[Suite] s ON ap.SuiteId=s.Id
	LEFT JOIN [adm].[Tenant] t on c.TenantId = t.TenantId
	where not exists (select * from @ids) or ap.Id in (select id from @ids)
)


go

EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[adm].[ttApplicationsWithCompanies]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetApplicationsWithCompanies';