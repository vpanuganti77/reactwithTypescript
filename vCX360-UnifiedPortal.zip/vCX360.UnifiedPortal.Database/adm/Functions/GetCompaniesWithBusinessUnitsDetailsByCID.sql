﻿CREATE FUNCTION [adm].[GetCompaniesWithBusinessUnitsDetailsByCID]
(
	@cids [dbo].[ttString] READONLY
)
RETURNS TABLE AS RETURN
(
	SELECT 
		CompanyId, 
		CompanyCID,
		CompanyName,
		CompanyStatus,
		CompanyDescription,
		
		TenantId,
		OrgId,
		IntegrationType,
		IsDeleted,
		CompanyCreatedBy,
		CompanyCreatedDate,
		CompanyUpdatedBy,
		CompanyUpdatedDate,
		BuId, 
		BuCID,
		BuName,
		BuStatus,
		BuDescription,
		BuCreatedBy,
		BuCreatedDate,
		BuUpdatedBy,
		BuUpdatedDate,
		BuNumber,
		Domain,
		BUDomain
	from [adm].vw_CompanyBuDetail 
	where not exists (select * from @cids) or CompanyCID in (select StrVal from @cids)
);

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttCompanyWithBusinessUnitDetails]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetCompaniesWithBusinessUnitsDetailsByCID',
    @level2type = NULL,
    @level2name = NULL
