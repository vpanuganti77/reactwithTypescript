﻿-- //Get TenantOAClient By OAClientId with multitenancy Using while Updating/retriveing

CREATE  FUNCTION [adm].[GetTenantOAClientById] 
(
    @ttOAClientIds [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
  with tab as (select * from [adm].[OAClient] where 
    (Select ISnull(result,0) from adm.issysadmin()) = 1 or 
    (id in (select OAClientId from adm.BusinessUnit)))
    select * from tab where 
    not exists (select * from @ttOAClientIds) or
	Id in (select Id from @ttOAClientIds)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttOAClient]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetTenantOAClientById',
    @level2type = NULL,
    @level2name = NULL