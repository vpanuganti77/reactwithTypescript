﻿CREATE FUNCTION [adm].[GetApplicationById]
(
	@ids [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
	 Select * from [adm].[Application] 
     where not exists (select * from @ids) or Id in (select Id from @ids)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttApplication]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetApplicationById'
    