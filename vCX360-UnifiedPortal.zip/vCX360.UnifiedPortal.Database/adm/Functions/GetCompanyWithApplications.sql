﻿CREATE FUNCTION [adm].[GetCompanyWithApplications]
(
	@ids [dbo].[ttIntValue] READONLY
)
RETURNS TABLE AS RETURN
(
	SELECT DISTINCT
	c.Id as CompanyId, 
	c.CID as CompanyCID,
	c.[Name] as CompanyName, 
	c.[Description] as CompanyDescription, 
	c.[Domain] as CompanyDomain,
	c.[status],
	
	c.[TenantId],
	t.[TenantName],
	c.[OrgId],
	c.[IntegrationType],
	c.[IsDeleted],
	c.[CreatedBy]	,
	c.[CreatedDate] ,
	c.[UpdatedBy]	,
	c.[UpdatedDate] ,

	ap.[Id] as ApplicationId,
	ap.[CID] as ApplicationCID,
	ap.[Name] as ApplicationName,
	ap.[Type] as ApplicationType,
	ap.[Status] as AppStatus,
	ap.[Description] as AppDescription,
	ap.SuiteId as SuiteId,
	s.[Name] as SuiteNamee
	
	FROM [adm].[Company] c 
	JOIN [adm].[CompanyBusinessUnitAppMap] cba ON c.Id = cba.CompanyId
	JOIN [adm].[Application] ap ON  ap.Id = cba.ApplicationId
	JOIN [adm].[Suite] s ON ap.SuiteId=s.Id
	LEFT JOIN [adm].[Tenant] t on c.TenantId = t.TenantId
	where not exists (select * from @ids) or c.Id in (select id from @ids)
)

go

EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[adm].[ttCompanyWithApplications]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetCompanyWithApplications';