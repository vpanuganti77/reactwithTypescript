﻿CREATE FUNCTION [adm].[IsEnterpriseAdminForCompany]
(
	@companyId int
)
RETURNS TABLE AS RETURN
(
	with coCte as
	(
		select Id from [adm].[Company] 
		where 
			APP_NAME() = 'Developer' or  APP_NAME() = 'SU' or
			APP_NAME() = 'DacFx Deploy' or
			APP_NAME() = 'Microsoft SQL Server Management Studio - Query' or --for the sake of unit testing and running queries from SSMS. If not passed, it assumes super-user with full access.
			-- Following code is applicable for Cloud Dashboard solution as User with Full Permission for Admin module should be able to add Company
			
			1 = (Select count(1) from [dbo].[Role] r 
			join [dbo].UserRole ur on ur.RoleId = r.Id
			join [dbo].[User] u on u.Id = ur.UserId where u.DomainUser = APP_NAME() and r.name='SysAdmin' ) or
			Id in 
			(select CompanyId 
			from  [dbo].[User] 
			where DomainUser = APP_NAME() --and cr.BusinessUnitId is null  --must be enterprise admin
			) 
	)
	select 1 as result --return true if APP_NAME (username) if input business unit ID is in the ids returned by the buCte
	where @CompanyId in (select Id from coCte)
)