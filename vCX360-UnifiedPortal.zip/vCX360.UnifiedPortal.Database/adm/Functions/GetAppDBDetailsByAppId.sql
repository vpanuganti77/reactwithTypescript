﻿CREATE FUNCTION [adm].[GetAppDBDetailsByAppId]
(
	@ids [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
	 Select * from [adm].[AppDBDetails] 
     where not exists (select * from @ids) or AppId in (select Id from @ids)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttAppDBDetails]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetAppDBDetailsByAppId'
