﻿CREATE FUNCTION [adm].[GetCompanyIdForBUId]
(
	@buId int
)
RETURNS INT
AS
BEGIN
	RETURN (SELECT TOP(1) CompanyId from [adm].[BusinessUnit] where Id = @buId);
END
