﻿CREATE FUNCTION [adm].[GetBusinessUnitsById]
(
	@businessIds [dbo].[ttIntValue] READONLY
)
RETURNS TABLE AS RETURN
(
	select
		bu.Id,
		bu.CID,
		bu.[Name],
		bu.[Status],
		bu.[Description],		
		bu.CompanyId,
		bu.Number as BuNumber,
		co.[Name] AS CompanyName,		
		IIF(isnull(bu.Domain,'') ='', co.Domain, bu.Domain) as Domain,
		bu.IsDeleted,
		bu.CreatedBy,
		bu.CreatedDate,
		bu.UpdatedBy,
		bu.UpdatedDate
	from 
		[adm].BusinessUnit as bu	
	JOIN [adm].Company AS co
	ON
		co.Id = bu.CompanyId
	where not exists (select * from @businessIds) or bu.id in (select id from @businessIds)

);

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttBusinessUnitDetail]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetBusinessUnitsById',
    @level2type = NULL,
    @level2name = NULL
