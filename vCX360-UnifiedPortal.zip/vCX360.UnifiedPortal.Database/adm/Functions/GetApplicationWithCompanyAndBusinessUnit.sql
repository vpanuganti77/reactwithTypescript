﻿
CREATE FUNCTION [adm].[GetApplicationWithCompanyAndBusinessUnit]
(
	@ids [dbo].[ttIntValue] READONLY
)
RETURNS TABLE AS RETURN
(
	SELECT DISTINCT
		ap.Id as ApplicationId,
		ap.CID as ApplicationCID,
		ap.[Name] as ApplicationName,
		ap.[Type] as ApplicationType,
		ap.[Status] as AppStatus,
		ap.SuiteId as SuiteId,
		s.[Name] as SuiteName,
		ap.[Description] as AppDescription,
		ap.IsDeleted,
		ap.CreatedBy ,
		ap.CreatedDate, 
		ap.UpdatedBy ,
		ap.UpdatedDate ,

		c.Id as CompanyId, 
		c.CID as CompanyCID,
		c.[Name] as CompanyName, 
		c.[Status] as CompanyStatus,
		c.[Description] as CompanyDescription, 
		c.Domain as CompanyDomain,
		
		c.[TenantId],
		t.[TenantName],
		c.[OrgId],
		c.[IntegrationType],

		b.Id as BuId,
		b.CID as BuCID,
		b.[name] as BuName ,
		b.[Status] asBuStatus, 
		b.[Description] as BuDescription,
		b.Domain as BuDomain,
		b.Number
	
	from [adm].[Application] ap
	JOIN [adm].[Suite] s ON ap.SuiteId=s.Id
	LEFT JOIN [adm].[CompanyBusinessUnitAppMap] cba	ON ap.Id = cba.ApplicationId
	LEFT JOIN [adm].[Company] c	ON cba.CompanyId = c.Id
	LEFT JOIN [adm].[Tenant] t on c.TenantId = t.TenantId
	LEFT JOIN [adm].[BusinessUnit] b ON cba.BusinessUnitId = b.Id
	where not exists (select * from @ids) or ap.Id in (select id from @ids)
);
GO

EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[adm].[ttApplicationWithCompanyAndBusinessUnit]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetApplicationWithCompanyAndBusinessUnit';


	