﻿CREATE FUNCTION [adm].[GetFeedbackById]
(
	@ids [dbo].[ttIntValue] READONLY
)
RETURNS TABLE AS RETURN
(
	SELECT DISTINCT
	a.[Id] as ApplicationId,
	a.[Name] as ApplicationName,
	c.[Id] as CompanyId,
	c.[Name] as CompanyName,
	f.[Id] as FeedbackId,
	f.[FeedbackType] as FeedbackType,
	fr.[Id] as FeedbackResponseId,
	fr.[Response] as FeedbackResponse,
	u.[Id] as UserId,
	u.UserName as UserName,
	f.[Status] as [Status],
	f.[CreatedBy],
	f.[CreatedDate],
	f.[UpdatedBy],
	f.[UpdatedDate]

	FROM [adm].[Application] a
	JOIN [adm].[CompanyBusinessUnitAppMap] cba ON a.Id = cba.ApplicationId
	JOIN [adm].[Company] c ON cba.CompanyId = c.Id
	LEFT JOIN [adm].[Feedback] f ON a.Id = f.ApplicationId
	LEFT JOIN [adm].[FeedbackResponse] fr ON f.Id = fr.FeedbackId
	LEFT JOIN [dbo].[User] u ON fr.UserId = u.Id
	where f.Id in (select id from @ids) or not exists (select * from @ids)

);

go

EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[adm].[ttFeedbackDetails]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetFeedbackById';

