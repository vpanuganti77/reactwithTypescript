﻿CREATE FUNCTION [adm].[IsBusinessUnitIdValid]
(
	@id int
)
RETURNS BIT
AS
BEGIN
	if (not exists (select id from [adm].[BusinessUnit] where id = @id))
		return CAST(0 as BIT);
	return CAST (1 as BIT);
END
