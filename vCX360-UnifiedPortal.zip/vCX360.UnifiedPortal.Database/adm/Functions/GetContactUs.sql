﻿CREATE FUNCTION [adm].[GetContactUs]
(
	--always retriev all, no filtering; should be cached
)
RETURNS TABLE AS RETURN
(
	select	cu.[ApplicationId],
			cu.[FirstName]  ,   
			cu.[LastName]  ,    
			cu.[EMail]	,	    
			cu.[Phone]	,
			cu.[Description],
			cu.[Country],
			
			a.[Name] as ApplicationName,
			a.[CID] as ApplicationCID,
			cu.[CompanyId] , 
			c.[Name] as CompanyName,
			c.[CID] as CompanyCID
					
	from [adm].[Application] a 
	join [adm].[ContactUs] cu on cu.ApplicationId = a.Id
	join [adm].[Company] c on cu.CompanyId = c.Id
)


go

EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[adm].[ttContactUs]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetContactUs';