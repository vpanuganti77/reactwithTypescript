﻿ -- //Get OAClient ById without multitenancy used only while adding new OAClient 

CREATE  FUNCTION [adm].[GetOAClientById] 
(
    @ttOAClientIds [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
    SELECT OAC.* FROM adm.OAClient OAC
    where 
	not exists (select * from @ttOAClientIds) or
	OAC.Id in (select Id from @ttOAClientIds)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttOAClient]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetOAClientById',
    @level2type = NULL,
    @level2name = NULL