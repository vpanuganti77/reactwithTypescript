﻿CREATE  FUNCTION [adm].[GetOAClientRegionById] 
(
    @ttOAClientIds [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
   Select oac.[Id] as OAClientId,
          oac.[Name] as OAClientName,
          oac.ClientIdEnc as OAClientClientIdEnc, 
          oac.SecretEnc as OAClientSecretEnc,
          oac.[LastValidationStatus],
          oac.[LastValidationDate],        
          oac.[CreatedBy],
          oac.[CreatedDate],
          oac.[UpdatedBy],
          oac.[UpdatedDate],
          oac.CompanyId, 
          ISNULL(co.IntegrationType, 1) IntegrationType,     
          rgn.[Id] as RegionId, 
          rgn.[Name] as RegionName, 
          rgn.[Description] as RegionDescription, 
          rgn.[Text] as RegionText
        From [adm].[OAClient] oac
        JOIN [adm].[Region] rgn on oac.RegionId = rgn.Id
        --JOIN [adm].BusinessUnit bu on bu.OAClientId = oac.Id
        JOIN [adm].Company co on co.Id = oac.CompanyId
    where
	not exists (select * from @ttOAClientIds) or
	oac.[Id] in (select Id from @ttOAClientIds)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttOAClientwithRegion]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetOAClientRegionById',
    @level2type = NULL,
    @level2name = NULL