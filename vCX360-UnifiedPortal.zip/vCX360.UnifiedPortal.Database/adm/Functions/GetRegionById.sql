﻿CREATE  FUNCTION [adm].[GetRegionById] 
(
    @ttRegionIds [dbo].[ttIntValue] Readonly
)
RETURNS TABLE AS RETURN
(
    SELECT * FROM [adm].[Region] where
	not exists (select * from @ttRegionIds) or
	Id in (select Id from @ttRegionIds)
)
Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[adm].[ttRegion]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'FUNCTION',
    @level1name = N'GetRegionById',
    @level2type = NULL,
    @level2name = NULL