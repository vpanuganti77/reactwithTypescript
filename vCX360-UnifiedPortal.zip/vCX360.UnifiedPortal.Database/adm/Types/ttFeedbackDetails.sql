﻿CREATE TYPE [adm].[ttFeedbackDetails] AS TABLE
(
	
	ApplicationId        INT ,
	ApplicationName	     VARCHAR(255) ,
	CompanyId		     INT ,
	CompanyName		     VARCHAR(255) ,
	FeedbackId			 INT ,
	FeedbackType		 VARCHAR(64) ,
	FeedbackResponseId	 INT	,		 
	FeedbackResponse	 NVARCHAR(255),
	UserId			     INT    ,       
	UserName		     NVARCHAR(100) , 
	[Status]		     VARCHAR(255) ,
	[CreatedBy]	         NVARCHAR (256) ,
	[CreatedDate]	     DATETIME2 (0) , 
	[UpdatedBy]	         NVARCHAR (256) ,
	[UpdatedDate]	     DATETIME2 (0)  
)
