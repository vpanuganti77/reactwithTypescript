﻿CREATE TYPE [adm].[ttApplicationWithCompanyAndBusinessUnit] AS TABLE
(
	--Application
	ApplicationId		 INT 	        NOT NULL ,
	ApplicationCID		 NVARCHAR (16)  NOT NULL,
	ApplicationName		 NVARCHAR (64)  NOT NULL,
	ApplicationType		 NVARCHAR (64)  NULL,
	AppStatus			 NVARCHAR (255) NULL,
	SuiteId				 INT            NULL,
	SuiteName			 NVARCHAR (64)  NULL,	
	AppDescription		 NVARCHAR (MAX) NULL,
	[IsDeleted]          BIT            NOT NULL,
	CreatedBy			 NVARCHAR (256) NOT NULL,
	CreatedDate			 DATETIME2 (0)	NOT NULL,
	UpdatedBy 			 NVARCHAR (256) NULL,
	UpdatedDate 		 DATETIME2 (0)	NULL,

	--Company
	CompanyId			 INT			NULL ,
	CompanyCID			 NVARCHAR(64)	NULL,
	CompanyName 		 NVARCHAR(128)	NULL,
	CompanyDescription	 NVARCHAR(255)	NULL,
	CompanyDomain		 NVARCHAR(10)	NULL,
	CompanyStatus        NVARCHAR (255) NULL,
	[TenantId]			 INT			NULL,
	[TenantName]		 NVARCHAR(128)	NULL,	
	[OrgId]				 NVARCHAR(64)	NULL,
	[IntegrationType]	 INT			NULL,

	--BusinessUnit
	 BuId				INT				NULL,
	 BuCID				NVARCHAR(64)	NULL,
	 BuName				NVARCHAR(128)	NULL,
	 BuStatus          NVARCHAR (10)    NULL, 
	 BuDescription		NVARCHAR(255)	NULL,
	 BuDomain			NVARCHAR(10)	NULL,
	 BuNumber			NVARCHAR (10)   NULL
)
