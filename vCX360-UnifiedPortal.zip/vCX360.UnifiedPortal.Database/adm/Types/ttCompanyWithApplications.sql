﻿CREATE TYPE [adm].[ttCompanyWithApplications] AS TABLE
(
	CompanyId			 INT			NOT NULL ,
	CompanyCID			 NVARCHAR(64) 	NOT NULL,
	CompanyName 		 NVARCHAR(128)	NOT NULL,
	CompanyDescription	 NVARCHAR(255)	NULL,
	CompanyDomain		 NVARCHAR(10)	NULL,
	CompanyStatus        NVARCHAR (255) NULL,
	[TenantId]			 INT			NULL,
	[TenantName]		 NVARCHAR(128)	NULL,	
	[OrgId]				 NVARCHAR(64)	NULL,
	[IntegrationType]	 INT			NULL,
	[IsDeleted]          BIT            NOT NULL,
	CreatedBy			 NVARCHAR (256) NOT NULL,
	CreatedDate			 DATETIME2 (0)	NOT NULL,
	UpdatedBy 			 NVARCHAR (256) NULL,
	UpdatedDate 		 DATETIME2 (0)	NULL,

	ApplicationId		 INT 	        NOT NULL ,
	ApplicationCID		 NVARCHAR (16)  NOT NULL,
	ApplicationName		 NVARCHAR (64)  NOT NULL,
	ApplicationType		 NVARCHAR (64)  NULL,
	AppStatus			 NVARCHAR (255) NULL,
	AppDescription		 NVARCHAR (MAX) NULL,
	SuiteId				 INT            NULL,
	SuiteName			 NVARCHAR (64)  NULL
	
	
)
