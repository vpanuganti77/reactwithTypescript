﻿CREATE TYPE [adm].[ttContactUs] AS TABLE
(
	[ApplicationId] INT			  NOT NULL,
	[FirstName]     NVARCHAR(64)  NULL,
	[LastName]      NVARCHAR(64)  NULL,
	[EMail]		    NVARCHAR(64)  NULL,
	[Phone]		    NVARCHAR(20)  NULL,
	[Description]	NVARCHAR(MAX) NULL,
	[Country]	    NVARCHAR(64)  NULL, 
	ApplicationCID	NVARCHAR (16) NOT NULL,
	ApplicationName	NVARCHAR (64) NOT NULL,
	[CompanyId]     INT           NULL,
	CompanyCID		NVARCHAR(64)  NOT NULL,
	CompanyName 	NVARCHAR(128) NOT NULL
)
