﻿CREATE TYPE [adm].[ttOAClientwithRegion] AS TABLE
(
    [Id]                    INT            NULL,
    [OAClienName]           NVARCHAR(512)  NOT NULL, 
    [OAClienClientIdEnc]    NVARCHAR(256)  NOT NULL, 
    [OAClienSecretEnc]      NVARCHAR(1024) NOT NULL,
    [LastValidationStatus]  NVARCHAR (64)  NULL,
	[LastValidationDate]    DATETIME2 (0)  NULL,
   
    [CreatedBy]             NVARCHAR (64)  NOT NULL ,
    [CreatedDate]           DATETIME2 (0)  NOT NULL ,
    [UpdatedBy]             NVARCHAR (64)  NULL,
    [UpdatedDate]           DATETIME2 (0)  NULL,
    [CompanyId]             INT            NOT NULL,
    [IntegrationType]       INT,

    [regionId]              INT            NOT NULL,
    [RegionName]            NVARCHAR(64)   NOT NULL, 
    [RegionDescription]     NCHAR(128)     NOT NULL,
    [RegionText]            NCHAR(128)     NOT NULL
)
GO
