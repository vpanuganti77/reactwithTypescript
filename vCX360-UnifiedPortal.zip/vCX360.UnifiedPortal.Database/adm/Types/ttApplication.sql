﻿CREATE TYPE [adm].[ttApplication] AS TABLE
(
   [Id]			    INT				, 	    
   [CID]			NVARCHAR (16)   ,
   [Name]			NVARCHAR (64)   ,
   [Type]           NVARCHAR (64)   ,
   [Icon]           VARBINARY(MAX)  ,
   [OverviewURL]	NVARCHAR(MAX)   ,
   [Overview]       NVARCHAR(1000)  ,
   [Status]			NVARCHAR (255)  ,
   [Description]	NVARCHAR (1000) ,
   [SuiteId]		INT				,
   [IsDeleted]      BIT ,

   --audit info
   [CreatedBy]		NVARCHAR (256) ,
   [CreatedDate]	DATETIME2 (0)  ,
   [UpdatedBy]		NVARCHAR (256) ,
   [UpdatedDate]	DATETIME2 (0)	
)
