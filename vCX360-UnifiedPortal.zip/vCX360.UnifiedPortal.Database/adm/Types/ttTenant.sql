﻿CREATE TYPE [adm].[ttTenant] AS TABLE
(
	[TenantId]		   SMALLINT ,
	[TenantCID]        NVARCHAR(100),
	[TenantName]	   NVARCHAR(100) ,
	[ParentTenantId]   SMALLINT,
	[PlatformId]	   SMALLINT	,
	[ConnectionString] NVARCHAR(100),
	[Description]      NVARCHAR(MAX)  ,
	[Contact]		   NVarchar(100),
	[IsDeleted]        BIT,
	[CreatedBy]        NVARCHAR (256)  ,
	[CreatedDate]      DATETIME2 (0)	 ,
	[UpdatedBy]        NVARCHAR (256)  ,
	[UpdatedDate]      DATETIME2 (0)	 
)
