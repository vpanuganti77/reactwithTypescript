﻿CREATE TYPE [adm].[ttFeedback] AS TABLE
(
	Id				INT ,
	FeedbackType	VARCHAR(64)   ,
	ApplicationId	INT			  ,
	ApplicationType VARCHAR(64)	  ,
	[Message]		VARCHAR(255)  ,
	[Attachment]    VARBINARY(MAX) ,
	[Status]        VARCHAR(255)  ,
	IsDeleted		BIT ,
		--audit info
	[CreatedBy]     NVARCHAR (256) ,
	[CreatedDate]   DATETIME2 (0)  ,
	[UpdatedBy]     NVARCHAR (256) ,
	[UpdatedDate]   DATETIME2 (0)  

)
