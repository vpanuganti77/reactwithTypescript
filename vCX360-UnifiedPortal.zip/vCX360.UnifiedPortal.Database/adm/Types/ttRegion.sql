﻿CREATE TYPE [adm].[ttRegion] AS TABLE
(
    [Id]                INT             NULL,
    [Name]              NVARCHAR(512)   NOT NULL, 
    [Description]       NCHAR(128)      NOT NULL,
    [Text]              NCHAR(128)      NOT NULL,
    [Enabled]           TINYINT         NOT NULL DEFAULT 0
)
GO
