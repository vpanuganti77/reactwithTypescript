﻿CREATE TYPE [adm].[ttOAClient] AS TABLE
(
    [Id]                    INT             NULL,
    [Name]                  NVARCHAR(512)   NOT NULL, 
    [ClientIdEnc]           NVARCHAR(256)   NOT NULL, 
    [SecretEnc]             NVARCHAR(1024)  NOT NULL,
    [RegionId]              TINYINT         NOT NULL,
    [LastValidationStatus]  NVARCHAR (64)   NULL,
	[LastValidationDate]    DATETIME2 (0)	NULL,
    [CompanyId]		        INT             NOT NULL,
    [IsDeleted]             BIT,
    --audit info
    [CreatedBy]             NVARCHAR (64)  NOT NULL ,
    [CreatedDate]           DATETIME2 (0)  NOT NULL ,
    [UpdatedBy]             NVARCHAR (64)  NULL,
    [UpdatedDate]           DATETIME2 (0)  NULL

  
)
GO
