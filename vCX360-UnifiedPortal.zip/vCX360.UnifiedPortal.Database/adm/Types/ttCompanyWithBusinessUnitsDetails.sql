﻿CREATE TYPE [adm].[ttCompanyWithBusinessUnitDetails] AS TABLE
(
	--Company
	CompanyId			INT			  NOT NULL,
	CompanyCID			NVARCHAR(64)  NOT NULL,
	CompanyName			NVARCHAR(128) NOT NULL,
	CompanyStatus		NVARCHAR(255) NOT NULL,
	CompanyDescription  NVARCHAR(512) NULL,
	[TenantId]			INT			  NULL,
	[OrgId]				NVARCHAR(64)  NULL,
	[IntegrationType]	INT			  NOT NULL,
	[IsDeleted]         BIT           NOT NULL,
	CompanyCreatedBy	NVARCHAR(255) NOT NULL,
	CompanyCreatedDate	DATETIME2(0)  NOT NULL,
	CompanyUpdatedBy	NVARCHAR(255) NULL,
	CompanyUpdatedDate	DATETIME2(0)  NULL,

	--BusinessUnit
	BuId				INT			  NULL,
	BuCID				NVARCHAR(64)  NULL,
	BuName				NVARCHAR(128) NULL,
	BuStatus			NVARCHAR(255) NULL,
	BuDescription		NVARCHAR(512) NULL,
	BuCreatedBy			NVARCHAR(255) NULL,
	BuCreatedDate		DATETIME2(0)  NULL,
	BuUpdatedBy			NVARCHAR(255) NULL,
	BuUpdatedDate		DATETIME2(0)  NULL,
	BuNumber			NVARCHAR(10)  NULL,
	Domain				NVARCHAR(64)  NULL,
	BUDomain			NVARCHAR(64)  NULL
)
