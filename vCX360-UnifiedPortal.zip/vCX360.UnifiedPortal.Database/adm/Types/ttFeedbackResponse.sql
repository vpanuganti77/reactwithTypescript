﻿
CREATE TYPE [adm].[ttFeedbackResponse] AS TABLE
(
	Id INT,
	FeedbackId		INT ,
	Response		VARCHAR(255) ,
	UserId			INT			 ,
	IsDeleted		BIT ,
	--audit info
	[CreatedBy]     NVARCHAR (256)  ,
	[CreatedDate]   DATETIME2 (0)	,
	[UpdatedBy]     NVARCHAR (256)  ,
	[UpdatedDate]   DATETIME2 (0)	

)
