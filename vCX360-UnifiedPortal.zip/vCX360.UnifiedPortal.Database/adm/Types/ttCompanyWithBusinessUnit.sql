﻿CREATE TYPE [adm].[ttCompanyWithBusinessUnit] AS TABLE
(
	--Company
	CompanyId			INT				NOT NULL,
	CompanyName			NVARCHAR(128)	NOT NULL,
	CompanyDescription  NVARCHAR(512)	NULL,
	Domain				NVARCHAR(64)	NOT NULL,
	--BusinessUnit
	BuId				INT				NULL,
	BuName				NVARCHAR(128)	NULL,
	BuDescription		NVARCHAR(512)	NULL,	
	BUDomain			NVARCHAR(64)	NOT NULL
)
