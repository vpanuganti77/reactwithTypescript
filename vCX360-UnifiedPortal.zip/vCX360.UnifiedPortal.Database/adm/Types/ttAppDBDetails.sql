﻿CREATE TYPE [adm].[ttAppDBDetails] AS TABLE
(
	[AppId]			  INT				NOT NULL ,
	[DBServer]		  NVARCHAR(256)		NOT NULL,
	[DBName]		  NVARCHAR(64)		NOT NULL,
	[UserId]		  NVARCHAR(100)		NOT NULL,
	[Pwd]			  NVARCHAR(25)		NULL,
	[ApplicationName] NVARCHAR(50)		NOT NULL,
	[Status]          NVARCHAR (24)		NOT NULL ,
	[Description]  	  NVARCHAR (MAX)	NULL,
	 
	 --audit info
	[CreatedBy]       NVARCHAR (256)    NOT NULL ,
	[CreatedDate]     DATETIME2 (0)		NOT NULL ,
	[UpdatedBy]       NVARCHAR (256)    NULL,
	[UpdatedDate]     DATETIME2 (0)	    NULL
)
