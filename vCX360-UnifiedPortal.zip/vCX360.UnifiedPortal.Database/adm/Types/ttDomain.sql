﻿CREATE TYPE [adm].[ttDomain] AS TABLE
(
	
    [Id]                        INT             NULL,
    [Name]                      NVARCHAR(512)   NOT NULL, 
    [Description]               NVARCHAR(256)   NULL,
    [LDAP]                      NVARCHAR(1024)  NOT NULL,
    [UserName]                  NVARCHAR(128)   NULL,
    [Password]                  NVARCHAR(1024)  NULL,
    [AllowsUserManagement]      BIT         NOT NULL DEFAULT 0,
    [TenantId]                  INT             NULL,
    [IsDeleted]                 BIT         NOT NULL DEFAULT 0,

    [CreatedBy]                 NVARCHAR (64)   NOT NULL ,
    [CreatedDate]               DATETIME2 (0)   NOT NULL ,
    [UpdatedBy]                 NVARCHAR (64)   NULL,
    [UpdatedDate]               DATETIME2 (0)   NULL
)
GO