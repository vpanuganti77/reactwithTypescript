﻿CREATE TYPE [adm].[ttBusinessUnit] AS TABLE
(
	[Id]						INT             NOT NULL,
    [CID]                       NVARCHAR (16)   NOT NULL,
    [Name]                      NVARCHAR (64)   NOT NULL,
    [Status]                    NVARCHAR (255)  NOT NULL ,
    [Description]               NVARCHAR (512)  NULL,
	[CompanyId]					INT             NOT NULL,
    [Number]                    NVARCHAR (10)   NULL,-- TBD
  	
	--[RowVersion]                ROWVERSION      NOT NULL,
    [Domain]                    NVARCHAR (64)   NULL,
    [DivisionId]                NVARCHAR (64)   NULL,
    [DivisionName]              NVARCHAR (64)   NULL,
    [OAClientId]                INT NULL,
    [TimeZone]                  NVARCHAR (150)   NULL,
    [IsDeleted]                 BIT ,

    --audit info
	[CreatedBy]                 NVARCHAR (256)  NOT NULL ,
    [CreatedDate]               DATETIME2 (0)	NOT NULL ,
    [UpdatedBy]                 NVARCHAR (256)  NULL,
    [UpdatedDate]               DATETIME2 (0)	NULL
)
