﻿CREATE TYPE [adm].[ttCompany] AS TABLE
(
	[Id]                  INT				 NOT NULL  ,
    [CID]                 NVARCHAR (16)      NOT NULL,
    [Name]                NVARCHAR (64)      NOT NULL,
    [Status]              NVARCHAR (255)     NOT NULL,
    [Description]         NVARCHAR (512)     NULL,   
  
	--[RowVersion]          ROWVERSION         NOT NULL,
    [Domain]              NVARCHAR (64)      NOT NULL ,
    [TenantId]            INT                NULL,
    [OrgId]               NVARCHAR (64)      NULL ,  
 --   [PurchaseSource]      NVARCHAR(128)      NULL,
	--[GCAppVersion]        NVARCHAR(16)       NULL, 
 --   [OACStatus]           BIT                NOT NULL ,
 --   IsProvisionNewBU      BIT                NOT NULL ,
    [CoOAClientId]        INT                NULL,
    [IsDeleted]           BIT                 ,
    [IntegrationType]     INT                 ,
     --audit info
    [CreatedBy]           NVARCHAR (256)     NOT NULL,
    [CreatedDate]         DATETIME2 (0)		 NOT NULL ,
    [UpdatedBy]           NVARCHAR (256)     NULL,
    [UpdatedDate]         DATETIME2 (0)	     NULL
)
