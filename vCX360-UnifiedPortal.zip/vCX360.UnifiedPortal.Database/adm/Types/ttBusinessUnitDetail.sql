﻿CREATE TYPE [adm].[ttBusinessUnitDetail] AS TABLE
(
	Id				INT				NOT NULL,
	CID				NVARCHAR(64)	NOT NULL,
	[Name]			NVARCHAR(64)	NOT NULL,
	[Status]		NVARCHAR(255)	NOT NULL,
	[Description]	NVARCHAR(512)	NULL,	
	CompanyId		INT				NOT NULL,
	BuNumber		NVARCHAR(10)	NOT NULL,
	CompanyName		NVARCHAR (128)  NOT NULL,
	Domain			NVARCHAR(64)	NOT NULL,
	[IsDeleted]     BIT,

	CreatedBy		NVARCHAR(256)   NOT NULL,
	CreatedDate		DATETIME2(0)	NOT NULL,
	UpdatedBy		NVARCHAR(256)	NULL,
	UpdatedDate		DATETIME2(0)	NULL
)
