﻿CREATE PROCEDURE [adm].[spDeleteOAClient]
	@Ids dbo.ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS

declare @result dbo.StProcResult;
	set XACT_ABORT on;

	--validate OAClient Ids
	if exists (select id from @Ids except select id from [adm].[OAClient])
	throw 51000, 'ERROR-DELETE-OAClient-Invalid OAClient Ids', 1;


	if exists (select id From adm.BusinessUnit where OAClientId in 
    (Select id from @Ids))
    throw 51000, 'ERROR- Cannot delete the Authorization Client because it is being used for BusinessUnit !', 1;

	--Transaction starts here
	declare @TranName nvarchar(20) = N'DeleteOAClientTx';
	begin transaction @TranName;


	delete from [adm].OAClient 
	output cast(0 as bit), deleted.Id, N'[adm].[OAClient]' into @result
	where Id in (select id from @Ids);

	--success
	commit transaction @TranName
	select * from @result;
	return;
RETURN 0
go
exec sp_addextendedproperty @name =
	N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spDeleteOAClient',
    @level2type = NULL,
    @level2name = NULL