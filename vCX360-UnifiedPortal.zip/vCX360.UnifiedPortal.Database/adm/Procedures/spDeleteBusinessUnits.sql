﻿CREATE PROCEDURE [adm].[spDeleteBusinessUnits]
	@Ids [dbo].ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS
	
	declare @result [dbo].StProcResult;
	set XACT_ABORT ON;
	
	--validate Business Unit Ids
	if exists (select id from @Ids except select id from [adm].[BusinessUnit])
	throw 51000, 'ERROR-DELETE-BUSINESSUNIT-Invalid Business Unit Ids', 1;

	declare @coIds [dbo].ttIntValue;
	insert into @coIds
	select distinct CompanyId from [adm].BusinessUnit bu
	join @Ids bi on bi.Id = bu.Id;

	--case a: mulitple companies returned above and user is NOT a SysADmin -> unauthorized
	if (select count(Id) from @coIds) > 1 --must be a sysAdmin
	and not exists (select 1 from [adm].[IsSysAdmin]())
	throw 51000, N'ERROR-DELETE-BUSINESSUNIT-UNAUTHORIZED The user is not a Sys Admin to delete multiple BUs across multiple companies', 1;

	--case b: single company returned above and user is NOT a SysAdmin OR Enterprise Admin for that company -> unauthorized
	if (select count(Id) from @coIds) = 1 
	and not exists (select 1 from [adm].[IsEnterpriseAdminForCompany]((select top(1) Id from @coIds)))
	throw 51000, N'ERROR-DELETE-BUSINESSUNIT-UNAUTHORIZED The user is not a Sys Admin or an Enterprise Admin to delete BUs', 1;


	declare @t [dbo].ttIntStringTuple;
	insert into @t
	select Id, 'BUSINESSUNIT' from @Ids;

	--Transaction starts here
	DECLARE @TranName NVARCHAR(20) = N'DeleteBusinessUnitsTx'; 
 	BEGIN TRANSACTION @TranName; 

	update adm.BusinessUnit set IsDeleted = 1, Status = 'Inactive', UpdatedBy = @userName, UpdatedDate = GETDATE()
	output cast(0 as bit), deleted.Id, N'[adm].[BusinessUnit]' into @result
	where Id in (select id from @Ids)

	--success
	commit transaction @TranName
	select * from @result;
	return; 

RETURN 0

go
exec sp_addextendedproperty @name =
	N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spDeleteBusinessUnits',
    @level2type = NULL,
    @level2name = NULL
