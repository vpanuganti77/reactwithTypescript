﻿CREATE PROCEDURE [adm].[spDeleteDomain]
	@Ids [dbo].[ttIntValue] Readonly
As

DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'DeleteDomainTx'; 
 	BEGIN TRANSACTION @TranName; 

	delete from  [adm].[Domain] 
	Output CAST (0 as bit),deleted.Id, N'[adm].[Domain]' into @result
	where Id in (Select Id from @Ids)

	--On Success
	Commit Transaction @TranName;
	Select * From @result;
	Return;

RETURN 0;
GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spDeleteDomain'
    