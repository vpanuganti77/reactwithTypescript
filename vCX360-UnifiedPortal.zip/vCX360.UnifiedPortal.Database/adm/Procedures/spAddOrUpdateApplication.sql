﻿CREATE PROCEDURE [adm].[spAddOrUpdateApplication]
(
	@ttApplication AS [adm].[ttApplication] READONLY
)
AS
DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'InsertApplicationTx'; 
 	BEGIN TRANSACTION @TranName; 

	DECLARE @name NVARCHAR(50),	@id int

	SELECT @name = [Name], @id = Id from @ttApplication

	IF (exists (SELECT * FROM [adm].[Application]
	WHERE [Id] = @id and (@id is null or @id <> Id) ))
	THROW 51000, 'ERROR-INSERT-Application - Id already exists', 1;
	
	IF (exists (SELECT * FROM [adm].[Application] 
	WHERE [Name] = @name and (@id is null or @id <> Id) ))
	THROW 51000, 'ERROR-INSERT-Application - Name already exists', 1;

	DECLARE @insertedAppIds [dbo].ttIntValue;

	MERGE [adm].[Application] AS t
    USING @ttApplication AS s
    ON (t.[Id] = s.[Id])
    WHEN NOT MATCHED BY TARGET THEN
        INSERT ([CID],
				[Name],
				[Type],
				[Icon],
				[OverviewURL],
				[Overview],
				[Status],
				[Description],
				[SuiteId],
				[IsDeleted],
				[CreatedBy],
				[CreatedDate])
        VALUES (s.[CID],
				s.[Name],
				s.[Type],
				s.[Icon],
				s.[OverviewURL],
				s.[Overview],
				s.[Status],
				s.[Description],
				s.[SuiteId],
				s.[IsDeleted], 
				s.[CreatedBy],
				s.[CreatedDate])
    WHEN MATCHED THEN
        UPDATE SET
            t.[CID] = s.[CID],
            t.[Name] = s.[Name],
			t.[Type] = s.[Type],
			t.[Icon] = s.[Icon],
			t.[OverviewURL] = s.[OverviewURL],
			t.[Overview] = s.[Overview],
            t.[Status] = s.[Status],
            t.[Description] = s.[Description],
            t.[SuiteId] = s.[SuiteId],
			t.[IsDeleted] = s.[IsDeleted],
            t.[UpdatedBy] = s.[UpdatedBy],
            t.[UpdatedDate] = GETDATE()
		Output inserted.Id into @insertedAppIds;
		
	Insert into @result
	SELECT
		CAST (0 as bit),
		Id,
		N'[adm].[Application]'
	From
		@insertedAppIds;
	--On Success
	Commit Transaction @TranName;
	SELECT * From @result;
	Return;
RETURN 0;
GO

EXEC sys.sp_addextendedproperty 
@name=N'DM_RecordType', 
@value=N'[dbo].[StProcResult]' ,
@level0type=N'SCHEMA',
@level0name=N'adm',
@level1type=N'PROCEDURE',
@level1name=N'spAddOrUpdateApplication'

	
	
