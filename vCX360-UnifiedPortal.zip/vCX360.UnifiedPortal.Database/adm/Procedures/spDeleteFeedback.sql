﻿
CREATE PROCEDURE [adm].[spDeleteFeedback]
	@Ids dbo.ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS

declare @result dbo.StProcResult;
	set XACT_ABORT on;

	--validate Tenant Ids
	if exists (select id from @Ids except select Id from [adm].[Feedback])
	throw 51000, 'ERROR-DELETE-Feedback-Invalid Feedback Ids', 1;

	--Transaction starts here
	declare @TranName nvarchar(20) = N'DeleteFeedbackTx';
	begin transaction @TranName;

	delete from [adm].[Feedback] 
	output cast(0 as bit), deleted.Id, N'[adm].[Feedback]' into @result
	where Id in (select id from @Ids);

	--success
	commit transaction @TranName
	select * from @result;
	return;
RETURN 0


EXEC sys.sp_addextendedproperty @name=N'DM_RecordType',
@value=N'[dbo].[StProcResult]' ,
@level0type=N'SCHEMA',
@level0name=N'adm',
@level1type=N'PROCEDURE',
@level1name=N'spDeleteFeedback'
