﻿CREATE PROCEDURE [adm].[spUpdateBusinessUnit]
	@buId int,
	@cid nvarchar(64), --this is the CID, not the company ID
	@buName nvarchar(64),
	@status nvarchar(255),
	@desc nvarchar(512) = NULL,
	@domain nvarchar(64),
	@userName nvarchar(256) = N'AdminPortal',
	@buNumber nvarchar(10)
AS
	
	declare @result [dbo].StProcResult;

	set XACT_ABORT on;

	--Validate Business Unit exists
	if ([adm].[IsBusinessUnitIdValid] (@buId) = 0)
	throw 51000, N'ERROR-UPDATE-BUSINESSUNIT-Invalid Business Unit Id', 1;

	--validate name (must be unique for a given company)
	if (exists (select * from [adm].[BusinessUnit] where [Name] = @buName  and [ID] <> @buid and [CompanyId] = (select top(1) CompanyId from [adm].BusinessUnit where id = @buId)))
	throw 51000, N'ERROR-UPDATE-BUSINESSUNIT-Name already exists (within the parent company)', 1;

	--validate CID (must be unique across all BUs - but since this is an update, must make sure we are not finding the CID for THIS BU that we are trying to update)
	if (exists (select * from [adm].[BusinessUnit] where [CID] = @cid AND [Id] <> @buId))
	throw 51000, N'ERROR-UPDATE-BUSINESSUNIT-CID for business units already exists', 1;

	--validate CID length
	if (len(@cid) < 2 OR len(@cid) > 64)
	throw 51000, N'ERROR-UPDATE-BUSINESSUNIT-CID for business units is not the correct length (2..64)', 1;

	declare @TranName nvarchar(20) = N'UpdateBusinessUnitTx';
	begin transaction @TranName;

	--previous cid for busnessid
	declare @bucid nvarchar = (select top(1) CID from [adm].[BusinessUnit] where Id = @buId);

	update [adm].[BusinessUnit]
	set
		CID = @cid,
		[Name] = @buName,
		[Status] = @status,
		[Description] = @desc,
		[Domain] = @domain,
		UpdatedBy = @userName,
		UpdatedDate = CURRENT_TIMESTAMP,
		Number = @buNumber
	where
		Id = @buId;

	insert into @result
	values
		(cast(0 as bit),
		@buId,
		N'[adm].[BusinessUnit]'
		);

		--cid is changed
		if @bucid <> @cid
		begin
		-- update role name
		 exec [adm].[spUpdateBusinessUnitRoles] @buId,@cid,@bucid,@userName
		end

	--sucess
	COMMIT TRANSACTION @TranName; 

 	SELECT * from @result; 
 	RETURN; 

RETURN 0;

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spUpdateBusinessUnit',
    @level2type = NULL,
    @level2name = NULL
