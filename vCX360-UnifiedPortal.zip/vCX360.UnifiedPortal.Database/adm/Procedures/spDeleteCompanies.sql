﻿CREATE PROCEDURE [adm].[spDeleteCompanies]
	@ids [dbo].ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS
	declare @result [dbo].StProcResult;
	set XACT_ABORT ON;
	
	--validate Company Ids
	if exists (select id from @ids except select id from [adm].[Company])
	throw 51000, 'ERROR-DELETE-COMPANIES-Invalid Company Ids', 1;

	--this check is needed, because for the Enterprise Admin, the company ID (about to be deleted) is valid. But EAs are not allowed to delete their own company. Only sys admins are.
	if not exists (select 1 from [adm].[IsSysAdmin]())
	throw 51000, N'ERROR-DELETE-COMPANY-UNAUTHORIZED The user is not a Sys Admin. Only Sys Admins can delete Companies', 1; 

	declare @t [dbo].ttIntStringTuple;
	insert into @t
	select Id, 'COMPANY' from @ids;	

	--Transaction starts here
	DECLARE @TranName NVARCHAR(20) = N'DeleteCompaniesTx'; 
 	BEGIN TRANSACTION @TranName; 

	Update [adm].[Company] Set IsDeleted = 1, Status = 'Inactive', UpdatedBy = @userName, UpdatedDate = GETDATE()
	output cast(0 as bit), deleted.Id, N'[adm].[Company]' into @result
	Where Id in (select id from @ids);
	
	--success
	commit transaction @TranName
	select * from @result;
	return;

RETURN 0

go
exec sp_addextendedproperty @name =
	N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spDeleteCompanies',
    @level2type = NULL,
    @level2name = NULL