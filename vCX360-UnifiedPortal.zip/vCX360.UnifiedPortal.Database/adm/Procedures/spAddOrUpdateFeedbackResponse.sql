﻿CREATE PROCEDURE [adm].[spAddOrUpdateFeedbackResponse]
(
	@ttFeedbackResponse AS [adm].[ttFeedbackResponse] READONLY
)
AS

	DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'InsertFeedbackResponseTx'; 
 	BEGIN TRANSACTION @TranName;
	DECLARE @insertedFeedbackResponseIds [dbo].ttIntValue;

	MERGE [adm].[FeedbackResponse] AS t
    USING @ttFeedbackResponse AS s
    ON (t.Id = s.Id)
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (
				[FeedbackId],
				[Response],
				[UserId],
				[IsDeleted],
				[CreatedBy],
				[CreatedDate])
        VALUES ( 
				s.[FeedbackId],
				s.[Response],
				s.[UserId],
				s.[IsDeleted],
				s.[CreatedBy],
				GETDATE())
    WHEN MATCHED THEN
        UPDATE SET
			t.[FeedbackId] = s.[FeedbackId],
			t.[Response] = s.[Response],
			t.[UserId] = s.[UserId],
			t.[IsDeleted] = s.[IsDeleted],
            t.[UpdatedBy] = s.[UpdatedBy],
            t.[UpdatedDate] = GETDATE()
		Output inserted.Id into @insertedFeedbackResponseIds;
		
	Insert into @result
	SELECT
		CAST (0 as bit),
		Id,
		N'[adm].[FeedbackResponse]'
	From
		@insertedFeedbackResponseIds;
	--On Success
	Commit Transaction @TranName;
	SELECT * From @result;
	Return;
RETURN 0;

EXEC sys.sp_addextendedproperty 
@name=N'DM_RecordType', 
@value=N'[dbo].[StProcResult]' ,
@level0type=N'SCHEMA',
@level0name=N'adm',
@level1type=N'PROCEDURE',
@level1name=N'spAddOrUpdateFeedbackResponse'
