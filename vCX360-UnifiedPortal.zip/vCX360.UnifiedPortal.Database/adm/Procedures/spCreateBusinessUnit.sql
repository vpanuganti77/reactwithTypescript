﻿CREATE PROCEDURE [adm].[spCreateBusinessUnit]
	@companyId int,
	@cid nvarchar(16),
	@name nvarchar(64),
	@status nvarchar(255),
	@description nvarchar(512) = NULL,
	@domain nvarchar(64),
	@userName nvarchar(256) = N'AdminPortal',
	@buNumber nvarchar(10),
	@divisionId NVARCHAR (64)   NULL,
	@divisionName NVARCHAR (64)   NULL,
	@oAClientId INT  NULL,
	@timeZone  NVARCHAR (150),
	@agentEntityKVPName VARCHAR(100) NULL
AS
	
	Declare @result dbo.StProcResult;

	Set XACT_ABORT ON;

	--Validate Company Id
	If(not exists(
		Select id
		From adm.Company
		Where id = @companyId
		))
	Throw 51000, N'ERROR-INSERT-BUSINESSUNIT-Invalid Company Id', 1;

	--validate name (must be unique for a given company)
	if (exists (select * from [adm].[BusinessUnit] where [Name] = @name and CompanyId = @companyId))
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-Name already exists (within the parent company)', 1;

		--validate CID (must be unique across all BUs)
	if (exists (select * from [adm].[BusinessUnit] where [CID] = @cid))
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-CID for business units already exists', 1;

	--validate CID length
	if (len(@cid) < 2 OR len(@cid) > 16)
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-CID for business units is not the correct length (2..16)', 1;

	if (Isnull(@oAClientId,0) != 0 and exists (select * From adm.BusinessUnit where [OAClientId] =  @oAClientId And CompanyId != @companyId))
      throw 51000, 'ERROR-INSERT-BUSINESSUNIT-Authorization Client for other company''s business units already exists', 1;

	

	if ((Isnull(@oAClientId,-1) = -1 And (Select Isnull(CoOAClientId,0) from adm.Company where id = @companyId) = 0))
      throw 51000, 'ERROR-INSERT-BUSINESSUNIT-Authorization Client can not be empty. 
                   Unless authorization client is set in the company.', 1;

	if (Isnull(@oAClientId,-1) != -1 and exists (select * From adm.Company where [CoOAClientId] =  @oAClientId And Id != @companyId))
    throw 51000, 'ERROR-INSERT-BUSINESSUNIT-Authorization Client Mapped to other company', 1;


	Declare @TranName nvarchar(20) = N'InsertBusinessUnitTx';
	Begin Transaction @TranName;

	--Create Business Unit
	Declare @insertedBusinessUnitIds [dbo].ttIntValue;

	Insert into adm.BusinessUnit(
		CID,
		[Name],
		[Status],
		[Description],
		[Domain],
		CreatedBy,
		CreatedDate,
		CompanyId,
		Number,
		DivisionId,
		DivisionName,
		OAClientId,
		TimeZone
	)
	Output inserted.Id into @insertedBusinessUnitIds --Ids of inserted BUs
	Values(
		@cid,
		@name,
		@status,
		@description,
		@domain,
		@userName,
		CURRENT_TIMESTAMP,
		@companyId,
		@buNumber,
		@divisionId,
		@divisionName,
		@oAClientId,
		@timeZone
	);

	Insert into @result
	Select
		CAST (0 as bit),
		Id,
		N'[adm].[BusinessUnit]'
	From
		@insertedBusinessUnitIds;


	declare @busnessunitId int = (select top(1) id from @insertedBusinessUnitIds);
	--Create roles for business unit and map newly created roles to busnessunit

	Exec [spCreateBusinessUnitRoles] @busnessunitId, @cid, @userName 
	
	--add the default (None) licensed feature, to enable some level of access
declare @buFeatIds ttIntIntTuple;
insert into @buFeatIds
values (@busnessunitId, 0);

if @busnessunitId is not null
begin
	
			declare @tmp1 table (coId int, buId int, featId int);
			insert into @tmp1 -- so that the output does not affect the expected result from THIS st proc
			Exec [sec].[spSetupLicensedFeatures] @buFeatIds, 0;
		
end;

	--On Success
	Commit Transaction @TranName;

	
	Return;

RETURN 0

Go
Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spCreateBusinessUnit',
    @level2type = NULL,
    @level2name = NULL
