﻿CREATE PROCEDURE [adm].[spAddOrUpdateAppDBDetails]
(
	@ttAppDBDetails AS [adm].[ttAppDBDetails] READONLY
)
AS
DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'InsertAppDBDetailsTx'; 
 	BEGIN TRANSACTION @TranName; 

	
	DECLARE @insertedAppIds [dbo].ttIntValue;

	MERGE [adm].[AppDBDetails] AS t
    USING @ttAppDBDetails AS s
    ON (t.[AppId] = s.[AppId])
    WHEN NOT MATCHED BY TARGET THEN
        INSERT ( [AppId],
				[DBServer],		 
				 [DBName]	,	 
				 [UserId],		 
				 [Pwd]	,		 
				 [ApplicationName],
				 [Status],
				 [Description],
				 [CreatedBy],
				 [CreatedDate])
        VALUES (s.[AppId],
				s.[DBServer],		
				s.[DBName]	,	 
				s.[UserId],		 
				s.[Pwd]	,		 
				s.[ApplicationName],
				s.[Status],
				s.[Description],
				s.[CreatedBy],
				s.[CreatedDate])
				
    WHEN MATCHED THEN
        UPDATE SET
			t.[AppId]			= s.[AppId],
            t.[DBServer]		= s.[DBServer],
            t.[DBName]			= s.[DBName],
			t.[UserId]			= s.[UserId],
			t.[Pwd]				= s.[Pwd],
			t.[ApplicationName] = s.[ApplicationName],
            t.[Status]			= s.[Status],
            t.[Description]		= s.[Description],
            t.[UpdatedBy]		= s.[UpdatedBy],
            t.[UpdatedDate]		= GETDATE()
		Output inserted.AppId into @insertedAppIds;
		
	Insert into @result
	SELECT
		CAST (0 as bit),
		Id,
		N'[adm].[AppDBDetails]'
	From
		@insertedAppIds;
	--On Success
	Commit Transaction @TranName;
	SELECT * From @result;
	Return;
RETURN 0;

go

EXEC sys.sp_addextendedproperty 
@name=N'DM_RecordType', 
@value=N'[dbo].[StProcResult]' ,
@level0type=N'SCHEMA',
@level0name=N'adm',
@level1type=N'PROCEDURE',
@level1name=N'spAddOrUpdateAppDBDetails'

	