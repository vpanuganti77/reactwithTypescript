﻿CREATE PROCEDURE [adm].[spAddOrUpdateFeedback]
(
	@ttFeedback AS [adm].[ttFeedback] READONLY
)
AS

	DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'InsertFeedbackTx'; 
 	BEGIN TRANSACTION @TranName;
	DECLARE @insertedFeedbackIds [dbo].ttIntValue;

	MERGE [adm].[Feedback] AS t
    USING @ttFeedback AS s
    ON (t.Id = s.Id)
    WHEN NOT MATCHED BY TARGET THEN
        INSERT ([FeedbackType], 
				[ApplicationId],
				[ApplicationType],
				[Message],
				[Attachment],
				[Status],
				[IsDeleted],
				[CreatedBy],
				[CreatedDate])
        VALUES (s.[FeedbackType],
				s.[ApplicationId],
				s.[ApplicationType],
				s.[Message],
				s.[Attachment],
				s.[Status],
				s.[IsDeleted],
				s.[CreatedBy],
				GETDATE())
    WHEN MATCHED THEN
        UPDATE SET
            t.[FeedbackType] = s.[FeedbackType],
			t.[ApplicationId] = s.[ApplicationId],
			t.[ApplicationType] = s.[ApplicationType],
			t.[Message] = s.[Message],
			t.[Attachment] = s.[Attachment],
			t.[Status] = s.[Status],
			t.[IsDeleted] = s.[IsDeleted],
            t.[UpdatedBy] = s.[UpdatedBy],
            t.[UpdatedDate] = GETDATE()
		Output inserted.Id into @insertedFeedbackIds;
		
	Insert into @result
	SELECT
		CAST (0 as bit),
		Id,
		N'[adm].[Feedback]'
	From
		@insertedFeedbackIds;
	--On Success
	Commit Transaction @TranName;
	SELECT * From @result;
	Return;
RETURN 0;

EXEC sys.sp_addextendedproperty 
@name=N'DM_RecordType', 
@value=N'[dbo].[StProcResult]' ,
@level0type=N'SCHEMA',
@level0name=N'adm',
@level1type=N'PROCEDURE',
@level1name=N'spAddOrUpdateFeedback'
