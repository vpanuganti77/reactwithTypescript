﻿
CREATE PROCEDURE [adm].[spAddOrUpdateBusinessUnit]
	@ttBusinessUnit AS [adm].[ttBusinessUnit] READONLY,
	@userName nvarchar(256) = N'AdminPortal'
AS
	Declare @result [dbo].StProcResult;

	Set XACT_ABORT ON;
	declare @isInsert int = 0

	if exists( Select id from @ttBusinessUnit where id in (select Id from [adm].[BusinessUnit]))
		set @isInsert = 1
	--Validate Company Id
	If(not exists(
		Select c.Id
		From [adm].Company c JOIN @ttBusinessUnit t
		ON c.[Id] = t.[CompanyId]
		))
	Throw 51000, N'ERROR-INSERT-BUSINESSUNIT-Invalid Company Id', 1;

	--validate name (must be unique for a given company)
	if (exists (select * from [adm].[BusinessUnit] b JOIN @ttBusinessUnit t
	ON b.[Name] = t.[Name] and b.[CompanyId] = t.[CompanyId] where (t.id is null or t.id <> b.Id) ))
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-Name already exists (within the parent company)', 1;

	if exists (select * from @ttBusinessUnit where len(CID) < 2 and len(CID) > 64)
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-CID for business units is not the correct length (2..64)', 1;

	--validate if user (APP_NAME()) is SysAdmin or EAdmin for given company ID
	DECLARE @companyId int;
	SELECT TOP(1) @companyId = CompanyId FROM @ttBusinessUnit;

	if not exists (select 1 from [adm].[IsEnterpriseAdminForCompany](@companyId))
	throw 51000, N'ERROR-INSERT-BUSINESSUNIT-UNAUTHORIZED The user is not a Sys Admin or an Enterprise Admin for this company to create BUs', 1;


	Declare @TranName nvarchar(20) = N'InsertBusinessUnitTx';
	Begin Transaction @TranName;

	--Create Business Unit
	Declare @insertedBusinessUnitIds [dbo].ttIntValue;

	MERGE [adm].[BusinessUnit] AS t
    USING @ttBusinessUnit AS s
    ON (t.[Id] = s.[Id])
    WHEN NOT MATCHED BY TARGET THEN
	
        INSERT
			([CID]         , 
			[Name]         ,
			[Status]       ,
			[Description]  ,
			[CompanyId]	   ,
			[Number]       ,
			[Domain]       ,
			[IsDeleted]    ,
			[CreatedBy]    )
			
	VALUES
	      (	s.[CID]         , 
			s.[Name]         ,
			s.[Status]       ,
			s.[Description]  ,
			s.[CompanyId]	 ,
			s.[Number]       ,
			s.[Domain]       ,
			s.[IsDeleted]    ,
			s.[CreatedBy]    )
			
	WHEN MATCHED THEN
        UPDATE SET
			t.[CID]			 =	s.[CID]         , 
			t.[Name]         =	s.[Name]         ,
			t.[Status]       =	s.[Status]       ,
			t.[Description]  =	s.[Description]  ,
			t.[CompanyId]	 =	s.[CompanyId]	 ,
			t.[Number]       =	s.[Number]       ,
			t.[Domain]       =	s.[Domain]       ,
			t.[IsDeleted]    =	s.[IsDeleted]    ,
			t.[UpdatedBy]    =	s.[UpdatedBy]    ,
			t.[UpdatedDate]  =	GETDATE()
Output inserted.Id into @insertedBusinessUnitIds;

	if(@isInsert=0)
	begin
		DECLARE @busnessunitId int;
		SELECT TOP(1) @busnessunitId = Id FROM @insertedBusinessUnitIds;

		DECLARE @cocid nvarchar(128);
		SELECT TOP(1) @cocid = CID FROM [adm].[Company] WHERE Id = @companyId;

		DECLARE @cid nvarchar(16);
		SELECT TOP(1) @cid = CID FROM @ttBusinessUnit;

		-- Create roles for business unit and map newly created roles to busnessunit
		declare @roleName nvarchar (512) = (select @cocid + '_' + @cid);
		Exec [dbo].[spCreateBusinessUnitRoles] @busnessunitId, @roleName, @userName ;
	end
	

	Insert into @result
	Select
		CAST (0 as bit),
		Id,
		N'[adm].[BusinessUnit]'
	From
		@insertedBusinessUnitIds;

		--On Success
	Commit Transaction @TranName;

	Select * From @result;
	Return;

RETURN 0
Go
Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spAddOrUpdateBusinessUnit',
    @level2type = NULL,
    @level2name = NULL