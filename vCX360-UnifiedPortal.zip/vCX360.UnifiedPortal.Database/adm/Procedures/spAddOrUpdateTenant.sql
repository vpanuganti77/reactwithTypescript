﻿
CREATE PROCEDURE [adm].[spAddOrUpdateTenant]
(
	@ttTenant AS [adm].[ttTenant] READONLY
)
AS

	DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'InsertTenantTx'; 
 	BEGIN TRANSACTION @TranName;
	DECLARE @insertedTenantIds [dbo].ttIntValue;

	MERGE [adm].[Tenant] AS t
    USING @ttTenant AS s
    ON (t.[TenantId] = s.[TenantId])
    WHEN NOT MATCHED BY TARGET THEN
        INSERT ([TenantCID],
				[TenantName],
				[ParentTenantId],
				[PlatformId],
				[ConnectionString],
				[Description] ,    
				[Contact],
				[IsDeleted],
				[CreatedBy],
				[CreatedDate])
        VALUES (s.[TenantCID],
				s.[TenantName],
				s.[ParentTenantId],
				s.[PlatformId],
				s.[ConnectionString],
				s.[Description],
				s.[Contact],
				s.[IsDeleted],
				s.[CreatedBy], GETDATE())
    WHEN MATCHED THEN
        UPDATE SET
			t.[TenantCID]		 = s.[TenantCID],
            t.[TenantName]	     = s.[TenantName],
			t.[ParentTenantId]   = s.[ParentTenantId],
			t.[PlatformId]	     = s.[PlatformId],
			t.[ConnectionString] = s.[ConnectionString],
			t.[Description]      = s.[Description],
			t.[Contact]		     = s.[Contact],
			t.[IsDeleted]	     = s.[IsDeleted],
            t.[UpdatedBy]	     = s.[UpdatedBy],
            t.[UpdatedDate]      = GETDATE()
		Output inserted.TenantId into @insertedTenantIds;
		
	Insert into @result
	SELECT
		CAST (0 as bit),
		Id,
		N'[adm].[Tenant]'
	From
		@insertedTenantIds;
	--On Success
	Commit Transaction @TranName;
	SELECT * From @result;
	Return;
RETURN 0;

EXEC sys.sp_addextendedproperty 
@name=N'DM_RecordType', 
@value=N'[dbo].[StProcResult]' ,
@level0type=N'SCHEMA',
@level0name=N'adm',
@level1type=N'PROCEDURE',
@level1name=N'spAddOrUpdateTenant'
