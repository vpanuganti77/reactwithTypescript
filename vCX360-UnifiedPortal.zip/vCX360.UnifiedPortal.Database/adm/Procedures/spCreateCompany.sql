﻿CREATE PROCEDURE [adm].[spCreateCompany]
	@cid nvarchar(16),
	@name nvarchar(64),
	@status nvarchar(255),
	@description nvarchar(512) = NULL,
	@domain nvarchar(64),
	@userName nvarchar(256) = N'AdminPortal',
	@Tenant INT  NULL,
	@orgId  NVARCHAR (64) NULL,
	@purchaseSource NVARCHAR(128) NULL,
	@gcAppVersion NVARCHAR(16) NULL,
	@oacStatus	BIT = 0,
	@IsProvisionNewBU BIT=1,
	@CoOAClientId INT

AS
	
	Declare @result dbo.StProcResult;

	Set XACT_ABORT ON;

	--validate name (must be unique)
	if (exists (select * from [adm].[Company] where [Name] = @name))
	throw 51000, 'ERROR-CO101-INSERT-COMPANY-Name already exists', 1;

	--validate name - Domain (must be unique)
	if (exists (select * from [adm].[Company] where [Name] = @name and [Domain] = @domain))
	throw 51000, 'ERROR-CO102-INSERT-COMPANY-Name-Domain already exists', 1;

	--validate CID (must be unique across all companies)
	if (exists (select * from [adm].[Company] where [CID] = @cid))
	throw 51000, 'ERROR-CO103-INSERT-COMPANY-CID for companies already exists', 1;	

	--if (Isnull(@CoOAClientId,0) != 0 and exists (select * From  [adm].BusinessUnit where OAClientId =  @CoOAClientId))
	--throw 51000, 'ERROR-INSERT-Authorization Client already Mapped to other company''s Businessunit', 1;

	----validate name - OrgId (must be unique)
 --   if (exists (select * from [adm].[Company] where [OrgId] = @orgId))
 --   throw 51000, 'ERROR-CO104-INSERT-COMPANY-Organization ID already exists', 1;
	
	--if (Isnull(@CoOAClientId,-1) != -1 and exists (select * From  [adm].[Company] where CoOAClientId =  @CoOAClientId))
 --   throw 51000, 'ERROR-INSERT-COMPANY-Authorization Client already exists', 1;

	--validate CID length
	if (len(@cid) < 2 OR len(@cid) > 16)
	throw 51000, 'ERROR-CO105-INSERT-COMPANY-CID for companies is not the correct length (2..16)', 1;

	--if not exists (select 1 from [sec].[IsSysAdmin]())
	--throw 51000, N'ERROR-CO106-INSERT-COMPANY-UNAUTHORIZED The user is not a Sys Admin. Only Sys Admins can create Companies', 1; 

	Declare @TranName nvarchar(20) = N'InsertCompanyTx';
	Begin Transaction @TranName;

	--Create Customer
	Declare @insertedCompanyIds [dbo].ttIntValue;

	Insert into [adm].[Company](
		CID,
		[Name],
		[Status],
		[Description],
		[Domain],
		TenantId,
		OrgId,
		PurchaseSource,
		GCAppVersion,
		OACStatus,
		IsProvisionNewBU,
		CoOAClientId,
		CreatedBy,
		CreatedDate
		
	)
	Output inserted.Id into @insertedCompanyIds --Ids of inserted companies
	Values(
		@cid,
		@name,
		@status,
		@description,
		@domain,
		@Tenant,
		@orgId,
		@purchaseSource,
		@gcAppVersion,
		@oacStatus,
		@IsProvisionNewBU,
		@CoOAClientId,
		@userName,
		CURRENT_TIMESTAMP
	);

	Insert into @result
	Select
		CAST (0 as bit),
		Id,
		N'[adm].[Company]'
	From
		@insertedCompanyIds;

	--declare @coId int = (select top(1) Id from @insertedCompanyIds);
	declare @companyIds  dbo.ttIntValue,
			@companyCids  dbo.ttString 

			insert into @companyIds
			select top(1) Id from @insertedCompanyIds;
			insert into @companyCids values(@cid);
		
declare @coId int = (select top(1) Id from @insertedCompanyIds);
EXEC [dbo].[spCreateEnterpriseAdminRole] @coId, @cid, @userName; --add EAdmin role/custom role and permission

	--On Success
	Commit Transaction @TranName;

	Select * From @result;
	Return;

RETURN 0

Go
Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spCreateCompany',
    @level2type = NULL,
    @level2name = NULL
