﻿CREATE PROCEDURE [adm].[spPurgingCompanies]
	@companyIds dbo.ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS
	declare @result [dbo].StProcResult;
	set XACT_ABORT ON;
	
	--validate Company Ids
	if exists (select id from @companyIds except select id from [adm].[Company])
	throw 51000, 'ERROR-DELETE-COMPANIES-Invalid Company Ids', 1;

	--this check is needed, because for the Enterprise Admin, the company ID (about to be deleted) is valid. But EAs are not allowed to delete their own company. Only sys admins are.
	if not exists (select 1 from [adm].[IsSysAdmin]())
	throw 51000, N'ERROR-DELETE-COMPANY-UNAUTHORIZED The user is not a Sys Admin. Only Sys Admins can delete Companies', 1; 

	declare @t [dbo].ttIntStringTuple;
	insert into @t
	select Id, 'COMPANY' from @companyIds;	

	--Transaction starts here
	DECLARE @TranName NVARCHAR(20) = N'DeleteCompaniesTx'; 
 	BEGIN TRANSACTION @TranName; 

	--delete some child elements related to scheduling (to avoid cycles with cascading deletes)
	--not calling delete st procs because those do not support multiple entity ids at a time and validation is not needed at this point

	-- delete businessunit related roles
	exec [dbo].[spDeleteEntepriseAdmintRoles] @companyIds;
	--exec [dbo].[spDeleteBusnessUnitRolesFromCompanies] @companyIds

	
	-- Delete Company's User
	-- Commented as now user could be associated with multiple companies. But Users with No Roles would be deleted using update below
	-- delete from [dbo].[User] where CompanyId in (select id from @companyIds);	

	-- With Users with no Roles.
	Declare @userIdsWithNoRoles [dbo].ttIntValue;
	BEGIN
		INSERT INTO @userIdsWithNoRoles SELECT Id FROM dbo.[User] WHERE Id NOT IN (SELECT UserId from dbo.UserRole);
		exec [dbo].[spDeleteUsers] @userIds=@userIdsWithNoRoles, @user=@userName;
	END


	--Delete Company's License
	
	delete from [sec].License where CompanyId in (select id from @companyIds);		
	
    -- delete from [adm].License where CompanyId in (select id from @companyIds);

	--delete Companies
	delete from [adm].[Company] 
	output cast(0 as bit), deleted.Id, N'[adm].[Company]' into @result
	where Id in (select id from @companyIds);

	--success
	commit transaction @TranName
	select * from @result;
	return;


RETURN 0

go
exec sp_addextendedproperty @name =
	N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spPurgingCompanies',
    @level2type = NULL,
    @level2name = NULL
