﻿CREATE PROCEDURE [adm].[spPurgingBusinessUnits]
	@buIds [dbo].ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS
	
	declare @result [dbo].StProcResult;
	set XACT_ABORT ON;
	
	--validate Business Unit Ids
	if exists (select id from @buIds except select id from [adm].[BusinessUnit])
	throw 51000, 'ERROR-DELETE-BUSINESSUNIT-Invalid Business Unit Ids', 1;

	declare @coIds [dbo].ttIntValue;
	insert into @coIds
	select distinct CompanyId from [adm].BusinessUnit bu
	join @buIds bi on bi.Id = bu.Id;

	--case a: mulitple companies returned above and user is NOT a SysADmin -> unauthorized
	if (select count(Id) from @coIds) > 1 --must be a sysAdmin
	and not exists (select 1 from [adm].[IsSysAdmin]())
	throw 51000, N'ERROR-DELETE-BUSINESSUNIT-UNAUTHORIZED The user is not a Sys Admin to delete multiple BUs across multiple companies', 1;

	--case b: single company returned above and user is NOT a SysAdmin OR Enterprise Admin for that company -> unauthorized
	-- Following code is NOT applicable for Cloud Dashboard solution as User with Full Permission for Admin module should be able to delete Organization which is mapped to BusinessUnit
	-- Hence executing the code conditionally
	-- IF @IsProductCloudDashboard = 0
	-- BEGIN
		if (select count(Id) from @coIds) = 1 
		and not exists (select 1 from [adm].[IsEnterpriseAdminForCompany]((select top(1) Id from @coIds)))
		throw 51000, N'ERROR-DELETE-BUSINESSUNIT-UNAUTHORIZED The user is not a Sys Admin or an Enterprise Admin to delete BUs', 1;
	-- END

	declare @t [dbo].ttIntStringTuple;
	insert into @t
	select Id, 'BUSINESSUNIT' from @buIds;

	--Transaction starts here
	DECLARE @TranName NVARCHAR(20) = N'DeleteBusinessUnitsTx'; 
 	BEGIN TRANSACTION @TranName; 

	--delete some child elements related to scheduling (to avoid cycles with cascading deletes)
	--not calling delete st procs because those do not support multiple entity ids at a time and validation is not needed at this point
	-- exec [adm].[spDeleteSchedulesAndHolidaysForEntities] @t, @userName; --deletes for the entire underlying hierarchy (schedules and holidays for itself, for its BUs, for all APPS of those BUs)

	
	--delete assigned Roles
	exec [dbo].[spDeleteBusnessUnitRoles] @buIds

	---Delete BU's Offer Eligibility
	-- Declare @surveyIds ttIntValue ,
	-- 	@companyIds ttIntValue
	-- 	insert into @result
	-- exec [cfl].[spDeleteAllOfferEligiblityRulesForSurvey] @surveyIds, @companyIds, @buIds, @userName;
		

    --Delete Company's External Link
	-- delete from [dbo].[ExternalLink] where BusinessUnitId in (select id from @buIds);	

	-- delete from DeploymentTargetMap
	-- delete from [adm].DeploymentTargetMap where BusinessUnitId in (select id from @buIds);
	--delete BUs
	delete from [adm].[BusinessUnit] 
	output cast(0 as bit), deleted.Id, N'[adm].[BusinessUnit]' into @result
	where Id in (select id from @buIds);

	--success
	commit transaction @TranName
	select * from @result;
	return; 

RETURN 0

go
exec sp_addextendedproperty @name =
	N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spPurgingBusinessUnits',
    @level2type = NULL,
    @level2name = NULL
