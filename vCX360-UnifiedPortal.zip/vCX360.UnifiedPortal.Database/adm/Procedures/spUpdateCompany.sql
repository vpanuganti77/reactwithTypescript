﻿CREATE PROCEDURE [adm].[spUpdateCompany]
	@companyId int,
	@cid nvarchar(64),
	@name nvarchar(64),
	@status nvarchar(255),
	@desc nvarchar(512),
	@domain nvarchar(64),
	@userName nvarchar(256) = N'AdminPortal'
AS
	declare @result [dbo].[StProcResult];

	set XACT_ABORT ON;

	--validate Company exists
	if ([adm].[IsCompanyIdValid](@companyId) = 0)
	throw 51000, 'ERROR-UPDATE-COMPANY-Invalid Company Id', 1;

	--validate name (must be unique, but don't include this company's ID since this is an update)
	if (exists (select * from [adm].[Company] where [Name] = @name AND [ID] <> @companyId))
	throw 51000, 'ERROR-UPDATE-COMPANY-Name already exists', 1;

	--validate name - Domain (must be unique)
	if (exists (select * from [adm].[Company] where [Name] = @name and [Domain] = @domain AND [ID] <> @companyId))
	throw 51000, 'ERROR-INSERT-COMPANY-Name-Domain already exists', 1;

	--validate CID (must be unique across all companies) - but since this is an update we must exclude this combination for the entity we are tyring to update
	if (exists (select * from [adm].[Company] where [CID] = @cid AND [ID] <> @companyId))
	throw 51000, 'ERROR-UPDATE-COMPANY-CID for companies already exists', 1;

	--validate CID length
	if (len(@cid) < 2 OR len(@cid) > 64)
	throw 51000, 'ERROR-UPDATE-COMPANY-CID for companies is not the correct length (2..64)', 1;

	if not exists (select 1 from [adm].[IsSysAdmin]())
	throw 51000, N'ERROR-UPDATE-COMPANY-UNAUTHORIZED The user is not a Sys Admin. Only Sys Admins can update Companies', 1; 

	declare @TranName nvarchar(20) = N'UpdateCompanyTx';
	begin transaction @TranName;


	update [adm].[Company]
	set
		CID = @cid,
		[Name] = @name,
		[Status] = @status,
		[Description] = @desc,
		[Domain] = @domain,
		[UpdatedBy] = @userName,
		[UpdatedDate] = CURRENT_TIMESTAMP
	where
		id = @companyId;

	insert into @result
	values
		(cast(0 as bit),
		@companyId,
		N'[adm].[Company]'
		);

	--sucess
	COMMIT TRANSACTION @TranName; 

 	SELECT * from @result; 
 	RETURN; 

RETURN 0;

Go
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spUpdateCompany',
    @level2type = NULL,
    @level2name = NULL
