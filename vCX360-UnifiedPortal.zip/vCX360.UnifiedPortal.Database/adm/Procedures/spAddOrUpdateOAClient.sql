﻿CREATE PROCEDURE [adm].[spAddOrUpdateOAClient]
	@ttOAClient [adm].[ttOAClient] Readonly
AS

DECLARE @result dbo.StProcResult; 	
	SET XACT_ABORT ON;
	
	--Transaction starts HERE
	DECLARE @TranName NVARCHAR(20) = N'InsertOAClientTx'; 
 	BEGIN TRANSACTION @TranName; 
	DECLARE @name NVARCHAR(50),	
	@id int

	SELECT @name = [Name], @id = Id from @ttOAClient

	if (exists (SELECT * from [adm].[OAClient]
	where [Id] = @id and (@id is null or @id <> Id) ))
	throw 51000, 'ERROR-INSERT-OAClient - OAClient already exists', 1;
	
	--validate name while inserting domain(must be unique)
	if (exists (select * from [adm].[OAClient] 
	where [Name] = @name and (@id is null or @id <> Id) ))
	throw 51000, 'ERROR-INSERT-OAClient - Name already exists', 1;
	
	DECLARE @insertedOAuthIds [dbo].ttIntValue;
	MERGE [adm].[OAClient] t
	USING @ttOAClient AS s
	ON (t.[Id] = s.[Id])
	WHEN NOT MATCHED BY TARGET
	THEN INSERT ( [Name],
				  [ClientIdEnc], 
				  [SecretEnc],
				  [RegionId], 
				  [LastValidationStatus],
				  [LastValidationDate],
				  [CompanyId],
				  [IsDeleted],
				  [CreatedBy],
				  [CreatedDate]) 		
		VALUES ( s.[Name],
				 s.[ClientIdEnc],
				 s.[SecretEnc], 
				 s.[RegionId], 
				 s.LastValidationStatus, 
				 s.LastValidationDate,
				 s.[CompanyId],
				 s.[IsDeleted],
				 s.[CreatedBy],
				 GETDATE())	
	WHEN MATCHED -- AND (t.[UpdatedDate] = s.[UpdatedDate] or  t.[UpdatedDate] IS NULL)
	THEN UPDATE SET
					 t.[Name] = s.[Name],     
					 t.[ClientIdEnc] = s.[ClientIdEnc],
					 t.[SecretEnc] = s.[SecretEnc],
					 t.[RegionId] = s.[RegionId],
					 t.LastValidationStatus = s.LastValidationStatus,
					 t.LastValidationDate = t.LastValidationDate,   --TODO-VJ: Need to check why t.LastValidationDate using while update
					 t.[CompanyId] = s.[CompanyId],
					 t.[IsDeleted] = s.[IsDeleted],
					 t.[UpdatedBy] = s.[UpdatedBy],
					 t.[UpdatedDate] = GETDATE()
		-- OUTPUT $action, inserted.*, deleted.*;
		Output inserted.Id into @insertedOAuthIds ;--Ids of inserted OAClients

    -- DECLARE @debug002 nvarchar(max) = (SELECT * FROM @insertedOAuthIds FOR JSON AUTO); print 'insertedOAuthIds: ' + @debug002;
    IF NOT EXISTS (SELECT * FROM @insertedOAuthIds)
	throw 51000, 'ERROR-Update-OAClient - Update attempted on old data. Please try again with reloaded data.', 1;

	Insert into @result
	SELECT
		CAST (0 as bit),
		Id,
		N'[adm].[OAClient]'
	From
		@insertedOAuthIds;
	--On Success
	Commit Transaction @TranName;
	SELECT * From @result;
	Return;
RETURN 0;
GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spAddOrUpdateOAClient',
    @level2type = NULL,
    @level2name = NULL