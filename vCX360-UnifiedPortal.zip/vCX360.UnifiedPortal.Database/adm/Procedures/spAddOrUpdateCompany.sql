﻿CREATE PROCEDURE [adm].[spAddOrUpdateCompany]
(
	@ttCompany AS [adm].[ttCompany] READONLY,
	@userName nvarchar(256) = N'AdminPortal'
)
AS
	Declare @result [dbo].StProcResult;

	Set XACT_ABORT ON;

	declare @isInsert int = 0

	if exists( Select id from @ttCompany where id in (select Id from [adm].[Company]))
		set @isInsert = 1

	--validate name (must be unique)
	if (exists (select * from [adm].[Company] c JOIN @ttCompany t on c.[Name] = t.[Name] where (t.id is null or t.id <> c.Id) ))
	throw 51000, 'ERROR-INSERT-COMPANY-Name already exists', 1;

	--validate name - Domain (must be unique)
	if (exists (select * from [adm].[Company] c JOIN @ttCompany t on c.[Name] = t.[Name] and c.[Domain] = t.[Domain] where (t.id is null or t.id <> c.Id)))
	throw 51000, 'ERROR-INSERT-COMPANY-Name-Domain already exists', 1;

	--validate CID (must be unique across all companies)
	if (exists (select * from [adm].[Company] c JOIN @ttCompany t on c.[CID] = t.[CID] where (t.id is null or t.id <> c.Id)))
	throw 51000, 'ERROR-INSERT-COMPANY-CID for companies already exists', 1;	

	--validate CID length
	if exists(select * from @ttCompany where len(CID) < 2 and len(CID) > 64)
	throw 51000, 'ERROR-INSERT-COMPANY-CID for companies is not the correct length (2..64)', 1;

	
	Declare @TranName nvarchar(20) = N'InsertCompanyTx';
	Begin Transaction @TranName;

	--Create Customer
	Declare @insertedCompanyIds [dbo].ttIntValue;

	MERGE [adm].[Company] AS t
    USING @ttCompany AS s
    ON (t.[Id] = s.[Id])
    WHEN NOT MATCHED BY TARGET THEN
        INSERT
			([CID],
			 [Name] ,          
			 [Status] ,        
			 [Description] ,    
			 [Domain]  , 
			 [TenantId] ,
			 [OrgId],
			 [IsDeleted] ,     
			 [IntegrationType],
			 [CreatedBy]  )
		VALUES
		    (s.[CID],
			 s.[Name] ,          
			 s.[Status] ,        
			 s.[Description] ,     
			 s.[Domain]  ,  
			 s.[TenantId] ,
			 s.[OrgId],
			 s.[IsDeleted] ,     
			 s.[IntegrationType],
			 s.[CreatedBy] )
	 WHEN MATCHED THEN
        UPDATE SET
			t.[CID]					=   s.[CID],
			t.[Name]				=   s.[Name] ,          
			t.[Status]				=	s.[Status] ,        
			t.[Description]		   	=	s.[Description] ,      
			t.[Domain]		       	=	s.[Domain]  ,  
			t.[TenantId]	      	=	s.[TenantId] ,
			t.[OrgId]				=   s.[OrgId],
			t.[IsDeleted]		   	=	s.[IsDeleted] ,     
			t.[IntegrationType]		=	s.[IntegrationType],
			t.[UpdatedBy]	     	=	s.[UpdatedBy] ,     
			t.[UpdatedDate] 		=	GETDATE()
	Output inserted.Id into @insertedCompanyIds; --Ids of inserted companies

	
	if(@isInsert = 0)
	begin
		declare @coId int = (select top(1) Id from @insertedCompanyIds);
		declare @cid nvarchar = (select top(1) CID from @ttCompany);
		EXEC [dbo].[spCreateEnterpriseAdminRole] @coId, @cid, @userName; --add EAdmin role/custom role and permission
	end

	Insert into @result
	Select
		CAST (0 as bit),
		Id,
		N'[adm].[Company]'
	From
		@insertedCompanyIds;
	
	--On Success
	Commit Transaction @TranName;

	Select * From @result;
	Return;

RETURN 0

Go
EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'adm',
    @level1type = N'PROCEDURE',
    @level1name = N'spAddOrUpdateCompany',
    @level2type = NULL,
    @level2name = NULL;
			    

