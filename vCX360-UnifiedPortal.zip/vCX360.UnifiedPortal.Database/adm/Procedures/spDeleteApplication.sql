﻿
CREATE PROCEDURE [adm].[spDeleteApplication]
	@Ids dbo.ttIntValue READONLY,
	@userName nvarchar(256) = N'AdminPortal' -- to be used perhaps for Audit
AS

declare @result dbo.StProcResult;
	set XACT_ABORT on;

	--validate Application Ids
	if exists (select id from @Ids except select id from [adm].[Application])
	throw 51000, 'ERROR-DELETE-Application-Invalid Application Ids', 1;

	if exists (select 1 From adm.CompanyBusinessUnitAppMap where ApplicationId in 
    (Select id from @Ids))
    throw 51000, 'ERROR- Cannot delete the Application because it is being used for Company\BusinessUnit!', 1;

	--Transaction starts here
	declare @TranName nvarchar(20) = N'DeleteApplicationTx';
	begin transaction @TranName;

	delete from [adm].[Application] 
	output cast(0 as bit), deleted.Id, N'[adm].[Application]' into @result
	where Id in (select id from @Ids);

	--success
	commit transaction @TranName
	select * from @result;
	return;
RETURN 0


EXEC sys.sp_addextendedproperty @name = N'DM_RecordType',
@value = N'[dbo].[StProcResult]' ,
@level0type = N'SCHEMA',
@level0name = N'adm',
@level1type = N'PROCEDURE',
@level1name = N'spDeleteApplication'
