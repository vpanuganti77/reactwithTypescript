﻿CREATE TABLE [adm].[Platform]
(
	Id				SMALLINT       NOT NULL DEFAULT NEXT VALUE FOR [adm].[PlatformIdSeq],
	[Name]			VARCHAR(100)   NOT NULL,
	[Description]	VARCHAR(1000)  NULL,
	[Status]		VARCHAR(100)   Default('Active'),	
	IsDeleted		BIT			   Default(0),

	CONSTRAINT [PK_Platform_Id] PRIMARY KEY CLUSTERED ([Id])
)
