﻿CREATE TABLE [adm].[Domain]
(
	[Id]                        INT            NOT NULL DEFAULT NEXT VALUE FOR [adm].[DomainIdSeq],
    [Name]                      NVARCHAR(64)   NOT NULL,
    [Description]               NVARCHAR(256)  NULL,
    [LDAP]                      NVARCHAR(1024) NOT NULL,
    [UserName]                  NVARCHAR(128)  NULL,
    [Password]                  NVARCHAR(1024) NULL,
    [AllowsUserManagement]      BIT            NOT NULL DEFAULT 0,
    [TenantId]                  INT            NULL,
    [IsDeleted]                 BIT            NOT NULL DEFAULT 0,

     --audit info
    [CreatedBy]   NVARCHAR (256) NOT NULL DEFAULT ('unknown'),
    [CreatedDate] DATETIME2 (0)	 NOT NULL CONSTRAINT [df_Domain_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]  NVARCHAR (256)  NULL,
    [UpdatedDate] DATETIME2 (0)	 NULL,

    CONSTRAINT [PK_Domain_Id] PRIMARY KEY CLUSTERED ([Id]),
    CONSTRAINT [UQ_Domain_Name] UNIQUE ([Name]),
    CONSTRAINT [FK_Domain_TenantId] FOREIGN KEY ([TenantId]) REFERENCES [adm].[Tenant] ([TenantId])

)
GO
CREATE INDEX [IX_Domain_Name] ON [adm].[Domain] ([Name])
GO