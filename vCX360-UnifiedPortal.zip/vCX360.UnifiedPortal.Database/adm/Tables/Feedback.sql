﻿CREATE TABLE [adm].Feedback
(
	Id				INT			   NOT NULL  DEFAULT NEXT VALUE FOR  [adm].[FeedbackIdSeq],
	FeedbackType	NVARCHAR(64)   NOT NULL,
	ApplicationId	INT			   NULL,
	ApplicationType NVARCHAR(64)   NOT NULL,
	[Message]		NVARCHAR(255)  NULL,
	[Attachment]    VARBINARY(MAX) NULL,--TBD
	[Status]        NVARCHAR(255)  NOT NULL,
	IsDeleted		BIT			   DEFAULT 0,
	--audit info
	[CreatedBy]     NVARCHAR (256) NOT NULL DEFAULT ('unknown'),
	[CreatedDate]   DATETIME2 (0)  NOT NULL CONSTRAINT [df_Feedback_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
	[UpdatedBy]     NVARCHAR (256) NULL,
	[UpdatedDate]   DATETIME2 (0)  NULL,

	CONSTRAINT [PK_Feedback_Id] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [FK_Application_Feedback] FOREIGN KEY ([ApplicationId]) REFERENCES [adm].[Application] ([Id]) ON DELETE CASCADE

)