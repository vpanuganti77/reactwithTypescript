﻿CREATE TABLE [adm].[Application]
(
	[Id]	            INT 	        NOT NULL  DEFAULT NEXT VALUE FOR [adm].ApplicationIdSeq,       
    [CID]	            NVARCHAR (16)   NOT NULL,
    [Name]	            NVARCHAR (64)   NOT NULL,
    [Type]              NVARCHAR (64)   NOT NULL,
    [Icon]              VARBINARY(MAX)  NULL,
    [OverviewURL]       NVARCHAR(MAX)   NULL,
    [Overview]          NVARCHAR(1000)  NULL,
    [Status]            NVARCHAR (255)  NOT NULL  DEFAULT (''),
    [Description]  	    NVARCHAR (MAX)  NULL,
    [SuiteId]           INT             NOT NULL,
    [IsDeleted]         BIT DEFAULT 0,

  --audit info
    [CreatedBy]         NVARCHAR (256)  NOT NULL,
    [CreatedDate]       DATETIME2 (0)	NOT NULL CONSTRAINT [df_Application_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]         NVARCHAR (256)  NULL,
    [UpdatedDate]       DATETIME2 (0)	NULL,

    CONSTRAINT [PK_Application] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_ApplicationName] UNIQUE ([SuiteId], [Name]),
    CONSTRAINT [UQ_Application_CID] UNIQUE ([SuiteId], [CID])
)
