﻿CREATE TABLE [adm].[Tenant]
(
	[TenantId]         INT			    NOT NULL DEFAULT NEXT VALUE FOR [adm].[TenantIdSeq],
	[TenantCID]		   NVARCHAR(100)	NOT NULL DEFAULT('Default'),
	[TenantName]	   NVARCHAR(100)	NOT NULL,
	[ParentTenantId]   SMALLINT		    NULL,
	[PlatformId]	   SMALLINT		    NULL,
	[ConnectionString] NVARCHAR(100)	NULL,
	[Description]      NVARCHAR(MAX)    NULL,
	[Contact]          NVARCHAR(100)	NULL,

	[IsDeleted]       BIT			DEFAULT 0,
	--audit info
	[CreatedBy]       NVARCHAR (256)  NOT NULL DEFAULT ('unknown'),
	[CreatedDate]     DATETIME2 (0)	  NOT NULL CONSTRAINT [df_Tenant_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
	[UpdatedBy]       NVARCHAR (256)  NULL,
	[UpdatedDate]     DATETIME2 (0)	  NULL,

	CONSTRAINT [PK_Tenant_Id] PRIMARY KEY CLUSTERED ([TenantId]),
	--CONSTRAINT [UQ_TenantCID] UNIQUE ([TenantCID],TenantId),
	CONSTRAINT [UQ_TenantName] UNIQUE ([TenantName]),
	CONSTRAINT [FK_Tenant_PlatformId] FOREIGN KEY (PlatformId) REFERENCES [adm].[Platform] ([Id]) ON DELETE CASCADE

)



go

CREATE TRIGGER [adm].[trgTenant] ON [adm].[Tenant] 
FOR INSERT,	UPDATE,DELETE
AS

SET NOCOUNT ON;

DECLARE @sql VARCHAR(5000) ,
    @sqlInserted NVARCHAR(500) ,  
	@sqlDeleted NVARCHAR(500) ,
    @NewValue NVARCHAR(1000) ,
	@OldValue NVARCHAR(1000) ,
    @CreatedBy VARCHAR(50) ,  
	@CreatedOn DATETIME2(0) ,
	@UpdatedBy VARCHAR(50) ,
	@UpdatedOn DATETIME2(0) ,  
    @ParmDefinitionI NVARCHAR(2000) ,
	@ParmDefinitionD NVARCHAR(2000) ,
    @TABLE_NAME VARCHAR(100) ,
    @COLUMN_NAME VARCHAR(100) ,
    @modifiedColumnsList NVARCHAR(4000) ,
    @ColumnListItem NVARCHAR(500) ,
    @Pos INT ,
	@ParentId VARCHAR(50),
    @RecordPk VARCHAR(50) ,
    @RecordPkName VARCHAR(50),
	@ScreenName VARCHAR(50);
	Set @ScreenName='adm.Tenant';

	
SELECT  *
INTO    #deleted
FROM    deleted;
SELECT  *
INTO    #Inserted
FROM    inserted;

SET @TABLE_NAME='adm.Tenant';

SELECT  @CreatedBy = app_name(), @CreatedOn = Getdate() ,@UpdatedBy = app_name()
, @UpdatedOn = Getdate() ,@ParentId=PlatformId
FROM    inserted;

--INSERT
IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)  
BEGIN
	SELECT  @RecordPk = TenantId --Change to the table primary key field
	FROM    inserted;   
	IF(@RecordPk IS NOT NULL) 
	BEGIN
	SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
	                                   FROM     sys.columns
	                                   WHERE name != 'UpdatedDate' 
									   and name != 'UpdatedBy' and name != 'CreatedBy' and name != 'CreatedDate'
									   and object_id = OBJECT_ID(@TABLE_NAME)                                           
	                                 FOR
	                                   XML PATH('')
	                                 ), 1, 1, '');
	
		WHILE LEN(@modifiedColumnsList) > 0
	    BEGIN
	        SET @Pos = CHARINDEX(',', @modifiedColumnsList);
	        IF @Pos = 0
	            BEGIN
	                SET @ColumnListItem = @modifiedColumnsList;
	            END;
	        ELSE
	            BEGIN
	                SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
	                                                @Pos - 1);
	            END;    
			
	        SET @COLUMN_NAME = @ColumnListItem;
	      
	        SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
	       
	        SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
	            + ' FROM #Inserted where TenantId = ' 
	            + CONVERT(VARCHAR(50), @RecordPk);
			
	        EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
	            @NewValueOut = @NewValue OUTPUT;
	
			if(ISNULL(@NewValue,'') != '')
				BEGIN                 
					INSERT INTO [dbo].[TableConfigChangeLogs](				   
					 [Table]    
					 ,[ColumnName]    
					 ,[NewValue]  				
					 ,[UserName]      
					 ,[ActionDate]
					 ,[Action]    
					 ,[KeyValue]
					 ,[ParentId])
					 values(@ScreenName,@COLUMN_NAME,@NewValue,@CreatedBy,@CreatedOn,'Insert',@RecordPk,@ParentId)   
				END         
	        SET @COLUMN_NAME = '';
	        SET @NewValue = '';
	       
	        IF @Pos = 0
	            BEGIN
	                SET @modifiedColumnsList = '';
	            END;
	        ELSE
	            BEGIN
	           -- start substring at the character after the first comma
	                SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
	                                                     @Pos + 1,
	                                                     LEN(@modifiedColumnsList)
	                                                     - @Pos);
	            END;
	    END;
	END;
END
--UPDATE 
IF EXISTS (SELECT * FROM inserted ) AND EXISTS (SELECT * FROM deleted)
BEGIN
	SELECT  @RecordPk = TenantId --Change to the table primary key field
	FROM    inserted;   
	
	IF(@RecordPk IS NOT NULL) 
	BEGIN
	SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
	                                   FROM     sys.columns
	                                   WHERE name != 'CreatedDate' and name != 'CreatedBy'
									   and name != 'UpdatedDate' and name != 'UpdatedBy'
									   and object_id = OBJECT_ID(@TABLE_NAME)                                           
	                                 FOR
	                                   XML PATH('')
	                                 ), 1, 1, '');
	
	
		WHILE LEN(@modifiedColumnsList) > 0
		BEGIN
	        SET @Pos = CHARINDEX(',', @modifiedColumnsList);
	        IF @Pos = 0
	            BEGIN
	                SET @ColumnListItem = @modifiedColumnsList;
	            END;
	        ELSE
	            BEGIN
	                SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
	                                                @Pos - 1);
	            END;    
	
	        SET @COLUMN_NAME = @ColumnListItem;
	        SET @ParmDefinitionD = N'@OldValueOut NVARCHAR(1000) OUTPUT';
	        SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
	        SET @sqlDeleted = N'SELECT @OldValueOut=' + @COLUMN_NAME
	            + ' FROM #deleted where TenantId = ' + CONVERT(VARCHAR(50), @RecordPk);
	        SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
	            + ' FROM #Inserted where TenantId =' + CONVERT(VARCHAR(50), @RecordPk);
	        EXECUTE sp_executesql @sqlDeleted, @ParmDefinitionD,
	            @OldValueOut = @OldValue OUTPUT;
	        EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
	            @NewValueOut = @NewValue OUTPUT;
	        IF ( LTRIM(RTRIM(ISNULL(@NewValue,''))) != LTRIM(RTRIM(ISNULL(@OldValue,''))) )
	            BEGIN  
				INSERT INTO [dbo].[TableConfigChangeLogs](				   
					 [Table]    
					 ,[ColumnName]    
					 ,[NewValue]  
					 ,[OldValue]  
					 ,[UserName]      
					 ,[ActionDate]
					 ,[Action]    
					 ,[KeyValue]
					 ,[ParentId])
					 values(@ScreenName,@COLUMN_NAME,ISNULL(@NewValue,''),ISNULL(@OldValue,''),@UpdatedBy,@UpdatedOn,'Update',@RecordPk,@ParentId)   
				
	            END;     
	        SET @COLUMN_NAME = '';
	        SET @NewValue = '';
	        SET @OldValue = '';
	        IF @Pos = 0
	            BEGIN
	                SET @modifiedColumnsList = '';
	            END;
	        ELSE
	            BEGIN
	           -- start substring at the character after the first comma
	                SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
	                                                     @Pos + 1,
	                                                     LEN(@modifiedColumnsList)
	                                                     - @Pos);
	            END;
	    END;
	END;
END
--DELETE
IF EXISTS (SELECT * FROM deleted) AND NOT EXISTS(SELECT * FROM inserted) 
BEGIN
	SELECT  @UpdatedBy = app_name(),@UpdatedOn = Getdate() , @RecordPk = TenantId, @ParentId = PlatformId 
	FROM    DELETED;   
	
	IF(@RecordPk IS NOT NULL) 
	BEGIN
		SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
	                                   FROM     sys.columns
	                                   WHERE name != 'UpdatedDate' 
									   and name != 'UpdatedBy' and name != 'CreatedBy' and name != 'CreatedDate'
									   and object_id = OBJECT_ID(@TABLE_NAME)                                           
	                                 FOR
	                                   XML PATH('')
	                                 ), 1, 1, '');
	
	
		WHILE LEN(@modifiedColumnsList) > 0
		BEGIN
		    SET @Pos = CHARINDEX(',', @modifiedColumnsList);
		    IF @Pos = 0
		        BEGIN
		            SET @ColumnListItem = @modifiedColumnsList;
		        END;
		    ELSE
		        BEGIN
		            SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
		                                            @Pos - 1);
		        END;    
			
		
			SET @COLUMN_NAME = @ColumnListItem;
		
		
		    SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
		    
		    SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
		        + ' FROM #DELETED where TenantId = ' 
		        + CONVERT(VARCHAR(50), @RecordPk);
		
		    EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
		        @NewValueOut = @NewValue OUTPUT;
		
		    if(ISNULL(@NewValue,'') != '')
			  BEGIN                 
			  INSERT INTO [dbo].[TableConfigChangeLogs](				   
			  		 [Table]    
			  		 ,[ColumnName]    
			  		 ,[OldValue]  				
			  		 ,[UserName]      
			  		 ,[ActionDate]
			  		 ,[Action]    
			  		 ,[KeyValue]
			  		 ,[ParentId])
			  		 values(@ScreenName,@COLUMN_NAME,@NewValue,@UpdatedBy,@UpdatedOn,'Delete',@RecordPk,@ParentId)   
		      END         
		      SET @COLUMN_NAME = '';
		      SET @NewValue = '';
		       
		      IF @Pos = 0
		          BEGIN
		              SET @modifiedColumnsList = '';
		          END;
		      ELSE
		          BEGIN
		          -- start substring at the character after the first comma
		              SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
		                                                   @Pos + 1,
		                                                   LEN(@modifiedColumnsList)
		                                                   - @Pos);
		          END;
		END;
	END;
END
GO

ALTER TABLE [adm].[Tenant] ENABLE TRIGGER [trgTenant]
GO





