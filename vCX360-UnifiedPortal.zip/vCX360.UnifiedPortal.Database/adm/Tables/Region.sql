﻿CREATE TABLE [adm].[Region]
(
	[Id]           	 INT			NOT NULL  DEFAULT NEXT VALUE FOR [adm].RegionIdSeq ,       
	[Name]         	 NVARCHAR(64)	NOT NULL, 
	[Description]  	 NCHAR(500)		NOT NULL,
	[Text]         	 NCHAR(500)		NOT NULL, 
	[Enabled]      	 TINYINT		NOT NULL DEFAULT 0, 
	


	CONSTRAINT [PK_Region] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_RegionName] UNIQUE ([Name])  
)
