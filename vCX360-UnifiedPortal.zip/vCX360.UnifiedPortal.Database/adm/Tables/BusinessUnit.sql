﻿CREATE TABLE [adm].[BusinessUnit] 
(
    [Id]						INT             NOT NULL   DEFAULT NEXT VALUE FOR [adm].[BusinessUnitIdSeq],
    [CID]                       NVARCHAR (16)   NOT NULL,
    [Name]                      NVARCHAR (64)   NOT NULL,
    [Status]                    NVARCHAR (255)  NOT NULL  DEFAULT (''),
    [Description]               NVARCHAR (512)  NULL,
	[CompanyId]					INT             NOT NULL,
    [Number]                    NVARCHAR (10)   NULL,-- TBD
  	
	[RowVersion]                ROWVERSION      NOT NULL,
    [Domain]                    NVARCHAR (64)   NULL,
    [DivisionId]                NVARCHAR (64)   NULL,
    [DivisionName]              NVARCHAR (64)   NULL,
    [OAClientId]                INT NULL,
    [TimeZone]                  NVARCHAR (150)   NULL,
    [IsDeleted]                 BIT DEFAULT 0,

    --audit info
	[CreatedBy]                 NVARCHAR (256)  NOT NULL DEFAULT ('unknown'),
    [CreatedDate]               DATETIME2 (0)	NOT NULL CONSTRAINT [df_BusinessUnit_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]                 NVARCHAR (256)  NULL,
    [UpdatedDate]               DATETIME2 (0)	NULL,

	CONSTRAINT [PK_BusinessUnit_Id] PRIMARY KEY CLUSTERED ([Id]),
    CONSTRAINT [FK_Company_BusinessUnit] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]) ON DELETE CASCADE,
	CONSTRAINT [UQ_BusinessUnitNameForCompany] UNIQUE ([Name], [CompanyId]), --for a given company, the name of a BU is unique
	CONSTRAINT [UQ_BusinessUnitCIDForCompany] UNIQUE ([CID], [CompanyId]), --TODO: verify if this is unique for a company, or across all companies
    CONSTRAINT [FK_OAuth_OAuthClientId] FOREIGN KEY ([OAClientId]) REFERENCES [adm].[OAClient] ([Id]), --ON DELETE CASCADE, -- Deleteing [OAClient] from spDeleteBusinessUnit
);


GO



CREATE TRIGGER [adm].[trgBusinessUnit] ON [adm].[BusinessUnit] 
FOR INSERT,	UPDATE,DELETE
AS

SET NOCOUNT ON;

DECLARE @sql VARCHAR(5000) ,
    @sqlInserted NVARCHAR(500) ,  
	@sqlDeleted NVARCHAR(500) ,
    @NewValue NVARCHAR(1000) ,
	@OldValue NVARCHAR(1000) ,
    @CreatedBy VARCHAR(50) ,  
	@CreatedOn DATETIME2(0) ,
	@UpdatedBy VARCHAR(50) ,
	@UpdatedOn DATETIME2(0) ,  
    @ParmDefinitionI NVARCHAR(2000) ,
	@ParmDefinitionD NVARCHAR(2000) ,
    @TABLE_NAME VARCHAR(100) ,
    @COLUMN_NAME VARCHAR(100) ,
    @modifiedColumnsList NVARCHAR(4000) ,
    @ColumnListItem NVARCHAR(500) ,
    @Pos INT ,
    @RecordPk VARCHAR(50) ,
    @RecordPkName VARCHAR(50),
	@ParentId VARCHAR(50),
	@ScreenName VARCHAR(50);
	Set @ScreenName='adm.BusinessUnit';

	
SELECT  *
INTO    #deleted
FROM    deleted;
SELECT  *
INTO    #Inserted
FROM    inserted;

SET @TABLE_NAME='adm.BusinessUnit';

SELECT  @CreatedBy = app_name(), @CreatedOn = Getdate() ,@UpdatedBy = app_name()
, @UpdatedOn = Getdate(),@ParentId = CompanyId
FROM    inserted;

--INSERT
IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)  
BEGIN
	SELECT  @RecordPk = Id --Change to the table primary key field
	FROM    inserted;   
	IF(@RecordPk IS NOT NULL) 
	BEGIN
	SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
	                                   FROM     sys.columns
	                                   WHERE  name != 'RowVersion' and name != 'UpdatedDate' 
									   and name != 'UpdatedBy' and name != 'CreatedBy' and name != 'CreatedDate'
									   and object_id = OBJECT_ID(@TABLE_NAME)                                           
	                                 FOR
	                                   XML PATH('')
	                                 ), 1, 1, '');
	
		WHILE LEN(@modifiedColumnsList) > 0
	    BEGIN
	        SET @Pos = CHARINDEX(',', @modifiedColumnsList);
	        IF @Pos = 0
	            BEGIN
	                SET @ColumnListItem = @modifiedColumnsList;
	            END;
	        ELSE
	            BEGIN
	                SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
	                                                @Pos - 1);
	            END;    
			
	        SET @COLUMN_NAME = @ColumnListItem;
	      
	        SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
	       
	        SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
	            + ' FROM #Inserted where Id = ' 
	            + CONVERT(VARCHAR(50), @RecordPk);
			
	        EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
	            @NewValueOut = @NewValue OUTPUT;
	
			if(ISNULL(@NewValue,'') != '')
			BEGIN                 
				INSERT INTO [dbo].[TableConfigChangeLogs](				   
					 [Table]    
					 ,[ColumnName]    
					 ,[NewValue]  				
					 ,[UserName]      
					 ,[ActionDate]
					 ,[Action]    
					 ,[KeyValue]
					 ,[ParentId]
					 ,[CompanyId])
					 values(@ScreenName,@COLUMN_NAME,@NewValue,@CreatedBy,@CreatedOn,'Insert',@RecordPk,@ParentId,@ParentId)   
			END         
	        SET @COLUMN_NAME = '';
	        SET @NewValue = '';
	       
	        IF @Pos = 0
	            BEGIN
	                SET @modifiedColumnsList = '';
	            END;
	        ELSE
	            BEGIN
	           -- start substring at the character after the first comma
	                SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
	                                                     @Pos + 1,
	                                                     LEN(@modifiedColumnsList)
	                                                     - @Pos);
	            END;
	    END;
	END;
END
--UPDATE 
IF EXISTS (SELECT * FROM inserted ) AND EXISTS (SELECT * FROM deleted WHERE IsDeleted = 0)
BEGIN
	SELECT  @RecordPk = Id --Change to the table primary key field
	FROM    inserted;   
	
	IF(@RecordPk IS NOT NULL) 
	BEGIN
		SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
	                                   FROM     sys.columns
	                                   WHERE  name != 'RowVersion' and name != 'CreatedDate' and name != 'CreatedBy'
									   and name != 'UpdatedDate' and name != 'UpdatedBy'
									   and object_id = OBJECT_ID(@TABLE_NAME)                                           
	                                 FOR
	                                   XML PATH('')
	                                 ), 1, 1, '');
	
	
		WHILE LEN(@modifiedColumnsList) > 0
	    BEGIN
	        SET @Pos = CHARINDEX(',', @modifiedColumnsList);
	        IF @Pos = 0
	            BEGIN
	                SET @ColumnListItem = @modifiedColumnsList;
	            END;
	        ELSE
	            BEGIN
	                SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
	                                                @Pos - 1);
	            END;    
	
	        SET @COLUMN_NAME = @ColumnListItem;
	        SET @ParmDefinitionD = N'@OldValueOut NVARCHAR(1000) OUTPUT';
	        SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
	        SET @sqlDeleted = N'SELECT @OldValueOut=' + @COLUMN_NAME
	            + ' FROM #deleted where Id = ' + CONVERT(VARCHAR(50), @RecordPk);
	        SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
	            + ' FROM #Inserted where Id =' + CONVERT(VARCHAR(50), @RecordPk);
	        EXECUTE sp_executesql @sqlDeleted, @ParmDefinitionD,
	            @OldValueOut = @OldValue OUTPUT;
	        EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
	            @NewValueOut = @NewValue OUTPUT;
	        IF ( LTRIM(RTRIM(ISNULL(@NewValue,''))) != LTRIM(RTRIM(ISNULL(@OldValue,''))) )
	            BEGIN  
				INSERT INTO [dbo].[TableConfigChangeLogs](				   
					 [Table]    
					 ,[ColumnName]    
					 ,[NewValue]  
					 ,[OldValue]  
					 ,[UserName]      
					 ,[ActionDate]
					 ,[Action]    
					 ,[KeyValue]
					 ,[ParentId]
					 ,[CompanyId])
					 values(@ScreenName,@COLUMN_NAME,ISNULL(@NewValue,''),ISNULL(@OldValue,''),@UpdatedBy,@UpdatedOn,'Update',@RecordPk,@ParentId,@ParentId)   
				
	            END;     
	        SET @COLUMN_NAME = '';
	        SET @NewValue = '';
	        SET @OldValue = '';
	        IF @Pos = 0
	            BEGIN
	                SET @modifiedColumnsList = '';
	            END;
	        ELSE
	            BEGIN
	           -- start substring at the character after the first comma
	                SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
	                                                     @Pos + 1,
	                                                     LEN(@modifiedColumnsList)
	                                                     - @Pos);
	            END;
	    END;
	END;
END
--DELETE
IF EXISTS (SELECT * FROM deleted) AND NOT EXISTS (SELECT * FROM inserted)
BEGIN

	SELECT  @UpdatedBy = app_name(), @UpdatedOn = Getdate() ,@ParentId = CompanyId,
	 @RecordPk = Id
	FROM    DELETED;   
	
	IF(@RecordPk IS NOT NULL) 
	BEGIN
	SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
	                                   FROM     sys.columns
	                                   WHERE  name != 'RowVersion' and name != 'UpdatedDate' 
									   and name != 'UpdatedBy' and name != 'CreatedBy' and name != 'CreatedDate'
									   and object_id = OBJECT_ID(@TABLE_NAME)                                           
	                                 FOR
	                                   XML PATH('')
	                                 ), 1, 1, '');
	
	
		WHILE LEN(@modifiedColumnsList) > 0
	    BEGIN
	        SET @Pos = CHARINDEX(',', @modifiedColumnsList);
	        IF @Pos = 0
	            BEGIN
	                SET @ColumnListItem = @modifiedColumnsList;
	            END;
	        ELSE
	            BEGIN
	                SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
	                                                @Pos - 1);
	            END;    
			
	
			SET @COLUMN_NAME = @ColumnListItem;
	
	
	        SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
	       
	        SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
	            + ' FROM #DELETED where Id = ' 
	            + CONVERT(VARCHAR(50), @RecordPk);
	
	        EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
	            @NewValueOut = @NewValue OUTPUT;
	
	    if(ISNULL(@NewValue,'') != '')
			BEGIN                 
			INSERT INTO [dbo].[TableConfigChangeLogs](				   
					 [Table]    
					 ,[ColumnName]    
					 ,[OldValue]  				
					 ,[UserName]      
					 ,[ActionDate]
					 ,[Action]    
					 ,[KeyValue]
					 ,[ParentId]
				     ,[CompanyId])
					 values(@ScreenName,@COLUMN_NAME,@NewValue,@UpdatedBy,@UpdatedOn,'Delete',@RecordPk,@ParentId,@ParentId)   
	      END         
	        SET @COLUMN_NAME = '';
	        SET @NewValue = '';
	       
	        IF @Pos = 0
	            BEGIN
	                SET @modifiedColumnsList = '';
	            END;
	        ELSE
	            BEGIN
	           -- start substring at the character after the first comma
	                SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
	                                                     @Pos + 1,
	                                                     LEN(@modifiedColumnsList)
	                                                     - @Pos);
	            END;
		END;
	END;
END
GO

ALTER TABLE [adm].[BusinessUnit] ENABLE TRIGGER [trgBusinessUnit]
GO

