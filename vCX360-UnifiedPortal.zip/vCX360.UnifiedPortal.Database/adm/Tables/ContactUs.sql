﻿CREATE TABLE [adm].[ContactUs]
(
	[ApplicationId] INT			  NOT NULL,
	[FirstName]     NVARCHAR(64)  NOT NULL,
	[LastName]      NVARCHAR(64)  NULL,
	[EMail]		    NVARCHAR(64)  NOT NULL,
	[Phone]		    NVARCHAR(20)  NOT NULL,
	[CompanyId]     INT           NOT NULL,
	[Country]	    NVARCHAR(64)  NOT NULL, 
	[Description]	NVARCHAR(MAX) NULL,

	CONSTRAINT [FK_ContactUs_ApplicationId] FOREIGN KEY (ApplicationId) REFERENCES [adm].[Application] ([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_ContactUs_CompanyId] FOREIGN KEY (ApplicationId) REFERENCES [adm].[Company] ([Id]) ON DELETE CASCADE


)
