﻿CREATE TABLE [adm].[Company]
(
	[Id]                  INT				 NOT NULL  DEFAULT NEXT VALUE FOR [adm].CompanyIdSeq,
    [CID]                 NVARCHAR (16)      NOT NULL,
    [Name]                NVARCHAR (64)      NOT NULL,
    [Status]              NVARCHAR (255)     NOT NULL,
    [Description]         NVARCHAR (512)     NULL,   
  
	[RowVersion]          ROWVERSION         NOT NULL,
    [Domain]              NVARCHAR (64)      NOT NULL DEFAULT '',
	
    [TenantId]            INT                NULL,
    [OrgId]               NVARCHAR (64)      NULL ,  
    [PurchaseSource]      NVARCHAR(128)      NULL,
	[GCAppVersion]        NVARCHAR(16)       NULL, 
    [OACStatus]           BIT                NOT NULL DEFAULT 0,
    IsProvisionNewBU      BIT                NOT NULL DEFAULT 1,
    [CoOAClientId]        INT                NULL,
    [IsDeleted]           BIT                 DEFAULT 0,
    [IntegrationType]     INT DEFAULT (1),
     --audit info
    [CreatedBy]           NVARCHAR (256)     NOT NULL,
    [CreatedDate]         DATETIME2 (0)		 NOT NULL CONSTRAINT [df_Company_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]           NVARCHAR (256)     NULL,
    [UpdatedDate]         DATETIME2 (0)	     NULL,

    --UNIQUE NONCLUSTERED ([CID] ASC, [Name] ASC) --replaced with individual unique constraints, making the composite one unique

    CONSTRAINT [PK_Company] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_CompanyName] UNIQUE ([Name]),
    CONSTRAINT [UQ_CompanyName_Domain] UNIQUE ([Name],[Domain]),
	CONSTRAINT [UQ_CompanyCID] UNIQUE ([CID]),
    CONSTRAINT [UQ_CompanyOrgId] UNIQUE ([OrgId]),
    CONSTRAINT [FK_company_Tenant] FOREIGN KEY ([TenantId]) REFERENCES [adm].[Tenant] ([TenantId]),
	
    CONSTRAINT [FK_company_OAuthClientId] FOREIGN KEY ([CoOAClientId]) REFERENCES [adm].[OAClient] ([Id])
);

GO



CREATE TRIGGER [adm].[trgCompany] ON [adm].[Company] 
FOR INSERT,	UPDATE,DELETE
AS

SET NOCOUNT ON;

DECLARE @sql VARCHAR(5000) ,
    @sqlInserted NVARCHAR(500) ,  
	@sqlDeleted NVARCHAR(500) ,
    @NewValue NVARCHAR(1000) ,
	@OldValue NVARCHAR(1000) ,
    @CreatedBy VARCHAR(50) ,  
	@CreatedOn DATETIME2(0) ,
	@UpdatedBy VARCHAR(50) ,
	@UpdatedOn DATETIME2(0) ,  
    @ParmDefinitionI NVARCHAR(2000) ,
	@ParmDefinitionD NVARCHAR(2000) ,
    @TABLE_NAME VARCHAR(100) ,
    @COLUMN_NAME VARCHAR(100) ,
    @modifiedColumnsList NVARCHAR(4000) ,
    @ColumnListItem NVARCHAR(500) ,
    @Pos INT ,
    @RecordPk VARCHAR(50) ,
    @RecordPkName VARCHAR(50),
	@ParentId VARCHAR(50),
	@ScreenName VARCHAR(50);
	Set @ScreenName='adm.Company';

	
SELECT  *
INTO    #deleted
FROM    deleted;
SELECT  *
INTO    #Inserted
FROM    inserted;

SET @TABLE_NAME = '[adm].[Company]';
SELECT  @CreatedBy = app_name(), @CreatedOn = Getdate() 
FROM    inserted;

SELECT  @UpdatedBy = app_name()
, @UpdatedOn = Getdate() ,@ParentId = TenantId
FROM    inserted;

--INSERT
IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)  
BEGIN
    SELECT  @RecordPk = Id --Change to the table primary key field
    FROM    inserted;   
    IF(@RecordPk IS NOT NULL) 
    BEGIN
        SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
                                       FROM     sys.columns
                                       WHERE   name != 'RowVersion' and name != 'UpdatedDate' 
    								   and name != 'UpdatedBy' and name != 'CreatedBy' and name != 'CreatedDate'
    								   and object_id = OBJECT_ID(@TABLE_NAME)                                           
                                     FOR
                                       XML PATH('')
                                     ), 1, 1, '');
    
        WHILE LEN(@modifiedColumnsList) > 0
        BEGIN
            SET @Pos = CHARINDEX(',', @modifiedColumnsList);
            IF @Pos = 0
                BEGIN
                    SET @ColumnListItem = @modifiedColumnsList;
                END;
            ELSE
                BEGIN
                    SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
                                                    @Pos - 1);
                END;    
    		
            SET @COLUMN_NAME = @ColumnListItem;
          
            SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
           
            SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
                + ' FROM #Inserted where ID = ' 
                + CONVERT(VARCHAR(50), @RecordPk);
    		
            EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
                @NewValueOut = @NewValue OUTPUT;
    
            if(ISNULL(@NewValue,'') != '')
    		BEGIN                 
    		    INSERT INTO [dbo].[TableConfigChangeLogs](				   
    				 [Table]    
    				 ,[ColumnName]    
    				 ,[NewValue]  				
    				 ,[UserName]      
    				 ,[ActionDate]
    				 ,[Action]    
    				 ,[KeyValue]
    				 ,[ParentId]
    				 )
    				 values(@ScreenName,@COLUMN_NAME,@NewValue,@CreatedBy,@CreatedOn,'Insert',@RecordPk,@ParentId)   
             END         
            SET @COLUMN_NAME = '';
            SET @NewValue = '';
           
            IF @Pos = 0
                BEGIN
                    SET @modifiedColumnsList = '';
                END;
            ELSE
                BEGIN
               -- start substring at the character after the first comma
                    SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
                                                         @Pos + 1,
                                                         LEN(@modifiedColumnsList)
                                                         - @Pos);
                END;
        END;
    END;
END
--UPDATE  
IF EXISTS (SELECT * FROM inserted ) AND EXISTS (SELECT * FROM deleted WHERE IsDeleted = 0)
BEGIN
    SELECT  @RecordPk = Id --Change to the table primary key field
    FROM    inserted;   
    
    IF(@RecordPk IS NOT NULL) 
    BEGIN
        SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
                                       FROM     sys.columns
                                       WHERE   name != 'RowVersion' and name != 'CreatedDate' and name != 'CreatedBy'
    								   and name != 'UpdatedDate' and name != 'UpdatedBy'
    								   and object_id = OBJECT_ID(@TABLE_NAME)                                           
                                     FOR
                                       XML PATH('')
                                     ), 1, 1, '');
    
    
        WHILE LEN(@modifiedColumnsList) > 0
        BEGIN
            SET @Pos = CHARINDEX(',', @modifiedColumnsList);
            IF @Pos = 0
                BEGIN
                    SET @ColumnListItem = @modifiedColumnsList;
                END;
            ELSE
                BEGIN
                    SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
                                                    @Pos - 1);
                END;    
    
            SET @COLUMN_NAME = @ColumnListItem;
            SET @ParmDefinitionD = N'@OldValueOut NVARCHAR(1000) OUTPUT';
            SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
            SET @sqlDeleted = N'SELECT @OldValueOut=' + @COLUMN_NAME
                + ' FROM #deleted where ID = ' + CONVERT(VARCHAR(50), @RecordPk);
            SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
                + ' FROM #Inserted where ID =' + CONVERT(VARCHAR(50), @RecordPk);
            EXECUTE sp_executesql @sqlDeleted, @ParmDefinitionD,
                @OldValueOut = @OldValue OUTPUT;
            EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
                @NewValueOut = @NewValue OUTPUT;
            IF ( LTRIM(RTRIM(ISNULL(@NewValue,''))) != LTRIM(RTRIM(ISNULL(@OldValue,''))) )
                BEGIN  
    			INSERT INTO [dbo].[TableConfigChangeLogs](				   
    				 [Table]    
    				 ,[ColumnName]    
    				 ,[NewValue]  
    				 ,[OldValue]  
    				 ,[UserName]      
    				 ,[ActionDate]
    				 ,[Action]    
    				 ,[KeyValue]
    				 ,[ParentId]
    				 )
    				 values(@ScreenName,@COLUMN_NAME,ISNULL(@NewValue,''),ISNULL(@OldValue,''),@UpdatedBy,@UpdatedOn,'Update',@RecordPk,@ParentId)   
    			
                END;     
            SET @COLUMN_NAME = '';
            SET @NewValue = '';
            SET @OldValue = '';
            IF @Pos = 0
                BEGIN
                    SET @modifiedColumnsList = '';
                END;
            ELSE
                BEGIN
               -- start substring at the character after the first comma
                    SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
                                                         @Pos + 1,
                                                         LEN(@modifiedColumnsList)
                                                         - @Pos);
                END;
        END;
    END;
END
--DELETE
IF EXISTS (SELECT * FROM deleted ) AND NOT EXISTS(SELECT * FROM inserted)
BEGIN
	
    SELECT  @RecordPk = Id --Change to the table primary key field
    FROM    DELETED;   
    
    SELECT  @UpdatedBy = app_name()
    , @UpdatedOn = Getdate() ,@ParentId=TenantId
    FROM    deleted;
    IF(@RecordPk IS NOT NULL) 
    BEGIN
        SET @modifiedColumnsList = STUFF(( SELECT   ',' + name
                                       FROM     sys.columns
                                       WHERE   name != 'RowVersion' and name != 'UpdatedDate' 
    								   and name != 'UpdatedBy' and name != 'CreatedBy' and name != 'CreatedDate'
    								   and object_id = OBJECT_ID(@TABLE_NAME)                                           
                                     FOR
                                       XML PATH('')
                                     ), 1, 1, '');
    
    
        WHILE LEN(@modifiedColumnsList) > 0
        BEGIN
            SET @Pos = CHARINDEX(',', @modifiedColumnsList);
            IF @Pos = 0
                BEGIN
                    SET @ColumnListItem = @modifiedColumnsList;
                END;
            ELSE
                BEGIN
                    SET @ColumnListItem = SUBSTRING(@modifiedColumnsList, 1,
                                                    @Pos - 1);
                END;    
    		
    
    		SET @COLUMN_NAME = @ColumnListItem;
    
    
            SET @ParmDefinitionI = N'@NewValueOut NVARCHAR(1000) OUTPUT';
           
            SET @sqlInserted = N'SELECT @NewValueOut=' + @COLUMN_NAME
                + ' FROM #DELETED where ID = ' 
                + CONVERT(VARCHAR(50), @RecordPk);
    
            EXECUTE sp_executesql @sqlInserted, @ParmDefinitionI,
                @NewValueOut = @NewValue OUTPUT;
    
            if(ISNULL(@NewValue,'') != '')
    		BEGIN                 
    		INSERT INTO [dbo].[TableConfigChangeLogs](				   
    				 [Table]    
    				 ,[ColumnName]    
    				 ,[OldValue]  				
    				 ,[UserName]      
    				 ,[ActionDate]
    				 ,[Action]    
    				 ,[KeyValue]
    				 ,[ParentId]
    				 )
    				 values(@ScreenName,@COLUMN_NAME,@NewValue,@UpdatedBy,@UpdatedOn,'Delete',@RecordPk,@ParentId)   
            END         
            SET @COLUMN_NAME = '';
            SET @NewValue = '';
           
            IF @Pos = 0
                BEGIN
                    SET @modifiedColumnsList = '';
                END;
            ELSE
                BEGIN
               -- start substring at the character after the first comma
                    SET @modifiedColumnsList = SUBSTRING(@modifiedColumnsList,
                                                         @Pos + 1,
                                                         LEN(@modifiedColumnsList)
                                                         - @Pos);
                END;
        END;
    END;
END
GO

ALTER TABLE [adm].[Company] ENABLE TRIGGER [trgCompany]
GO




--CREATE TRIGGER [adm].[trgCompany] 
--ON [adm].[Company]
--AFTER INSERT, UPDATE ,DELETE
--AS 
--BEGIN
--	-- UPDATE
--	IF EXISTS (SELECT * FROM inserted WHERE IsDeleted = 0 ) AND EXISTS (SELECT * FROM deleted WHERE IsDeleted = 0)
--	BEGIN
--		INSERT INTO [adm].[SyncDataDetails] (
--		    [CompanyId],		
--		    [AppId],			
--		    [EntityName],
--		    [EntityId],
--			[EntityAction],
--		    [EntityStatus],
--		    [InSync],
--			[CreatedBy],
--			[CreatedDate],
--		    [UpdatedBy],  
--		    [UpdatedDate]
--		)
--		SELECT 
--		    i.Id ,
--		    cba.ApplicationId ,
--		    N'adm.Company',
--		    i.Id ,
--			N'UPDATE',
--		    N'New' ,
--		    0 ,
--			i.CreatedBy,
--			i.CreatedDate,
--		    i.UpdatedBy ,
--		    i.UpdatedDate
--		FROM inserted i 
--		JOIN [adm].[CompanyBusinessUnitAppMap] cba
--		ON i.Id = cba.CompanyId
--		--where i.IsDeleted=0	;
--		END
--	--INSERT
--	IF EXISTS (SELECT * FROM inserted WHERE IsDeleted = 0 )
--	BEGIN
--		INSERT INTO [adm].[SyncDataDetails] (
--		    [CompanyId],		
--		    [AppId],			
--		    [EntityName],
--		    [EntityId],
--			[EntityAction],
--		    [EntityStatus],
--		    [InSync],
--			[CreatedBy],
--			[CreatedDate],
--		    [UpdatedBy],  
--		    [UpdatedDate]
--		)
--		SELECT 
--		    i.Id ,
--		    cba.ApplicationId ,
--		    N'adm.Company',
--		    i.Id ,
--			N'INSERT',
--		    N'New' ,
--		    0 ,
--			i.CreatedBy,
--			i.CreatedDate,
--		    i.UpdatedBy ,
--		    i.UpdatedDate
--		FROM inserted i 
--		JOIN [adm].[CompanyBusinessUnitAppMap] cba
--		ON i.Id = cba.CompanyId
--		--where i.IsDeleted=0	;
--		END
--	IF EXISTS (SELECT * FROM deleted WHERE IsDeleted = 0) AND EXISTS(SELECT * FROM inserted WHERE IsDeleted = 1)
--	BEGIN
--		--DELETE
		
--	   INSERT INTO [adm].[SyncDataDetails] (
--        [CompanyId],		
--        [AppId],			
--        [EntityName],
--        [EntityId],	
--		[EntityAction],
--        [EntityStatus],
--        [InSync],
--        [CreatedBy],
--        [CreatedDate],
--        [UpdatedBy],  
--        [UpdatedDate]
--		)
--	  SELECT 
--        d.Id, 
--        cba.ApplicationId,
--        N'adm.Company', 
--        d.Id, 
--		N'DELETE',
--        N'New',  
--        0, 
--        d.CreatedBy,
--        d.CreatedDate,
--        d.UpdatedBy,
--        d.UpdatedDate
--      FROM deleted d 
--      JOIN [adm].[CompanyBusinessUnitAppMap] cba
--        ON d.Id = cba.CompanyId;
--	END
--END;
--GO
 
 
--ALTER TABLE [adm].[Company] ENABLE TRIGGER [trgCompany]