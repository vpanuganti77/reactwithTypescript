﻿CREATE TABLE [adm].[OAClientMapping]
(
	[OAClientId]		INT NOT NULL ,
	[CompanyId]			INT NOT NULL ,
	[BusinessUnitId]    INT NULL  ,
	[ApplicationId]		INT NULL  

	CONSTRAINT [FK_OAClientMapping_OAClientId] FOREIGN KEY (OAClientId) REFERENCES [adm].[OAClient] ([Id]) ON DELETE CASCADE,

	CONSTRAINT [FK_OAClientMapping_Company_Id] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]) ON DELETE NO ACTION,
	CONSTRAINT [FK_OAClientMapping_BusinessUnit_Id] FOREIGN KEY ([BusinessUnitId]) REFERENCES [adm].[BusinessUnit] ([Id])  ON DELETE NO ACTION ,
	CONSTRAINT [FK_OAClientMapping_Application_Id] FOREIGN KEY (ApplicationId) REFERENCES [adm].[Application] ([Id])  ON DELETE NO ACTION ,

	
	CONSTRAINT [UQ_OAClientMapping] UNIQUE (CompanyId, BusinessUnitId, ApplicationId,OAClientId)

)
