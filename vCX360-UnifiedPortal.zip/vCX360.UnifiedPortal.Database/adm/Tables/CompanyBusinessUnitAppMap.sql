﻿CREATE TABLE [adm].[CompanyBusinessUnitAppMap]
(
	CompanyId	    INT NOT NULL,
	BusinessUnitId	INT NULL,
	ApplicationId	INT NOT NULL

	CONSTRAINT [FK_CompanyBusinessUnitAppMap_ApplicationId] FOREIGN KEY (ApplicationId) REFERENCES [adm].[Application] ([Id]) ON DELETE CASCADE,

	CONSTRAINT [FK_CompanyBusinessUnitAppMap_Company_Id] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_CompanyBusinessUnitAppMap_BusinessUnit_Id] FOREIGN KEY ([BusinessUnitId]) REFERENCES [adm].[BusinessUnit] ([Id]) ,
	
	CONSTRAINT [UQ_CompanyBusinessUnitApp] UNIQUE (CompanyId, BusinessUnitId, ApplicationId)
)
