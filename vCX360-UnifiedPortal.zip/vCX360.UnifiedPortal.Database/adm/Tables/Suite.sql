﻿CREATE TABLE [adm].[Suite]
(	
	[Id]	        INT 	        NOT NULL  DEFAULT NEXT VALUE FOR [adm].SuiteIdSeq ,       
    [CID]	        NVARCHAR (16)   NOT NULL,
    [Name]	        NVARCHAR (64)   NOT NULL,
    [Status]        NVARCHAR (255)  NOT NULL  DEFAULT ('') ,
    [Description]  	NVARCHAR (1000) NULL,
    [IsDeleted]     BIT DEFAULT 0,
  
  --audit info
    [CreatedBy]     NVARCHAR (256)   NOT NULL,
    [CreatedDate]   DATETIME2 (0)	 NOT NULL CONSTRAINT [df_Suite_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]     NVARCHAR (256)   NULL,
    [UpdatedDate]   DATETIME2 (0)	 NULL,

    CONSTRAINT [PK_Suite] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_SuiteName] UNIQUE ([Name]),
    CONSTRAINT [UQ_Suite_CID] UNIQUE ([CID])
)
