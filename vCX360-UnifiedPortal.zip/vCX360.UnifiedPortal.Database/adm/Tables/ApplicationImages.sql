﻿CREATE TABLE [adm].[ApplicationImages]
(
	[ApplicationId] INT			   NULL,
	[Image]			VARBINARY(MAX) NULL,

	CONSTRAINT [FK_ApplicationImages_ApplicationId] FOREIGN KEY (ApplicationId) REFERENCES [adm].[Application] ([Id]) ON DELETE CASCADE

)
