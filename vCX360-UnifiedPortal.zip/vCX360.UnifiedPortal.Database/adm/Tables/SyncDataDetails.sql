﻿CREATE TABLE [adm].[SyncDataDetails]
(
	[Id]			INT			  NOT NULL DEFAULT NEXT VALUE FOR [adm].SyncDataDetailsIdSeq,       
	[CompanyId]		INT			  NOT NULL,
	[AppId]			INT			  NOT NULL,
	[EntityName]	NVARCHAR(255) NOT NULL,
	[EntityId]		INT			  NOT NULL,
	[EntityAction]	NVARCHAR(10)  NOT NULL,
	[EntityStatus]	NVARCHAR(50)  NOT NULL,
	[InSync]		BIT, --DEFAULT 0,

  --audit info
    [CreatedBy]     NVARCHAR (256)  NOT NULL,
    [CreatedDate]   DATETIME2 (0)	NOT NULL CONSTRAINT [df_SuncDataDetails_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]     NVARCHAR (256)  NULL,
    [UpdatedDate]   DATETIME2 (0)	NULL,

	CONSTRAINT [PK_SyncDataDetails] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [FK_SyncDataDetails_CompanyId] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]) ON DELETE CASCADE,

	CONSTRAINT [FK_SyncDataDetails_AppId] FOREIGN KEY (AppId) REFERENCES [adm].[Application] ([Id]) ON DELETE CASCADE

)
