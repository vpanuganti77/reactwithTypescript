﻿CREATE TABLE [adm].[OAClient]
(
    [Id]                    INT             NOT NULL    DEFAULT NEXT VALUE FOR [adm].[OAClientIdSeq],
    [Name]                  NVARCHAR(512)   NOT NULL, 
    [ClientIdEnc]           NVARCHAR(256)   NOT NULL, 
    [SecretEnc]             NVARCHAR(1024)  NOT NULL, 
    [RegionId]              INT             NOT NULL, 
    [LastValidationStatus]  NVARCHAR (64)   NULL,
	[LastValidationDate]    DATETIME2 (0)	NULL,
    [CompanyId]				INT             NOT NULL    DEFAULT 1,
    [IsDeleted]             BIT DEFAULT 0,
     --audit info
    [CreatedBy]             NVARCHAR (64)   NOT NULL    DEFAULT ('unknown'),
    [CreatedDate]           DATETIME2 (0)   NOT NULL    CONSTRAINT [df_OAClient_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]             NVARCHAR (64)   NULL,
    [UpdatedDate]           DATETIME2 (0)   NULL,

  

    CONSTRAINT [PK_OAClient] PRIMARY KEY CLUSTERED ([Id]),
    CONSTRAINT [UQ_OAClient_Name] UNIQUE ([Name]),
    CONSTRAINT [FK_OAClient_Region] FOREIGN KEY ([regionId]) REFERENCES [adm].[Region] ([Id]),
    CONSTRAINT [FK_OAClient_Company] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company] ([Id]) ON DELETE CASCADE
)
GO

CREATE INDEX [IX_OAClient_Name] ON [adm].[OAClient] ([Name])
GO
