﻿
CREATE TABLE [adm].FeedbackResponse
(
	Id				INT			  NOT NULL DEFAULT NEXT VALUE FOR [adm].[FeedbackResponseIdSeq] ,
	FeedbackId	    INT			  NULL,
	Response		NVARCHAR(255) NOT NULL,
	UserId			INT			  NOT NULL,
	IsDeleted		BIT DEFAULT 0,
		--audit info
	[CreatedBy]     NVARCHAR (256)  NOT NULL DEFAULT ('unknown'),
	[CreatedDate]   DATETIME2 (0)	NOT NULL CONSTRAINT [df_FeedbackResponse_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
	[UpdatedBy]     NVARCHAR (256)  NULL,
	[UpdatedDate]   DATETIME2 (0)	NULL,

	
	CONSTRAINT [PK_FeedbackResponse_Id] PRIMARY KEY CLUSTERED ([Id]),
    CONSTRAINT [FK_Feedback_FeedbackResponse] FOREIGN KEY ([FeedbackId]) REFERENCES [adm].[Feedback] ([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_User_FeedbackResponse] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]) ON DELETE CASCADE

)



