﻿CREATE VIEW [adm].[vw_CompanyBusinessUnit]
	AS SELECT 
		c.Id as CompanyId, 
		c.[Name] as CompanyName, 
		c.[Description] as CompanyDescription,
		c.CID as CompanyCID,		
		b.Id as BuId, 
		b.[Name] as BuName, 
		b.[Description] as BuDescription,
		b.CID as BuCID,
		c.Domain as Domain,
		IIF(isnull(b.Domain,'') ='', c.Domain, b.Domain) as BUDomain
	from [adm].[Company] c
	left join [adm].[BusinessUnit] b on c.Id = b.CompanyId

