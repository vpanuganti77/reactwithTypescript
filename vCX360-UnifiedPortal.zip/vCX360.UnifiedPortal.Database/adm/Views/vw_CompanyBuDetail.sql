﻿CREATE VIEW [adm].[vw_CompanyBuDetail]
	AS SELECT
		c.Id as CompanyId, 
		c.CID AS CompanyCID,
		c.[Name] as CompanyName,
		c.[Status] AS CompanyStatus,
		c.[Description] as CompanyDescription,
		c.[TenantId] as TenantId,
		c.OrgId as OrgId,
		c.[IntegrationType] as IntegrationType,
		c.[IsDeleted] as IsDeleted,
		c.CreatedBy AS CompanyCreatedBy,
		c.CreatedDate AS CompanyCreatedDate,
		c.UpdatedBy AS CompanyUpdatedBy,
		c.UpdatedDate AS CompanyUpdatedDate,
		b.Id as BuId, 
		b.CID AS BuCID,
		b.[Name] as BuName,
		b.[Status] AS BuStatus,
		b.[Description] as BuDescription,
		b.CreatedBy AS BuCreatedBy,
		b.CreatedDate AS BuCreatedDate,
		b.UpdatedBy AS BuUpdatedBy,
		b.UpdatedDate AS BuUpdatedDate,
		b.Number AS BuNumber,		
		c.Domain as Domain,
		IIF(isnull(b.Domain,'') ='', c.Domain, b.Domain) as BUDomain
	from [adm].[Company] c
	left join [adm].[BusinessUnit] b on c.Id = b.CompanyId
