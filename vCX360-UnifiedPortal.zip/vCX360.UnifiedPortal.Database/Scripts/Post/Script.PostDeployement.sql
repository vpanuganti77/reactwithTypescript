﻿
/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/



:r .\DisableAllTriggers.sql
:r .\ApplicationSeedData.sql
:r .\FeatureLookupData.sql
:r .\CompanyBUSeedData.sql
:r .\PermissionLookupData.sql
:r .\RoleTypeLookupData.sql
:r .\RoleSeedData.sql
:r .\UserSeedData.sql
:r .\NavItemLookupData.sql
:r .\NavItemFeatureMapLookupData.sql
:r .\SuiteLookUpData.sql
:r .\RegionSeedData.sql
:r .\PlatformSeedData.sql
:r .\TenantSeedData.sql
:r .\DomainSeedData.sql


:r .\EnableAllTriggers.sql

:r .\FeedbackSeedData.sql
:r .\FeedbackResponseSeedData.sql

:r .\OAClientSeedData.sql