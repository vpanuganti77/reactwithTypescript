﻿declare @suite Table
(
	[Id]	        SMALLINT ,	       
    [CID]	        NVARCHAR (16)   NOT NULL,
    [Name]	        NVARCHAR (64)   NOT NULL,
    [Status]        NVARCHAR (255)  NOT NULL
    );


insert into @suite values(1,N'vCX360',N'vCX360',N'active');


merge [adm].[Suite] t
using @suite s
on (t.Id = s.Id)
when not matched by target
	then insert ([Id], [CID], [Name], [Status], [CreatedBy])
	values (s.[Id], s.[CID], s.[Name],s.[Status], 'Post Deployment script')
when matched
	then update set
		t.[CID] = s.[CID],
		t.[Name] = s.[Name],
		t.[Status] = s.[Status];
Go