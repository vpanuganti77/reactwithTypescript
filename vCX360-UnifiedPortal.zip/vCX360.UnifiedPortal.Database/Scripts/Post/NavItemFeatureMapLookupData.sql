﻿--declare @navItemFeatureMap table
--(
--	NavItemId int,
--	FeatureId int
--);

--insert into @navItemFeatureMap values
----FEATURE: Voice Surveys (1)
--( 1, 1), --Administration (category)
--( 2, 1), --Domains
--( 3, 1), --OAClients
--( 4, 1), --Organization
--( 5, 1), --Users
--( 6, 1), --Email Templates

----FEATURE: Dashboards
--(11, 2), --Dashboard Category
--(12, 2), --All Org Summary
--(13, 2), --Org Detail

----FEATURE: Monitoring
--(21, 3), --Monitoring Category
--(22, 3), --Rules
--(23, 3), --Raised Alerts
--(24, 3); --Current App Monitoring

----todo: change/add links as needed

--merge [sec].[AppNavItemFeatureMap] t
--using @navItemFeatureMap s
--on (t.NavItemId = s.NavItemId and t.FeatureId = s.FeatureId)
--when not matched by target
--	then insert (NavItemId, FeatureId)
--	values (s.NavItemId, s.FeatureId)
--when not matched by source
--	then delete;

--GO
