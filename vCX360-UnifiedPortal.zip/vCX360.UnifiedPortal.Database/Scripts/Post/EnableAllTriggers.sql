﻿sp_msforeachtable 'ALTER TABLE ? ENABLE TRIGGER all';
GO