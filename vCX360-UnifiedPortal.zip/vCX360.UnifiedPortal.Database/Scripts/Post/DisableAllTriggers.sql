﻿sp_msforeachtable 'ALTER TABLE ? DISABLE TRIGGER all' ;
print app_name()

GO