﻿
declare @ids table (id int);
declare @u NVARCHAR(255) = N'SurveyScript';
declare @c NVARCHAR(16) = N'Default';
declare @b NVARCHAR(16) = N'Default';
declare @t datetime2(0) = CURRENT_TIMESTAMP;

If not exists (select * from [adm].Company)-- where CID = @c)
insert into [adm].Company 
(CID, Name, Status, Description, CreatedBy, CreatedDate)
output inserted.Id into @ids
values
(@c, @c, N'Inactive',@c, @u, @t);

declare @cid int = (select top(1) id from @ids);

if not exists (select * from [adm].BusinessUnit) -- where CID = @b)
insert into [adm].BusinessUnit
(CID, Name, Status, Description, CreatedBy, CreatedDate, CompanyId, Number)
values
(@b, @b, N'Inactive', @b, @u, @t, @cid, 101);

GO

-- --for the company (or any company without a schedule), must create a schedule (all companies have default schedule):
-- declare @ws  [adm].[ttDayOfWeekTimeInterval] ;
-- insert into @ws values
-- (1, '9:00:00', '17:00:00'),
-- (2, '9:00:00', '17:00:00'),
-- (3, '9:00:00', '17:00:00'),
-- (4, '9:00:00', '17:00:00'),
-- (5, '9:00:00', '17:00:00');
-- 
-- declare @tbl as table
-- (id int, rn int);
-- 
-- with cte1 as
-- (select 
-- 	id, 
-- 	ROW_NUMBER() over (ORDER BY id ASC) as RN 
-- 	from [adm].Company
-- 	where id not in (select companyId from [adm].operatingSchedule)
-- )
-- insert into @tbl
-- select id, rn from cte1;
-- 
-- declare @cnt int = (select count(id) from @tbl);
-- declare @id int;
-- 
-- while (@cnt > 0)
-- begin
-- 	set @id = (select top(1) id from @tbl where rn = @cnt);
-- 
-- 	exec [adm].spCreateWeekScheduleForEntity 
-- 		@ws, 
-- 		@id,
-- 		'Company',
-- 		'PostDeploymentScript'	
-- 	set @cnt = @cnt -1;
-- end;
-- 
-- 
-- /* validation: to ensure there are no companies left without schedule:*/
-- if exists 
-- (select 
-- 	id, 
-- 	ROW_NUMBER() over (ORDER BY id ASC) as RN 
-- 	from [adm].Company
-- 	where id not in (select companyId from [adm].operatingSchedule)
-- )
-- print 'ERROR: there are companies without schedule'
-- else print 'OK: all companies have schedules';
--  
-- --- Company Domain migartion -- while adding  domain coumn first time it is empty, it shoudl be updated with give domain name 
-- DECLARE @domain VARCHAR(100)  = '$(domain)';
-- update [adm].Company Set Domain = @domain where ISnull(Domain,'') = ''  -- this should be chnage based on company's info
-- GO