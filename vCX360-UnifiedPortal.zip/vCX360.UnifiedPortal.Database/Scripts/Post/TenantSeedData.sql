﻿declare @Tenant table
(
	[TenantId]          INT NOT NULL ,
	[TenantCID]			NVARCHAR(100) NOT NULL,
	[TenantName]	    NVARCHAR(100) NOT NULL,
	[ParentTenantId]    SMALLINT	  NULL,
	[PlatformId]	    SMALLINT	  NULL,
	[ConnectionString]  NVARCHAR(100) NULL,
	[Description]	    NVARCHAR(MAX) NULL,
	[Contact]           NVarchar(100) NULL
);

insert into @Tenant values(1,N'Default',N'Default',1,1,N' 9876543210',N'Description',N'Contact@company.com');



merge [adm].[Tenant] t
using @Tenant s
on (t.[TenantId] = s.[TenantId])
when not matched by target
	then insert ([TenantId],[TenantCID], [TenantName], [ParentTenantId],[PlatformId],[ConnectionString] ,[Description], [Contact],[CreatedBy])
	values (s.[TenantId],s.[TenantCID], s.[TenantName], s.[ParentTenantId],s.[PlatformId], s.[ConnectionString] , s.[Description],s.[Contact],N'Post Deployment script')
when matched
	then update set
		t.[TenantName]		  = s.[TenantName],
		t.[TenantCID]		  = s.[TenantCID], 
		t.[ParentTenantId]    = s.[ParentTenantId],
		t.[PlatformId]		  = s.[PlatformId],
		t.[ConnectionString]  = s.[ConnectionString],
		t.[Description]	      = s.[Description],
		t.[Contact]           = s.[Contact];
Go


