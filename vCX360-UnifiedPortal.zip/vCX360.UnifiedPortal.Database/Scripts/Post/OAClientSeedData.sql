﻿
declare @u NVARCHAR(255) = N'SurveyScript';
declare @c NVARCHAR(16) = N'Default';
declare @b NVARCHAR(16) = N'Default';
declare @t datetime2(0) = CURRENT_TIMESTAMP;
declare @s nvarchar(500) = 'PrvGVZ3JmKnT1JxM2XHn7A==';

if not exists (select * from adm.OAClient)
insert into adm.OAClient
( Name, SecretEnc,ClientIdEnc, RegionId, CreatedBy, CreatedDate, CompanyId)
values
(@b,@s,@b,1,@u,@t,1);
