﻿Declare @Domain table
(
	[Id]                        INT            NOT NULL ,
    [Name]                      NVARCHAR(64)   NOT NULL,
    [LDAP]                      NVARCHAR(1024) NOT NULL,
    [UserName]                  NVARCHAR(128)  NULL,
    [Password]                  NVARCHAR(1024) NULL,
    [AllowsUserManagement]      BIT            NOT NULL
);

insert into @Domain
values(1,N'amazon.com',N'amazon.com',N' developer',NULL,0);


merge [adm].[Domain] t
using @Domain s
on (t.[Id] = s.[Id])
when not matched by target
	then insert ([Id], [Name], [LDAP], [UserName],[Password],[AllowsUserManagement],[CreatedBy])
	values (s.[Id], s.[Name], s.[LDAP],s.[UserName],s.[Password],s.[AllowsUserManagement],N'Post Deployment script')
when matched
	then update set
		t.[Name] = s.[Name],
		t.[LDAP] = s.[LDAP],
		t.[UserName] = s.[UserName],
		t.[Password] = s.[Password],
		t.[AllowsUserManagement] = s.[AllowsUserManagement];

Go

