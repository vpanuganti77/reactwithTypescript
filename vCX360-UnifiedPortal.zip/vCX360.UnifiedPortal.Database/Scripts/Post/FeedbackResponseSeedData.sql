﻿Declare @FeedbackResponse table
(
	Id				INT			  NOT NULL  ,
	FeedbackId	    INT			  NOT NULL,
	Response		NVARCHAR(255) NOT NULL,
	UserId			INT			  NOT NULL
);

insert into @FeedbackResponse values(1,1,'Please log in again and check. This issue typically occurs when the session has expired.',1);


merge [adm].[FeedbackResponse] t
using @FeedbackResponse s
on (t.[Id] = s.[Id])
when not matched by target
	then insert (FeedbackId, Response, UserId,[CreatedBy])
	values (s.FeedbackId, s.Response, s.UserId,N'Post Deployment script')
when matched
	then update set
		t.[FeedbackId] = s.[FeedbackId],
		t.[Response] = s.[Response],
		t.UserId = s.UserId;

Go
