﻿DECLARE @Platform TABLE
(
	Id				SMALLINT    NOT NULL,
	[Name]			VARCHAR(100)  NOT NULL
);

insert into @Platform values(1,'Genesys'),(2,'AmazonConnect');


Merge [adm].[Platform] t
using @Platform s
on t.Id = s.Id
when not matched by target
	then insert  (Id,[Name]) values(s.Id,s.[Name])
when matched 
Then Update set
		t.[Name] = s.[Name];

GO
