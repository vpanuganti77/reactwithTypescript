﻿DECLARE @Application TABLE
(
	[Id]	        SMALLINT 		NOT NULL,
    [CID]	        NVARCHAR (16)   NOT NULL,
    [Name]	        NVARCHAR (64)   NULL,
	[Type]          NVARCHAR (64)   NULL,   
    [Status]        NVARCHAR (255)  NULL,
    [SuiteId]       SMALLINT        NULL
);

insert into @Application values
(1,N'vCX360',N'vCX360',N'Product',N'Active',1),
(2,N'CloudCXDashboard',N'CloudCXDashboard',N'Product',N'Active',1),
(3,N'vInteract',N'vInteract',N'Product',N'Active',1),
(4,N'DataStore',N'DataStore',N'Product',N'Active',1),
(5,N'ManagedServices',N'ManagedServices',N'Service',N'Active',1);


merge [adm].[Application] t
using @Application s
on (t.Id = s.Id)
when not matched by target
	then insert ([CID], [Name],[Type], [Status],[SuiteId],[CreatedBy])
	values (s.[CID], s.[Name],s.[Type],s.[Status], s.[SuiteId],'Post Deployment script')
when matched
	then update set
		t.[CID] = s.[CID],
		t.[Name] = s.[Name],
		t.[Type] = s.[Type],
		t.[Status] = s.[Status],
		t.[SuiteId] = s.[SuiteId];

Go
