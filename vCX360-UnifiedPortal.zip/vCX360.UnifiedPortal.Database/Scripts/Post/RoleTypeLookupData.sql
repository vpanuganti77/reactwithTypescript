﻿declare @roleType table
(
	[Id] TINYINT NOT NULL,
	[Name] varchar(50) NOT NULL,
	[Description] varchar(100) 
);

insert into @roleType values
(0, 'PermissionRole', 'Role tied to R/W permission access'),
(1, 'SpecialRole', 'Super User or other super admin role'),
(2, 'EnterpriseRole', 'Company-level admin role - Given single company ... not applicable'),
(3, 'OrganizationRole', 'Role tied to a Organization[BU]'),
(4, 'FeatureRole', 'Role tied to a Feature'),
(100, 'Custom', 'Other type'); 
--todo add as needed

merge [dbo].[RoleType] t
using @roleType s
on (t.Id = s.Id)
when not matched by target
	then insert (Id, [Name], [Description])
	values (s.Id, s.[Name], s.[Description])
when matched
	then update set
		t.[Name] = s.[Name],
		t.[Description] = s.[Description]
when not matched by source
	then delete
output $action, inserted.*, deleted.*;

GO