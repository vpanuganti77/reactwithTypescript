﻿declare @feature table
(
	[Id] INT NOT NULL,
	[Cid] varchar(50) NOT NULL,
	[Name] varchar(50) NOT NULL,
	[Enabled] bit not null,
	[IsLicensable] bit not null
);

insert into @feature values
( 0, 'None', 'None (BU created)', 1, 0),

( 1, 'VoiceSurvey', 'Voice Survey', 1, 1),
( 2, 'WebSurvey', 'Web Survey', 1, 1),
( 3, 'IVRProv', 'IVR Provisioning', 1, 1),
(10, 'LoBAdmin', 'LoB Admin', 1, 0),
(11, 'UserMgmt', 'User Management', 1, 0),
(12, 'Other', 'Other', 1, 0),
(13, 'SurveyDeployment', 'Survey Deployment', 1, 0),
(14, 'Reporting', 'Reporting', 1, 0); 

merge [sec].[Feature] t
using @feature s
on (t.Id = s.Id)
when not matched by target
	then insert (Id, [CID], [Name], [Enabled], [IsLicensable])
	values (s.Id, s.[Cid], s.[Name], s.[Enabled], s.[IsLicensable])
when matched
	then update set
		t.[CID] = s.[Cid],
		t.[Name] = s.[Name],
		t.[Enabled] = s.[Enabled],
		t.[IsLicensable] = s.[IsLicensable]
-- when not matched by source then delete
output $action, inserted.*, deleted.*;

GO