﻿Declare @Feedback table
(
	Id				INT			   NOT NULL,
	FeedbackType	NVARCHAR(64)   NOT NULL,
	ApplicationId	INT			   NULL,
	ApplicationType NVARCHAR(64)   NOT NULL,
	[Status]        NVARCHAR(255)  NOT NULL
);

insert into @Feedback 
values(1,N'Bug',1,N'Product',N'Active');


merge [adm].[Feedback] t
using @Feedback s
on (t.Id = s.Id)
when not matched by target
	then insert (FeedbackType, ApplicationId, ApplicationType,[Status],[CreatedBy])
	values (s.FeedbackType, s.ApplicationId,s.ApplicationType,s.[Status],N'Post Deployment script')
when matched
	then update set
		t.FeedbackType = s.FeedbackType,
		t.ApplicationId = s.ApplicationId,
		t.ApplicationType = s.ApplicationType,
		t.[Status] = s.[Status];
Go
