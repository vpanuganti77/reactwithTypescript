﻿DECLARE @navItem TABLE
(
	[Id] INT NOT NULL,
	[ParentId] INT NULL,
	[DisplayName] VARCHAR(100) NOT NULL,	
	[NavLink] VARCHAR(100) NULL,
	[Description]  NVARCHAR(2000) NULL,
	[ToolTip] VARCHAR(200) NULL,
	[Order] TINYINT NOT NULL,
	[Group] TINYINT NOT NULL
);




INSERT INTO @navItem VALUES --todo: populate tooltips below, instead of nulls.
(1, null, 'Administration', null, N'Admin Operations', null, 1, 0), 
(2, 1, 'Domain Management', 'dmnMgmt',   'Domains are the entities to which users belong to and either local domain authentication or AD authentication is performed. This section allows to List, Add, Edit and Delete a Domain.', N'',1, 0), 
(3, 1, 'OAClient Management', 'oacMgmt',  'OAClient allows to poll Genesys Platform APIs for different metrics. This section allows to List, Add, Edit and Delete a OAClient.', N'', 2, 0), 
(4, 1, 'Organization Management', 'org',  'Organization as the term refers to different Organaziations that are available in Genesys Cloud. We map here as applicable. This sections allows to List, Add, Edit and Delete an Organization.',null, 3, 0), 
(5, 1, 'User Management', 'usersMgmt', 'Authorized user will have the ability to manage users and their permissions. This section allows to Add, Edit and Delete user and their permissions.',  N'',4, 0), 
(6, 1, 'Email Template Management', 'emailTmplts', 'Email Templates which can be used for sending Email Notifications part of Monitoring',  N'',4, 0), 

(11, null, 'Dashboards', null,  'Dashboards Section for quick insights', N'',1, 0), 
(12, 11, 'All Org Summary', 'aos',  'All Organization Summary to provide Birds Eye View of all Organizations status',N'', 1, 0), 
(13, 11, 'Org Detail', 'orgdetail','More Detailed View of information for a given Organization',N'', 2, 0), 

(21, null, 'Monitoring', null, N'Monitoring Section', null, 2, 0),  
(22, 21, 'Rules', 'rules',  'Rules capture the aspect being monitored based on items like Conversation Stats / Billing Info / Status of Edge/Phone/Line etc',N'', 1, 0), 
(23, 21, 'Raised Alerts', 'alerts',  'List of Raised Alerts',N'', 2, 0),
(24, 21, 'Curr App Status', 'appstatus',  'Health of Current Monitoring App',N'', 2, 0);


-- before deleting from [adm].[NavItem], delete the child data which are not in NavItems
Delete from [sec].[AppNavItemFeatureMap]  where NavItemId not in (Select id from @navItem);

MERGE [sec].[NavItem] t
USING @navItem s
ON (t.Id = s.Id)
WHEN NOT MATCHED BY TARGET
	THEN INSERT VALUES (s.Id, s.ParentId, s.DisplayName, s.NavLink, s.[Description], s.Tooltip, s.[Order], s.[Group], 1)
WHEN MATCHED
	THEN UPDATE SET
		t.ParentId = s.ParentId,
		t.DisplayName = s.DisplayName,
		t.NavLink = s.NavLink,
		t.[Description] = s.[Description],
		t.Tooltip = s.Tooltip,
		t.[Order] = s.[Order],
		t.[Group] = s.[Group]
WHEN NOT MATCHED BY SOURCE
	THEN DELETE
OUTPUT $action, inserted.*, deleted.*;
--- ********once we get the proper description need to remove 
update [sec].[NavItem] set [Description] = DisplayName where isnull([Description],'') = ''

GO