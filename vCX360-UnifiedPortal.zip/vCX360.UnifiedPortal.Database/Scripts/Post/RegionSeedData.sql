﻿
--Seed data (fixed)
DECLARE @Region TABLE
(
	[Id] TINYINT NOT NULL,
	[Name] NVARCHAR(128) NOT NULL,
	[Text] NVARCHAR(128) NOT NULL,
	[Description] NVARCHAR(256) NULL,
	[Enabled] TINYINT NOT NULL DEFAULT 0
);

INSERT INTO @Region VALUES
(1,  N'us_east_1', N'US East 01', N'US East Region 01', 1),
(2,  N'us_west_2', N'US West 02', N'US West Region 02', 1),
(3,  N'us_east_2', N'US East 02', N'US East Region 02', 1),
(4,  N'eu_west_1', N'EU West 01', N'US West Region 01', 0),
(5,  N'eu_west_2', N'US East 01', N'EU West Region 02', 0),
(6,  N'eu_central_1', N'EU Central 01', N'EU Central Region 01', 0),
(7,  N'ap_northeast_1', N'AP North East 01', N'AP North East 01', 0),
(8,  N'ap_northeast_2', N'AP North East 02', N'AP North East 02', 0),
(9,  N'ap_south_1', N'AP South 01', N'AP South Region 01', 0),
(10,  N'ap_southeast_1', N'AP South East 01', N'AP South East Region 01', 0),
(11,  N'ca_central_1', N'CA Central 01', N'CA Central Region 01', 0); 


MERGE [adm].[Region] t
USING @Region AS s
ON (t.id = s.id)
WHEN NOT MATCHED BY TARGET
	THEN INSERT (Id, [Name], [Description], [Text], [Enabled])
	VALUES (s.id, s.[Name], s.[Description], s.[Text], s.[Enabled])
WHEN MATCHED
	THEN UPDATE SET
		t.name = s.name,
		t.Description = s.Description,
		t.Text = s.Text
WHEN NOT MATCHED BY SOURCE
	THEN DELETE
OUTPUT $action, inserted.*, deleted.*;

GO
