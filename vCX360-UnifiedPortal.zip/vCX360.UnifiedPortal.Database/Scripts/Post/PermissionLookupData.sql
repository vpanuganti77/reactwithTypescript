﻿--Lookup data (fixed)
DECLARE @Permission TABLE
(
	[Id] TINYINT NOT NULL,
	[Name] NVARCHAR(50) NOT NULL,
	[Description] NVARCHAR(250) NULL
);

INSERT INTO @Permission VALUES
(0,  N'Unspecified',	N''), --no unspecified here. Numbers (IDs) must match Domain flags enum.
(1,  N'View',			N'View-only permission.'),
(7,  N'Edit',		    N'Add and update permission.'),
(15,  N'Full',			N'Delete and execute permission.'); 
--DO NOT CHANGE the IDs/Meanings of the above items

MERGE [dbo].[Permission] t
USING @Permission AS s
ON (t.id = s.id)
WHEN NOT MATCHED BY TARGET
	THEN INSERT (Id, [Name], [Description])
	VALUES (s.id, s.[Name], s.[Description])
WHEN MATCHED
	THEN UPDATE SET
		t.name = s.name,
		t.Description = s.Description
WHEN NOT MATCHED BY SOURCE
	THEN DELETE
OUTPUT $action, inserted.*, deleted.*;

GO