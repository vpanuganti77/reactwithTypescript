﻿--(MI2018Oct) this is not lookup data; this populates the default admin user with full permissions

DECLARE @dev nvarchar(10) = N'Developer';
DECLARE @roleIds as table (UserId int, RoleId int);

--insert 'Developer' in User is not already present
IF NOT EXISTS (select 1 from [dbo].[User] --)
	WHERE UserName = @dev) -- we might want to skip inserting Developer if there are users already in the system (or maybe always??, in case all users are deleted)
	INSERT INTO [dbo].[User]
		(UserName, FullName, Email, CreatedBy, Domain, DomainUser)
	VALUES
		(N'developer',		N'Admin Developer', NULL, N'Post Deployment Script',N'Local',N'Developer'); 

--get the ID of 'Developer'
Declare @userid INT= (Select Top(1) Id from [dbo].[User] where UserName = @dev);
 -- Developer should have  sysadmin, administartor roles (previous script was only setting it as Admin; 
 -- This updated script will make the Developer a SysAdmin, to make sure he has access to all data and all features

insert into @roleIds
Select @userId, RoleId from [dbo].vw_RoleWithPermissions 
where RoleName = 'SysAdmin';


--if a user was inserted in the first step, must assign the max permissions role to it:
merge [dbo].[UserRole] t
using @roleIds s
on t.UserId = s.UserId and t.RoleId = s.RoleId
when not matched by target
	then insert (UserId, RoleId)
	values (s.UserId, s.RoleId);
--leave other assignments in place: don't update, don't delete any other associations set for developer
	

GO
