﻿CREATE TABLE [dbo].[Permission]
(
	
	[Id]			TINYINT       NOT NULL,
	[Name]			NVARCHAR(100) NOT NULL,
	[Description]	NVARCHAR(256) NULL,

	CONSTRAINT [PK_Permission] PRIMARY KEY CLUSTERED ([Id])
);
