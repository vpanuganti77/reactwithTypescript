﻿CREATE TABLE [dbo].[EntityAudit]
(	
	[Id]			INT			  NOT NULL DEFAULT NEXT VALUE FOR [dbo].[EntityAuditIdSeq],
	[EntityName]	NVARCHAR(100) NOT NULL,
	[Operation]		NVARCHAR(20)  NOT NULL,
	[User]			NVARCHAR(100) NOT NULL,
	[Timestamp]		DATETIME2(0)  NOT NULL CONSTRAINT [DF_EntityAudit_Timestamp] DEFAULT CURRENT_TIMESTAMP,
	[Before]		XML			  NULL,
	[After]			XML			  NULL,

	CONSTRAINT [PK_EntityAudit] PRIMARY KEY CLUSTERED ([id])
)
