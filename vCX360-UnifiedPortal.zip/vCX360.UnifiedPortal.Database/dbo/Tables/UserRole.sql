﻿CREATE TABLE [dbo].[UserRole]
(
	[UserId]		  INT NOT NULL,
	[RoleId]		  INT NOT NULL,
	[IsDeleted]       BIT DEFAULT 0,

	--audit info
	[CreatedBy]		  NVARCHAR (256)  NOT NULL DEFAULT ('unknown'),
    [CreatedDate]	  DATETIME2 (0)	  NOT NULL CONSTRAINT [df_UserRole_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]		  NVARCHAR (256)  NULL,
    [UpdatedDate]	  DATETIME2 (0)	  NULL,

	CONSTRAINT [PK_UserRole] PRIMARY KEY CLUSTERED ([UserId],[RoleId]),

	CONSTRAINT [FK_UserRole_User] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_UserRole_Role] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role] ([Id]) ON DELETE CASCADE,
)

GO

CREATE INDEX [IX_UserRole_UserId_RoleId] ON [dbo].[UserRole] ([UserId], [RoleId])
GO

CREATE INDEX [IX_UserRole_UserId] ON [dbo].[UserRole] ([UserId])

GO

CREATE INDEX [IX_UserRole_RoleId] ON [dbo].[UserRole] ([RoleId])
