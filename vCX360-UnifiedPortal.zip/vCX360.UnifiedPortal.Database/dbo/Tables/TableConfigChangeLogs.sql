﻿CREATE TABLE [dbo].[TableConfigChangeLogs]
(
	[Id]         BIGINT             NOT NULL IDENTITY (1, 1) ,
    [Table]      NVARCHAR (255)     NULL,
    [ColumnName] NVARCHAR (255)     NOT NULL,
    [NewValue]   NVARCHAR (1000)    NULL      DEFAULT (''),
    [OldValue]   NVARCHAR (1000)    NULL      CONSTRAINT [DF__TableConf__OldVa__6FC44677] DEFAULT ('') ,
    [UserName]   NVARCHAR (255)     NULL      DEFAULT 'vCX360Script',
    [Action]     NVARCHAR (128)     NOT NULL,
    [ActionDate] DATETIME2(0)       NOT NULL,
    [KeyValue]   NVARCHAR(128)      NOT NULL,
	[ParentId]   INT                NULL,
    [RowVersion] ROWVERSION         NOT NULL,
    [CompanyId]  INT                NULL,
    [BusinessUnitId] INT            NULL,
    CONSTRAINT [PK__TableCon__3214EC0706555B9D] PRIMARY KEY CLUSTERED ([Id] ASC)
);
