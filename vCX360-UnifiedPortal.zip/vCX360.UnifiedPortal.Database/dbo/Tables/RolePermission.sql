﻿CREATE TABLE [dbo].[RolePermission]
(
	 [RoleId]		INT		NOT NULL,
     [PermissionId]	TINYINT NOT NULL,

    CONSTRAINT [PK_RolePermissions] PRIMARY KEY CLUSTERED ([RoleId] ASC, [PermissionId] ASC),
	CONSTRAINT [FK_RolePermissions_Role] FOREIGN KEY ([RoleId]) References [dbo].[Role] ([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_RolePermissions_Permissions] FOREIGN KEY ([PermissionId]) References [dbo].[Permission] ([Id]) ON DELETE CASCADE
);


GO

CREATE INDEX [IX_RolePermission_RoleId] ON [dbo].[RolePermission] ([RoleId])

GO

CREATE INDEX [IX_RolePermission_PermissionId] ON [dbo].[RolePermission] ([PermissionId])

GO

CREATE INDEX [IX_RolePermission_RoleId_PermissionId] ON [dbo].[RolePermission] ([RoleId], [PermissionId])
GO