﻿--This is a derived (extension) table for the base table Role. Any ID in here is also an ID in the Role table (but not also vice-versa)
--this will be used to pull roles using the custom attributes;
--NEED data migration to create all BU + Feature roles for each individual permission + sysadmin
CREATE TABLE [dbo].[CustomRole]
(
	[RoleId]				INT NOT NULL,
	[PermissionRoleId]		as [dbo].[GetPermissionRoleForCustomRole] ([RoleId]), --computed column, based on the permissions associated to THIS (custom) role
	[ApplicationId]			INT,
	[CompanyId]				INT NULL,
	[BusinessUnitId]		INT NULL,
	[FeatureId]				INT NULL,
	[FeaturePartId]			INT NULL, --for future use: like a nav item for example
	[CompositeName]			as dbo.BuildCustomRoleName2 ([CompanyId], [BusinessUnitId], [FeatureId], [FeaturePartId], [RoleId], [ApplicationId]),
	[IsValid]				as sec.IsValidRole(/*[CompanyId], [BusinessUnitId], [FeatureId], [FeaturePartId], */[RoleId]),
	[IsEnterpriseAdmin]		as case when BusinessUnitId is null then 1 else 0 end,

	CONSTRAINT [PK_CustomRole] PRIMARY KEY CLUSTERED ([RoleId]),
	CONSTRAINT [FK_CustomRole_Role1] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role]([Id]) ON DELETE CASCADE,
	CONSTRAINT [FK_CustomRole_Application] FOREIGN KEY ([ApplicationId]) REFERENCES [adm].[Application]([Id]) ON DELETE CASCADE,
	--CONSTRAINT [FK_CustomRole_Role2] FOREIGN KEY ([PermissionRoleId]) REFERENCES [dbo].[Role]([Id]),
	CONSTRAINT [FK_CustomRole_Company] FOREIGN KEY ([CompanyId]) REFERENCES [adm].[Company]([Id]), --cannot cascade because this is derived table
	CONSTRAINT [FK_CustomRole_BusinessUnit] FOREIGN KEY ([BusinessUnitId]) REFERENCES [adm].[BusinessUnit]([Id]), --cannot cascade because this is derived table
	CONSTRAINT [FK_CustomRole_Feature] FOREIGN KEY ([FeatureId]) REFERENCES [sec].[Feature]([Id]), --cannot cascade because this is derived table
)

GO

CREATE INDEX [IX_CustomRole_CompanyId] ON [dbo].[CustomRole] ([CompanyId])

GO

CREATE INDEX [IX_CustomRole_BusinessUnitId] ON [dbo].[CustomRole] ([BusinessUnitId])

GO

CREATE INDEX [IX_CustomRole_FeatureId] ON [dbo].[CustomRole] ([FeatureId])
GO
