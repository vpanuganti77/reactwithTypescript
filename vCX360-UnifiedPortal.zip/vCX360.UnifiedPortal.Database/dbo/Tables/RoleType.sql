﻿--lookup data
CREATE TABLE [dbo].[RoleType]
(
	[Id]			TINYINT		NOT NULL,
	[Name]			varchar(50) NOT NULL,
	[Description]	varchar(200),

	CONSTRAINT [PK_RoleType] PRIMARY KEY CLUSTERED ([Id])
)
