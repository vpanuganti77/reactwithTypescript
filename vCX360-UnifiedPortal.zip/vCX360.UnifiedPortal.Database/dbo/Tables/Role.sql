﻿CREATE TABLE [dbo].[Role]
(
	[Id]			INT				NOT NULL DEFAULT NEXT VALUE FOR [dbo].[RoleIdSeq],
	[Name]			NVARCHAR(200)	NOT NULL,
	[Description]	NVARCHAR(256),
	[RoleType]		TINYINT			NOT NULL default(100), 
	[IsDeleted]     BIT DEFAULT 0,

	--audit info
	[CreatedBy]      NVARCHAR (256)  NOT NULL DEFAULT ('unknown'),
    [CreatedDate]    DATETIME2 (0)	 NOT NULL CONSTRAINT [df_Role_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]      NVARCHAR (256)  NULL,
    [UpdatedDate]    DATETIME2 (0)	 NULL,

	CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_Role_Name] UNIQUE ([Name]),
	CONSTRAINT [FK_Role_RoleType] FOREIGN KEY ([RoleType]) REFERENCES [dbo].[RoleType]([Id])
)

GO

CREATE INDEX [IX_Role_RoleType] ON [dbo].[Role] ([RoleType])

GO

CREATE INDEX [IX_Role_Name] ON [dbo].[Role] ([Name])
GO