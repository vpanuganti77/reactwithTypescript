﻿CREATE TABLE [dbo].[User]
(
	[Id]              INT            NOT NULL DEFAULT NEXT VALUE FOR [dbo].[UserIdSeq],
	[UserName]        NVARCHAR(100)  NOT NULL,
	[FullName]        NVARCHAR(256),
	[Email]           NVARCHAR(100),
	[LastLoginDate]   DATETIME2(0),	
    [CompanyId]       INT            NULL, 
    [Domain]          NVARCHAR (64)  NOT NULL DEFAULT '',    	
    [DomainUser]      NVARCHAR (120) NOT NULL DEFAULT '',--as   iif(Domain !='', UserName + '@' + Domain, UserName),  --[dbo].[GetDomainUserForUserAndDomain] (UserName,Domain),
	
    -- For Pwd Reset / Unlock acct / GC User
    [FailedAuthCount] TINYINT NOT NULL DEFAULT 0, 
    [IsForcePwdReset] BIT     NOT NULL DEFAULT 1, 
    [IsImportedUSer]  BIT     NOT NULL DEFAULT 0,
    [IsDeleted]       BIT              DEFAULT 0,
   --audit info
	[CreatedBy]       NVARCHAR (256)  NOT NULL DEFAULT ('unknown'),
    [CreatedDate]     DATETIME2 (0)	  NOT NULL CONSTRAINT [df_User_CreatedDate] DEFAULT CURRENT_TIMESTAMP,
    [UpdatedBy]       NVARCHAR (256)  NULL,
    [UpdatedDate]     DATETIME2 (0)	  NULL,
    CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED ([Id]),
	CONSTRAINT [UQ_User_UserName_Domain] UNIQUE ([UserName], [Domain]),
)
GO
CREATE INDEX [IX_User_UserName] ON [dbo].[User] ([UserName], [Domain])
GO
CREATE INDEX [IX_User_DomainUser] ON [dbo].[User] (DomainUser)
GO

