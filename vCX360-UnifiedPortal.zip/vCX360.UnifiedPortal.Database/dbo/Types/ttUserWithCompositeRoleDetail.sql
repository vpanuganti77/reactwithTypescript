﻿--type used for inserting/updating users and their roles
CREATE TYPE [dbo].[ttUserWithCompositeRoleDetail] AS TABLE
(
	UserId			INT, --can be null in case of insert, but will be validated for updates
	UserName		NVARCHAR(50) NOT NULL,
	FullName		NVARCHAR(256), 
	Email			NVARCHAR(100),
	Domain			NVARCHAR(64) NOT NULL,
	PermissionRoleId INT NOT NULL, --the BASIC role ID (SysAdmin, Basic, Editor, Administrator)
	RoleId			 int NOT NULL,
	RoleName		 VARCHAR(100) NOT NULL,
	CompanyId		 INT,
	BusinessUnitId	 INT,
	ApplicationId    INT,
	FeatureId		 INT,
	--RoleType varchar(50),
	ComputedRoleName varchar(100) null,
	PermissionId	 TINYINT NOT NULL,
	PermissionName	 NVARCHAR(256)  NOT NULL,
	CreatedBy		 NVARCHAR (256) NOT NULL, 
	CreatedDate		 DATETIME2 (0)  NOT NULL, 
	UpdatedBy		 NVARCHAR (256), 
	UpdatedDate		 DATETIME2 (0),

	-- Company CID / Name
	CompanyCID  NVARCHAR (64)  NULL, 
	CompanyName NVARCHAR (128) NULL,

	-- For Pwd Reset / Unlock acct
	FailedAuthCount  TINYINT, 
    ForcePwdReset    BIT
)

