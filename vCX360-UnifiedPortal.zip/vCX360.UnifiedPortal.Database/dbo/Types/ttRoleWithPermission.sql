﻿CREATE TYPE [dbo].[ttRoleWithPermission] AS TABLE
(
	RoleId			INT			   NOT NULL, 
	RoleName		NVARCHAR (100) NOT NULL,
	RoleDescription NVARCHAR (256),
	
	CreatedBy		NVARCHAR (256) NOT NULL, 
	CreatedDate		DATETIME2 (0)  NOT NULL, 
	UpdatedBy		NVARCHAR (256), 
	UpdatedDate		DATETIME2 (0),
	PermissionId	TINYINT		   NOT NULL, 
	PermissionsName NVARCHAR (100), 
	PermissionDescription NVARCHAR (256)
)
