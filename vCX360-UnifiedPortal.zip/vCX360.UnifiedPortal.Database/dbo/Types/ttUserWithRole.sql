﻿--type used for inserting/updating users and their roles
CREATE TYPE [dbo].[ttUserWithRole] AS TABLE
(
	UserId	 INT, --can be null in case of insert, but will be validated for updates
	UserName NVARCHAR(50) NOT NULL,
	FullName NVARCHAR(256), 
	Email    NVARCHAR(100),
	[CompanyId]  Int NULL, 
	Domain NVARCHAR(64) NOT NULL,
	RoleId INT NOT NULL
)
