﻿--For consistency: all st procs must return (on all return paths) a table of this type (one or more rows, depending on the context)
--e.g. For inserts, if success, we return rows with IDs inserted, where IsError is false for all and message is NULL for all
--e.g. For error, we return a table with a single row where IsError is true, and Message contains error detail. Id is null.
CREATE TYPE [dbo].[StProcResult] AS TABLE
(
	[IsError] BIT            NOT NULL,
    [Id]      INT            NULL,
    [Message] NVARCHAR (500) NULL
)
