﻿CREATE TYPE [dbo].[ttIntStringTuple] AS TABLE
(
	Id INT,
	[Name] VARCHAR(128)
)
