﻿CREATE TYPE [dbo].[ttIntIntTuple] AS TABLE
(
	Item1 INT, 
	Item2 INT
)
