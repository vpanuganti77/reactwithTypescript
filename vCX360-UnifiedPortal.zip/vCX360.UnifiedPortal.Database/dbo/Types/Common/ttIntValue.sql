﻿CREATE TYPE [dbo].[ttIntValue] AS TABLE
(
	Id INT
)
