﻿CREATE TYPE [dbo].[ttString] AS TABLE
(
	[StrVal] NVARCHAR(250)
)
