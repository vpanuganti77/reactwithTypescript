﻿CREATE TYPE [dbo].[ttUserWithRoleAndPermissionDetail] AS TABLE
(
	UserId		INT NOT NULL, 
	UserName	NVARCHAR(50) NOT NULL,
	FullName	NVARCHAR(256), 
	Email		NVARCHAR(100), 
	Domain		NVARCHAR(64)   NOT NULL,
	CreatedBy	NVARCHAR (256) NOT NULL, 
	CreatedDate DATETIME2 (0)  NOT NULL, 
	UpdatedBy	NVARCHAR (256), 
	UpdatedDate DATETIME2 (0),
	RoleId		INT NOT NULL, 
	RoleName	NVARCHAR(512) NOT NULL,
	PermissionId   TINYINT    NOT NULL,
	PermissionName NVARCHAR(256) NOT NULL
)
