﻿CREATE TYPE [dbo].[ttUserWithCompositeRole] AS TABLE
(
	UserId		INT, --can be null in case of insert, but will be validated for updates
	UserName	NVARCHAR(50) NOT NULL,
	FullName	NVARCHAR(256), 
	Email		NVARCHAR(100),
	Domain		NVARCHAR(64) NOT NULL,
	PermissionId   INT NOT NULL, --the BASIC role ID (SysAdmin, Basic, Editor, Administrator)
	CompanyId	   INT,
	BusinessUnitId INT,
	ApplicationId Int,
	FeatureId	   INT,
	FailedAuthCount TINYINT, 
    ForcePwdReset   BIT 
)
