﻿CREATE TYPE [dbo].[ttAuditSnapshot] AS TABLE
(
	[Table]			nvarchar(255),
	[KeyValue]		nvarchar(50),
	[Action]		nvarchar(50),
	[ActionDate]	datetime2(0),
	[UserName]		nvarchar(255),
	[ColumnName]	nvarchar(255),
	[NewValue]		nvarchar(1000),
	[OldValue]		nvarchar(1000)
	
)

