﻿CREATE TYPE [dbo].[ttCustomRoleWithPermission] AS TABLE
(
	RoleId	 INT NOT NULL, 
	RoleName NVARCHAR (200) NOT NULL,
	--RoleDescription NVARCHAR (256),
	--RoleType tinyint not null,

	--parts
	CompanyId int,
	BusinessUnitId int,
	FeatureId int,
	ComputedRoleName varchar(100), --computed

	--other
	--IsEnterpriseAdmin bit, --computed
	--IsSysAdmin bit, --computed
	
	----audit
	--CreatedBy NVARCHAR (256) NOT NULL, 
	--CreatedDate DATETIME2 (0) NOT NULL, 
	--UpdatedBy NVARCHAR (256), 
	--UpdatedDate DATETIME2 (0),
	
	--permission
	PermissionId TINYINT NOT NULL, 
	PermissionsName NVARCHAR (100), 
	PermissionDescription NVARCHAR (256)
)
