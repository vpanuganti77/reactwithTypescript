﻿CREATE PROCEDURE [dbo].[spDeleteBusnessUnitRoles]
	@buIds dbo.ttIntValue READONLY
AS

	declare @roleids  dbo.ttIntValue;
		
	insert into @roleids
	Select RoleId --from [adm].[BusinessUnitRole] 
	from [dbo].[CustomRole] 
	where BusinessUnitId in (select id from @buIds)

	--delete from [adm].[RolePermission] where roleId in (select id  from @roleids)

	--delete from [adm].[BusinessUnitRole] where  roleid in (select id from @roleids)

	delete from [dbo].[Role] where Id in (select id from @roleids)--will delete from CustomRole as well, due to cascading delete
	
	
	return;

RETURN 0
