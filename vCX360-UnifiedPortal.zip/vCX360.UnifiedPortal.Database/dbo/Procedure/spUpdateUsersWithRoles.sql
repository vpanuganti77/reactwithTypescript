﻿	--st proc that supports updating multiple users in one request;
-- a user can have one or more roles associated to it (even if currently there is only a 1-1 mapping of user-to-role)
CREATE PROCEDURE [dbo].[spUpdateUsersWithRoles]
	@users [dbo].[ttUserWithRole] READONLY, -- may have more rows than users, if any given user has more than one role
	@user nvarchar(256) = N'AdminPortal' --user making the insert request (audit)
AS
	Declare @result dbo.StProcResult;

	Set XACT_ABORT ON;

	--validate user IDs (must be existing users)
	IF (exists (select UserId from @users except (select Id from [dbo].[User]))) --there are input user IDs which cannot be found in the User table's IDs
	Throw 51000, N'ERROR-INSERT-USER-UserId is not a valid User ID', 1;

	--validate role IDs (must be valid)
	If (exists (select RoleId from @users except (select Id from [dbo].[Role]))) --there are input role IDs which cannot be found in the Role table's IDs
	Throw 51000, N'ERROR-INSERT-USER-RoleId is not a valid Role ID', 1;

	Declare @TranName nvarchar(20) = N'UpdateUserwithRoleTx';
	Begin Transaction @TranName;
	
	Declare @updatedUserIds [dbo].ttIntValue;

	--update all users first (even if only roles were updated, we still want to set the UpdatedBy and UpdatedDate here
	update [dbo].[User]
	set 
		UserName = x.UserName,
		FullName = x.FullName, 
		Email = x.Email, 
		Domain = x.Domain,
		UpdatedBy = @user,
		UpdatedDate = CURRENT_TIMESTAMP
	from @users x
	where Id = x.UserId;
	
	--update roles (possibly multiple roles per person)
	merge [dbo].UserRole t
	using @users s
	on (t.userId = s.userId and t.roleId = s.roleId)
	when not matched by target
		then insert (UserId, RoleId, CreatedBy)
		values (s.UserId, s.RoleId, @user)
	--when matched --do nothing
	when not matched by source AND t.userid in (select UserId from @users)
		then delete;	


	--return updated user IDs (same from input)
	Insert into @result
	Select distinct
		CAST (0 as bit),
		UserId,
		N'[dbo].[User]'
	From
		@users;

	--On Success
	Commit Transaction @TranName;

	Select * From @result;
	Return;


RETURN 0
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'spUpdateUsersWithRoles',
    @level2type = NULL,
    @level2name = NULL
