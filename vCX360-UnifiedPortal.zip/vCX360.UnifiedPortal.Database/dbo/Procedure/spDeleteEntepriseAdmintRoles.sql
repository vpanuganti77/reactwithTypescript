﻿CREATE PROCEDURE [dbo].[spDeleteEntepriseAdmintRoles]
	@coIds dbo.ttIntValue READONLY
AS

	delete [dbo].[Role]  --will delete from CustomRole as well, due to cascading delete
	where Id in 
	(
		select  Roleid from [dbo].[CustomRole] cr
		join @coIds on Id = cr.CompanyId
	)
	
	return;

RETURN 0
