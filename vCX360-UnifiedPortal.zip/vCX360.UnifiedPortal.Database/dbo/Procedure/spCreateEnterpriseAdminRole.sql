﻿CREATE PROCEDURE [dbo].[spCreateEnterpriseAdminRole]
@companyId int,	
@companyCid nvarchar(64),
@userName nvarchar(256) = N'AdminPortal'	
AS	

	Set XACT_ABORT ON;

	DECLARE @TranName VARCHAR(20) = 'InsertEAdminRoleTx'; 
 	BEGIN TRANSACTION @TranName; 


	DECLARE @Roles TABLE
	(
		[Id] int,
		[Name] NVARCHAR(200) NOT NULL,
		[Description] NVARCHAR(256) NULL,
		[PermissionId] TINYINT NOT NULL
	);

	INSERT INTO @Roles ([Name], [Description], [PermissionId])
	select 
		@companyCid + N' Enterprise Admin' , N' Enterprise Admin role for ' + @companyCid +' CO.', 15;
	
	update @Roles
		set Id = next value for [dbo].[RoleIdSeq]; --generate new role IDs

	--insert new roles:
	Insert into [dbo].[Role]([Id], [Name], [Description], RoleType, CreatedBy)
	select [Id], [Name], [Description], 2, @userName
	from @Roles;

	--insert RolePermission first
	insert into [dbo].[RolePermission] (RoleId, PermissionId)
	select Id, PermissionId
	from @Roles;	

	--insert CUstomRole after (as it has a computed column based on RolePermission)
	insert into [dbo].[CustomRole] (RoleId, CompanyId, BusinessUnitId)
	select Id, @companyId, null
	from @Roles;

	COMMIT TRANSACTION @TranName; 

RETURN 0