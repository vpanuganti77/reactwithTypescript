﻿CREATE PROCEDURE [dbo].[spDeleteBusnessUnitRolesFromCompanies]
	@companyIds dbo.ttIntValue READONLY	
AS
	
	declare @buids dbo.ttIntValue;
	insert into @buids
	select Id from  [adm].[BusinessUnit] where CompanyId in (select id from @companyIds);

	delete t1 --delete t1
	from [dbo].[Role] t1
	join [dbo].[CustomRole] cr on cr.RoleId = t1.Id
	where cr.CompanyId in (select Id from @companyIds); --deletes both BU roles and CO enterprise admin role for the input company ids

	--exec [dbo].[spDeleteBusnessUnitRoles]  @buids; --no need, the above will delete BU roles as well

return;

RETURN 0
