﻿CREATE PROCEDURE [dbo].[spDeleteUsers]
	@userIds dbo.ttIntValue READONLY,
	@user nvarchar(256) = N'AdminPortal' --not used with delete (yet, until we do soft delete)
AS
	declare @result dbo.StProcResult;
	set XACT_ABORT ON;
	
	--validate User Ids
	if exists (select id from @userIds except select id from [dbo].[User])
	throw 51000, 'ERROR-DELETE-USER-Invalid User Ids', 1;

	--Transaction starts here
	DECLARE @TranName NVARCHAR(20) = N'DeleteUsersTx'; 
 	BEGIN TRANSACTION @TranName; 

	delete from [dbo].[User] 
	output cast(0 as bit), deleted.Id, N'[adm].[User]' into @result
	where Id in (select Id from @userIds);

	--roles assigned to these users will be deleted via cascading delete action

	--success
	commit transaction @TranName
	select * from @result;
	return;

RETURN 0

go
exec sp_addextendedproperty @name =
	N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'spDeleteUsers',
    @level2type = NULL,
    @level2name = NULL
