﻿	--st proc that supports inserting multiple users on one request;
-- a user can have one or more roles associated to it (even if currently there is only a 1-1 mapping of user-to-role)
CREATE PROCEDURE [dbo].[spCreateUsersWithRoles]
	@users [dbo].[ttUserWithRole] READONLY,
	@user nvarchar(256) = N'AdminPortal' --user making the insert request (audit)
AS
	Declare @result dbo.StProcResult;

	Set XACT_ABORT ON;

	--validate role IDs (must be valid)
	If (exists (select RoleId from @users except (select Id from [dbo].[Role]))) --there are input role IDs which cannot be found in the Role table's IDs
	Throw 51000, N'ERROR-INSERT-USER-RoleId is not a valid Role ID', 1;

	--user names are validated at insert (UQ constraint)

	Declare @TranName nvarchar(20) = N'InsertUserwithRoleTx';
	Begin Transaction @TranName;
	
	Declare @insertedUserIds [dbo].ttIntValue;

	--insert all users first
	insert into [dbo].[User]
	(UserName, FullName, Email, CompanyId, Domain, CreatedBy, DomainUser)
	output inserted.Id into @insertedUserIds
	select distinct
		UserName, FullName, Email, CompanyId, Domain, @user, iif(Domain !='', UserName + '@' + Domain, UserName) 
	from @users;
		
	--insert roles (possibly multiple roles per person)
	insert into [dbo].[UserRole]
	(UserId, RoleId, CreatedBy)
	select u.Id, x.RoleId, @user
	from @insertedUserIds as iu
	join [dbo].[User] u on u.Id = iu.Id
	join @users x on x.UserName = u.UserName;

	Insert into @result
	Select
		CAST (0 as bit),
		Id,
		N'[dbo].[User]'
	From
		@insertedUserIds;

	--On Success
	Commit Transaction @TranName;

	Select * From @result;
	Return;


RETURN 0
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'spCreateUsersWithRoles',
    @level2type = NULL,
    @level2name = NULL
