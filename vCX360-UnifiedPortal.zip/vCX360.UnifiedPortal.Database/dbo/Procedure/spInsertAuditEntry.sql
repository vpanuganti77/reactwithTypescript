﻿CREATE PROCEDURE [dbo].[spInsertAuditEntry]
	@entityName nvarchar(100),
	@before xml,
	@after xml,
	@user nvarchar(100) = 'unknown',
	@op nvarchar(20)
AS
	Declare @result dbo.StProcResult;

	insert into [dbo].EntityAudit
	(EntityName, Operation, [User], [Timestamp], [Before], [After])
	OUTPUT CAST (0 as bit), inserted.Id, N'[dbo].[EntityAudit]' into @result 
	values
	(@entityName, @op, @user, CURRENT_TIMESTAMP, @before, @after);
	select * from @result;
	return;

RETURN 0
GO


Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'spInsertAuditEntry',
    @level2type = NULL,
    @level2name = NULL