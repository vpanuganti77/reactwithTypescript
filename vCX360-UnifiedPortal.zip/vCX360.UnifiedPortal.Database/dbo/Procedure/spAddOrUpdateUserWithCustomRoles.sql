﻿CREATE PROCEDURE [dbo].[spAddOrUpdateUserWithCustomRoles]
	@userWithRoles [dbo].[ttUserWithCompositeRole] READONLY,
	@user nvarchar(256) = N'AdminPortal'
AS
	Declare @result dbo.StProcResult;

	Set XACT_ABORT ON;

	--validations
	--V1: user (if this is an update)
	declare @userId int = (select top(1) UserId from @userWithRoles);
	IF (@userId is not null and @userId > 0 and not exists (select Id from [dbo].[User] where Id = @userId)) 
	Throw 51000, N'ERROR-AddOrUpdate-USER-UserId is not a valid User ID', 1;
	
	--V2: Roles (details)
	if exists (select PermissionId from @userWithRoles except Select Id from [dbo].[Permission])
	Throw 51000, N'ERROR-AddOrUpdate-USER-Invalid Basic/Permission ID', 1;

	if exists (select BusinessUnitId from @userWithRoles where BusinessUnitId is not null except select id from [adm].[BusinessUnit])
	Throw 51000, N'ERROR-AddOrUpdate-USER-Invalid Business Unit Id ID', 1;

	if exists (select CompanyId from @userWithRoles where CompanyId is not null except select id from [adm].[Company])
	Throw 51000, N'ERROR-AddOrUpdate-USER-Invalid Company Id ID', 1;

	if exists (select FeatureId from @userWithRoles where FeatureId is not null except select id from [sec].[Feature])
	Throw 51000, N'ERROR-AddOrUpdate-USER-Invalid Feature Id ID', 1;

	if exists (select UserId from @userWithRoles where FeatureId is not null and (CompanyId IS NULL OR BusinessUnitId IS NULL))
	Throw 51000, N'ERROR-AddOrUpdate-USER-CompanyId and BusinessUnitId are required to create User With Permissions', 1;

	--if exists (select UserId from @userWithRoles where FeatureId is null and (CompanyId IS NOT NULL OR BusinessUnitId IS NOT NULL))
	--Throw 51000, N'ERROR-AddOrUpdate-USER-CompanyId / BusinessUnitId are not applicable for SuperAdmin', 1;

	declare @companyid int = (Select top(1) companyid from @userWithRoles)

	--DECLARE @IsProductCloudDashboard AS INT = (SELECT [adm].[IsProductCloudDashboard]());
	--IF @IsProductCloudDashboard = 0 and
	--(@userId is not null and @userId > 0 and @companyid is not null and @companyid > 0 and
	--@companyid != (select CompanyId from [dbo].[User] where Id = @userId)) 
	--Throw 51000, N'ERROR-AddOrUpdate-USER-CompanyID can not modifiy.', 1;

	Declare @insertedUserIds [dbo].ttIntValue;

	Declare @TranName nvarchar(50) = N'InsertUserwithRoleTx';
	Begin Transaction @TranName;

	--1. insert/update user
	if @userId is null or @userId <= 0
	begin
		insert into [dbo].[User]
		(UserName, FullName, Email, CompanyId, Domain, CreatedBy,DomainUser, IsForcePwdReset)
		output inserted.Id into @insertedUserIds
		select top(1) -- there could be more than one (CloudDashboard)
			UserName, FullName, Email, CompanyId, Domain, @user, iif(Domain !='', UserName + '@' + Domain, UserName), ForcePwdReset
		from @userWithRoles;
		set @userId = (select top(1) Id from @insertedUserIds);
	end
	else
	begin
		update [dbo].[User]
		set
			UserName = x.UserName,
			FullName = x.FullName, 
			Email = x.Email, 
			Domain = x.Domain,
			FailedAuthCount = x.FailedAuthCount,
			IsForcePwdReset = x.ForcePwdReset,
			UpdatedBy = @user,
			UpdatedDate = CURRENT_TIMESTAMP
		from @userWithRoles x
		where Id = @userId;

		insert into @insertedUserIds
		select @userId;
	end;

	--2. Identify and/or create the roles to be assiged to this user
	declare @roles table (
		roleId int, permissionRoleId int, 
		companyId int, businessUnitId int, 
		applicationId int,
		featureId int, roleName nvarchar(512), 
		permissionId tinyint, isNewRole bit);

	insert into @roles
	select distinct 
		cr.RoleId, Coalesce(cr.PermissionRoleId, r0.Id),
		u.CompanyId, u.BusinessUnitId, u.ApplicationId,  u.FeatureId, 
		cr.ComputedRoleName, 
		u.PermissionId, IIF(cr.RoleId is null or cr.RoleId < 0, 1, 0)
	from @userWithRoles u
	left join [dbo].vw_CustomRoleWithPermission cr 
		on (ISNULL(u.CompanyId, cr.CompanyId) is null or cr.CompanyId = u.CompanyId) and 
			(ISNULL(u.BusinessUnitId, cr.BusinessUnitId) is null or cr.BusinessUnitId = u.BusinessUnitId) and 
			(ISNULL(u.ApplicationId, cr.ApplicationId) is null or cr.ApplicationId = u.ApplicationId) and 
			(ISNULL(u.FeatureId, cr.FeatureId) is null or cr.FeatureId = u.FeatureId) and 
			cr.PermissionId = u.PermissionId
	left join [dbo].[Role] r on (cr.RoleId is null or r.Id = cr.RoleId) 
	join [dbo].[RolePermission] rp on rp.PermissionId = u.PermissionId
	join [dbo].[Role] r0 on r0.Id = rp.RoleId and r0.RoleType = 0
	where  r.RoleType is null or r.RoleType > 0;

	-- DECLARE @debug001 nvarchar(max) = (SELECT * FROM @roles FOR XML AUTO); print 'insertedRoles: ' + @debug001;
	--declare @newRoles table (roleId int);--, permissionRoleId int, companyId int, businessUnitId int, featureId int, roleName nvarchar(100));

	--insert new roles in [Role] table where RoleId is null in the table above;
	--a. prepare IDs - and update them into @roles
	update @roles
		set RoleId = next value for [dbo].[RoleIdSeq]
	where isNewRole = 1;

	-- DECLARE @debug002 nvarchar(max) = (SELECT * FROM @roles FOR XML AUTO); print 'updatedRoles: ' + @debug002;

	declare @rolesDataToRoleTable table (
		Id int, 
		Name varchar(512), 
		RoleType int, 
		CreatedBy varchar(128));


	--b. insert new roles
	insert into @rolesDataToRoleTable
	select
		RoleId,
		[dbo].[BuildCustomRoleName] (companyId, businessUnitId, featureId, null, permissionRoleId, applicationId), 
		case 
			when FeatureId is not null then 4
			when FeatureId is null and businessUnitId is not null then 3
			when FeatureId is null and businessUnitId is null and CompanyId is not null then 2
			else 1 --should never happen
		end,
		@user
	from @roles r
	where isNewRole = 1; 

	-- DECLARE @debug003 nvarchar(max) = (SELECT * FROM @rolesDataToRoleTable FOR XML AUTO); print 'rolesDataToRoleTable: ' + @debug003;


	insert into [dbo].[Role] ([Id], [Name], [RoleType], [CreatedBy])
	SELECT * FROM @rolesDataToRoleTable;

	--d. add permissions-role associations for the new roles (MAY NOT BE NEEDED - to validate)
	insert into [dbo].[RolePermission] (RoleId, PermissionId)
	select roleId, permissionId
	from @roles
	where isNewRole = 1;

	--c. insert CustomRoles for the ones above
	insert into [dbo].[CustomRole] ([RoleId], [CompanyId], [BusinessUnitId], [FeatureId], ApplicationId)
	select roleId, companyId, businessUnitId, featureId, applicationId
	from @roles
	where isNewRole = 1;

	--3. MERGE User-Role associations (add or delete only)
	merge [dbo].UserRole t
	using @roles s
	on (t.userId = @userId and t.roleId = s.roleId)
	when not matched by target
		then insert (UserId, RoleId, CreatedBy)
		values (@userId, s.RoleId, @user)
	--when matched --do nothing
	when not matched by source AND t.userid = @userId
		then delete;	
	
	Insert into @result
	Select
		CAST (0 as bit),
		Id,
		N'[adm].[User]'
	From
		@insertedUserIds;

    -- Done explicitly for CloudDashboard Project as deletion of BusinessUnit (when Organization is deleted) is failing due to presence of Role though UNUSED.
	-- Perform the cleanup. The necessary Role is created again when user associates with relevant Feature in future (say Dasboard Full Permission)
	DELETE FROM [dbo].Role WHERE Id IN 
	(	
		SELECT RoleId FROM [dbo].[CustomRole] WHERE FeatureId IS NOT NULL AND RoleId NOT IN 
		(SELECT RoleId from [dbo].[UserRole])
	)

	--On Success
	Commit Transaction @TranName;

	Select * From @result;
	Return;
RETURN 0
GO

Exec sp_addextendedproperty
	@name = N'DM_RecordType',
    @value = N'[dbo].[StProcResult]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'PROCEDURE',
    @level1name = N'spAddOrUpdateUserWithCustomRoles',
    @level2type = NULL,
    @level2name = NULL