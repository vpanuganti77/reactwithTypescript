﻿CREATE PROCEDURE [dbo].[spCreateBusinessUnitRoles]
@busnessunitId int,	
@name nvarchar(100),
@userName nvarchar(256) = N'AdminPortal'	
AS	

	Set XACT_ABORT ON;

	DECLARE @TranName VARCHAR(20) = 'InsertBusinessUnitRolesTx'; 
 	BEGIN TRANSACTION @TranName; 


	DECLARE @Roles TABLE
	(
		[Id] int,
		[Name] NVARCHAR(200) NOT NULL,
		[Description] NVARCHAR(256) NULL,
		[PermissionId] TINYINT NOT NULL
	);

	INSERT INTO @Roles ([Name], [Description], [PermissionId])
	select 
		@name + ' ' + r.[Name] + N' BU' , r.[Name] + N' BU role for ' + @name +' BU.', rp.PermissionId
	from [dbo].[Role] r 
	join [dbo].[RolePermission] rp on rp.RoleId = r.Id
	where r.RoleType = 0 --Basic, Editor, Admin (all 3 primitive roles)

	update @Roles
		set Id = next value for [dbo].[RoleIdSeq]; --generate new role IDs

	--insert new roles:
	Insert into [dbo].[Role]([Id], [Name], [Description], [RoleType], CreatedBy)
	select [Id], [Name], [Description], 3,  @userName
	from @Roles;
	
	--company ID:
	declare @coId int = (select top(1) CompanyId from [adm].BusinessUnit where Id = @busnessunitId);

	--insert RolePermission first
	insert into [dbo].[RolePermission] (RoleId, PermissionId)
	select Id, PermissionId
	from @Roles;	

	--insert CUstomRole after (as it has a computed column based on RolePermission)
	insert into [dbo].[CustomRole] (RoleId, CompanyId, BusinessUnitId)
	select Id, @coId, @busnessunitId
	from @Roles;

	COMMIT TRANSACTION @TranName; 

RETURN 0