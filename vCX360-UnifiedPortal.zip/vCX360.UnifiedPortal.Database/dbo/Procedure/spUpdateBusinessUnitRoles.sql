﻿CREATE PROCEDURE [dbo].[spUpdateBusinessUnitRoles]
@busnessunitId int,	
@name nvarchar(64),
@oldname nvarchar(64),
@userName nvarchar(256) = N'AdminPortal'	
AS	

	-- with tbids as (Select RoleId from [adm].[BusinessUnitRole] where BusinessUnitId=@busnessunitId)
	-- 
	-- update [dbo].[Role] Set name = @name + N' Business User',description = N'permission for ' + @name ,
	-- updatedby= @userName
	-- where id in (select RoleId from tbids)

RETURN 0