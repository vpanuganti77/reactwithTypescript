﻿CREATE VIEW [dbo].[vw_UserWithRoles]
	AS 
	SELECT 
		u.Id as UserId, UserName, FullName, Email, Companyid, Domain,
		u.CreatedBy, u.CreatedDate, u.UpdatedBy, u.UpdatedDate,
		r.Id as RoleId, r.Name as RoleName
	FROM [dbo].[User] u
	JOIN [dbo].UserRole ur on u.Id = ur.UserId
	JOIN [dbo].Role r on r.Id = ur.RoleId
