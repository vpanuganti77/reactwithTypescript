﻿CREATE VIEW [dbo].[vw_CustomRoleWithPermission]
WITH SCHEMABINDING  
	AS 
	with computedRoles as
	( --fabricate all possible roles, and give negative IDs to those that are not actual roles (in Role or CustomRole tables)
		select 
			-ROW_NUMBER() over (order by CoId, BuId, FeatureId, cr.RoleId) as RoleId, CustomRoleName as RoleName, 
			CoId as CompanyId, BuId as BusinessUnitId, AppId as ApplicationId, FeatureId, CustomRoleName as ComputedRoleName,
			cr.RoleId as PermissionRoleId, 
			PermissionId, p.[Name] as PermissionsName, p.[Description] as PermissionDescription
		from [dbo].vw_CompositeRole cr
		join [dbo].RolePermission rp on rp.RoleId = cr.RoleId
		join [dbo].Permission p on p.Id = rp.PermissionId
		where cr.CoId is not null
	),
	rolesCte as
	(
		select r.Id, r.[Name] as RoleName, cr.CompositeName, cr.CompanyId, cr.BusinessUnitId, cr.ApplicationId,
		cr.FeatureId, cr.PermissionRoleId
		from [dbo].[Role] r
		join [dbo].[CustomRole] cr on cr.RoleId = r.Id
		where cr.IsValid = 1

		union all

		select r.Id, r.[Name] as RoleName, null as CompositeName, null as CompanyId, null as BusinessUnitId, null as ApplicationId, null as FeatureId, r.Id as PermissionRoleId
		from [dbo].[Role] r
		where r.RoleType < 2 or r.RoleType = 100  --primitives
	),
	roleWithPermCte as
	(
		select r.Id as RoleId, coalesce(CompositeName,RoleName) as RoleName, CompanyId, BusinessUnitId,
		 ApplicationId, FeatureId, 
			CompositeName as ComputedRoleName, PermissionRoleId,
			p.Id as PermissionId, p.[Name] as PermissionsName, p.[Description] as PermissionDescription
		from rolesCte r
		join [dbo].RolePermission rp on rp.RoleId = r.Id
		join [dbo].Permission p on p.Id = rp.PermissionId 
	),
	allRolesCte as
	(
			select 
			RoleId, RoleName, CompanyId, BusinessUnitId, ApplicationId, FeatureId,	ComputedRoleName, 
			PermissionRoleId, PermissionId, PermissionsName, PermissionDescription
		from roleWithPermCte
		
		union
		
		select 
			RoleId, RoleName, CompanyId, BusinessUnitId, ApplicationId, FeatureId,	ComputedRoleName, 
			PermissionRoleId, PermissionId, PermissionsName, PermissionDescription
		from computedRoles
		--where RoleName not in (select RoleName from roleWithPermCte)		
	)
	select 
		max(RoleId) as RoleId, RoleName, CompanyId, BusinessUnitId, ApplicationId, FeatureId,	ComputedRoleName, 
		PermissionRoleId, PermissionId, PermissionsName, PermissionDescription
	from allRolesCte
	group by RoleName, CompanyId, BusinessUnitId, ApplicationId, FeatureId,	ComputedRoleName, 
		PermissionRoleId, PermissionId, PermissionsName, PermissionDescription;

