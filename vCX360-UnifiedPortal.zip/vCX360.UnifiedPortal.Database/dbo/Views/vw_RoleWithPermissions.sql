﻿CREATE VIEW [dbo].[vw_RoleWithPermissions]
	AS  
	SELECT 
		r.Id as RoleId, r.Name as RoleName, r.Description as RoleDescription,
		r.CreatedBy, r.CreatedDate, r.UpdatedBy, r.UpdatedDate,
		p.Id as PermissionId, p.Name as PermissionsName, p.Description as PermissionDescription
	FROM
		[dbo].Role r
	JOIN
		[dbo].[RolePermission] rp on rp.RoleId = r.Id
	JOIN
		[dbo].Permission p on p.Id = rp.PermissionId;