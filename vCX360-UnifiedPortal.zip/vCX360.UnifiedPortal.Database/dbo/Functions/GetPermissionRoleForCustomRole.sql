﻿CREATE FUNCTION [dbo].[GetPermissionRoleForCustomRole]
(
	@roleId int
)
RETURNS INT
AS
BEGIN
	RETURN 
		(select top(1) r2.id
		from rolepermission rp
		join RolePermission rp2 on rp2.PermissionId = rp.PermissionId
		join [role] r2 on r2.id = rp2.RoleId
		where rp.RoleId = @roleid and r2.RoleType = 0)
END
