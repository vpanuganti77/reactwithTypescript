﻿CREATE FUNCTION [dbo].[GetRolesForAuth]
(
	--always retriev all possible/licensed roles (from VIEW), no filtering; should be cached
)
RETURNS TABLE AS RETURN
(
	select RoleId, RoleName, null as RoleDescription, '' as CreatedBy, getdate() as CreatedDate, null as UpdatedBy, null as UpdatedDate,
		   PermissionId, PermissionsName, PermissionDescription
	from [dbo].[vw_CustomRoleWithPermission]
);

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[ttRoleWithPermission]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'FUNCTION',
    @level1name = N'GetRolesForAuth',
    @level2type = NULL,
    @level2name = NULL
