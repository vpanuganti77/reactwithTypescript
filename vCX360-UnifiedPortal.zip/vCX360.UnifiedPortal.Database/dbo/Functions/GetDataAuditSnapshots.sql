﻿CREATE FUNCTION [dbo].[GetDataAuditSnapshots]
(
	@offset int = 0,
	@count int = 100
)
RETURNS TABLE AS RETURN
(
	with c1 as
       (
              select  [Table], KeyValue, [Action], ActionDate, 
              UserName, ColumnName, OldValue, NewValue
              from [dbo].TableConfigChangeLogs
              
       )
	   ,c2 as 
       (select
              [Table] as [Table], KeyValue,LTRIM(RTRIM([Action])) as [Action], 
             
              ActionDate, UserName
       from c1
       group by [Table], KeyValue, [Action], UserName, ActionDate
       order by ActionDate desc, [Action] desc --Order by is requried as we need to return same result everytime to offset and fetch rows
       offset @offset rows fetch next @count rows only 
       )
	   select c.[Table],c.[KeyValue],c.[Action],c.[ActionDate],c.[UserName],c.[ColumnName],c.[NewValue],c.[OldValue] from [dbo].TableConfigChangeLogs c
	   join c2 on c.[Table] = c2.[Table] and c.[Action] = c2.[Action] and c.ActionDate = c2.ActionDate and c.UserName = c2.UserName
	   
	   and c.KeyValue=c2.KeyValue

	  -- order by c.ActionDate desc, c.[Action] desc

);

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[ttAuditSnapshot]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'FUNCTION',
    @level1name = N'GetDataAuditSnapshots',
    @level2type = NULL,
    @level2name = NULL