﻿CREATE FUNCTION [dbo].[GetRolesWithPermissions]
(
	--always retriev all, no filtering; should be cached
)
RETURNS TABLE AS RETURN
(
	select 
        r.Id as RoleId, r.[Name] as RoleName,  
        cr.CompanyId, cr.BusinessUnitId, cr.FeatureId, 
        cr.ComputedRoleName,
        cr.PermissionId, cr.PermissionsName,
        cr.PermissionDescription
    from [dbo].[Role] r
        left join [dbo].vw_CustomRoleWithPermission cr on cr.RoleId = r.id
    where PermissionId is not null --this excludes invalid roles (due to license updates for existing feature roles from when licensed)
);

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[ttCustomRoleWithPermission]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'FUNCTION',
    @level1name = N'GetRolesWithPermissions',
    @level2type = NULL,
    @level2name = NULL
