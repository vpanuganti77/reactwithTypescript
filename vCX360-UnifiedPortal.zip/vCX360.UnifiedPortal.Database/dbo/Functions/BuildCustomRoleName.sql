﻿CREATE FUNCTION [dbo].[BuildCustomRoleName]
(
	@coId int,
	@buId int,
	@featureId int,
	@featurePartId int,
	@basicRoleId int,
	@applicationId int
)
RETURNS varchar(100)
WITH SCHEMABINDING
AS
BEGIN
	RETURN 
		(select 
			coalesce((select top(1) 'App:' + app.[CID]), '') + '~'+ --as application,
			coalesce((select top(1) 'CO:' + c.[CID]), '') + '~' + --as Company,
			coalesce((select top(1) 'BU:' + b.[CID]), '') + '~'+ --as BusinessUnit,
			--coalesce((select top(1) 'Suite:' + s.[CID]), '') + '~'+ --as Suite,			
			coalesce((select top(1) f.[CID]), '') + '~' + --as Feature,
			coalesce((select top(1) r.[Name]), '') --as [Role]
		from  adm.[Application] app 
		Left join adm.CompanyBusinessUnitAppMap cba on cba.ApplicationId = app.Id and cba.CompanyId = @coId 
					and cba.BusinessUnitId = @buId
		Left join adm.Company c on c.Id = cba.CompanyId and c.Id = @coId
		left join adm.BusinessUnit b on b.CompanyId = c.Id and b.Id = @buId
		left join sec.Feature f on f.Id = @featureId
		left join dbo.[Role] r on r.id = @basicRoleId
		where 
			c.Id = @coId and  app.Id = @applicationId	 --and s.Id = @suitId
		);
END
