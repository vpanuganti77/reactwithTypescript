﻿CREATE FUNCTION [dbo].[GetUsersWithRolesForAuth]
(
)
RETURNS TABLE AS RETURN
(
	with userRoles as
	(
		select 
			u.id, u.UserName, u.FullName, u.Email, u.Domain, 
			u.CreatedBy, u.CreatedDate, u.UpdatedBy, u.UpdatedDate, 
			r.id as RoleId, coalesce(cr.CompositeName, r.[name]) as RoleName, 
			cr.PermissionRoleId,
			cr.CompanyId, cr.BusinessUnitId, cr.FeatureId,
			rp.PermissionId, p.[Name] as PermissionName
		from [dbo].[role] r
		join [dbo].[RolePermission] rp on r.Id = rp.RoleId
		join [dbo].[Permission] p on p.Id = rp.PermissionId
		join [dbo].[UserRole] ur on ur.RoleId = r.Id
		join [dbo].[user] u on u.Id = ur.UserId
		left join customrole cr on cr.RoleId = r.Id
	) --select * from userRoles order by username
	, userAllRoles as
	(
		select 
			ur.Id as UserId, ur.UserName,  ur.FullName, ur.Email, ur.Domain, 
			ur.CreatedBy, ur.CreatedDate, ur.UpdatedBy, ur.UpdatedDate, 
			-1 as RoleId, ur.PermissionId, ur.PermissionName,
			cr.CustomRoleName as RoleName--,
			--cr.CoId as CompanyId, cr.BuId as BusinessUnitId, cr.FeatureId
		from userRoles ur
		join dbo.[vw_CompositeRole] cr on
			ur.PermissionRoleId = cr.RoleId and
			(ur.CompanyId = cr.CoId or ur.CompanyId is null) and
			(ur.BusinessUnitId is null or ur.BusinessUnitId = cr.BuId) and
		    (ur.FeatureId is null or ur.FeatureId = cr.FeatureId) 

		union all

		select 
			ur.Id as UserId, ur.UserName,  ur.FullName, ur.Email, ur.Domain, 
			ur.CreatedBy, ur.CreatedDate, ur.UpdatedBy, ur.UpdatedDate, 
			ur.RoleId, ur.PermissionId, ur.PermissionName,
			ur.RoleName--, 
			--ur.CompanyId, ur.BusinessUnitId, ur.FeatureId
		from userRoles ur
	)
	select 
		UserId, UserName, FullName, Email, Domain, 
		CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, 
		max(roleid) as RoleId, RoleName, PermissionId, PermissionName
	from userAllRoles
	group by 
		UserId, UserName, FullName, Email, Domain, 
		CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, 
		RoleName, PermissionId, PermissionName
/*
	with assignedRolesCte as
	(
		select 
			ur.UserId, u.UserName, u.FullName, u.Email, u.Domain,
			u.CreatedBy, u.CreatedDate, u.UpdatedBy, u.UpdatedDate,
			rp.RoleId, cr.[CompositeName] as OrigRoleName, 
			coalesce(r1.[Name], r.[Name]) as RoleName, 
			cr.CompanyId, cr.BusinessUnitId, FeatureId, 
			p.Id as PermissionId, p.Name as PermissionName
		from [User] u
		join userrole ur on ur.userid = u.id
		join [Role] r on r.Id = ur.RoleId
		join RolePermission rp on rp.RoleId = r.Id
		join Permission p on p.Id = rp.PermissionId
		left join CustomRole cr on cr.RoleId = r.Id
		left join [Role] r1 on r1.Id = cr.PermissionRoleId
	) --select * from assigedRolesCte
	, wFeatCte as
	(
		select 
			a.UserId, a.UserName, a.FullName, a.Email, a.Domain,
			a.CreatedBy, a.CreatedDate, a.UpdatedBy, a.UpdatedDate, a.RoleId, 
			IIF(a.CompanyId is null, 
				a.RoleName, 
				'CO:' + co.CID + '~BU:' + bu.CID + '~' + IIF(f.Id = 0, '', f.CID) + '~' + a.RoleName)  
				as RoleName, 
			a.PermissionId, a.PermissionName
		from [adm].LicensedFeature lf
		join [adm].Feature f on f.Id = lf.FeatureId or f.IsLicensable = 0
		join adm.Company co on co.Id = lf.CompanyId
		join adm.BusinessUnit bu on bu.Id = lf.BusinessUnitId
		join assignedRolesCte a on 
			(a.CompanyId is null) or
			(a.CompanyId = lf.CompanyId and a.BusinessUnitId is null) or 
			(a.BusinessUnitId = lf.BusinessUnitId and a.FeatureId is null) or 
			(a.BusinessUnitId = lf.BusinessUnitId and a.FeatureId = f.Id)

		union all

		select 
			a.UserId, a.UserName, a.FullName, a.Email, a.Domain,
			a.CreatedBy, a.CreatedDate, a.UpdatedBy, a.UpdatedDate, a.RoleId, 
			a.OrigRoleName, 
			a.PermissionId, a.PermissionName
		from assignedRolesCte a
		where RoleName <> 'SysAdmin'
	)
	select * from wFeatCte
	group by 
		UserId, UserName, FullName, Email, Domain,
		CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, 
		RoleId, RoleName, PermissionId, PermissionName
*/
)
GO
EXEC sp_addextendedproperty 
    @name = N'DM_RecordType',
    @value = N'[dbo].[ttUserWithRoleAndPermissionDetail]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'FUNCTION',
    @level1name = N'GetUsersWithRolesForAuth';

