﻿CREATE FUNCTION [dbo].[IsEntityIdValid]
(
	@id int,
	@type nvarchar(25) -- so far, one of {Company, BusinessUnit, Application, Module, Holiday, ScheduleTemplate}; other to be added and implemented as needed
)
RETURNS BIT
AS
BEGIN
	RETURN
		CASE @type
			WHEN N'Company' THEN [adm].IsCompanyIdValid(@id)
			WHEN N'BusinessUnit' THEN [adm].IsBusinessUnitIdValid(@id)
			-- WHEN N'Application' THEN [adm].IsApplicationIdValid(@id)
			-- WHEN N'ScheduleTemplate' THEN [adm].IsScheduleTemplateIdValid(@id)
			-- WHEN N'Holiday' THEN [adm].IsHolidayIdValid(@id)
			ELSE CAST (0 as BIT)
		END
END