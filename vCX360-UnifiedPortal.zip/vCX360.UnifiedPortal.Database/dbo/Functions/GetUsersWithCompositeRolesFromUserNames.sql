﻿--this will be called from the User Management screen;
--so filtering for multitenancy applies
CREATE FUNCTION [dbo].[GetUsersWithCompositeRolesFromUserNames]
(
    @uNames [dbo].[ttString] READONLY
)
RETURNS TABLE
AS
RETURN
WITH allUsersCte AS
(
    SELECT 
        u.Id AS UserId, u.UserName, u.FullName, u.Email, u.Domain,
        r.PermissionRoleId, 
        r.RoleId, r.RoleName,  
        b.CompanyId, r.BusinessUnitId, r.FeatureId, r.ApplicationId,
        r.ComputedRoleName,
        r.PermissionId, r.PermissionsName AS PermissionName, 
        u.CreatedBy, u.CreatedDate, u.UpdatedBy, u.UpdatedDate,
        c.cid AS CompanyCID, c.name AS CompanyName,
        u.FailedAuthCount, u.IsForcePwdReset
    FROM [dbo].vw_CustomRoleWithPermission r
        JOIN [dbo].UserRole ur ON ur.RoleId = r.RoleId
        JOIN [dbo].[User] u ON u.Id = ur.UserId
        LEFT JOIN [adm].[BusinessUnit] b ON r.BusinessUnitId = b.Id
        LEFT JOIN [adm].[Company] c ON b.CompanyId = c.Id
    WHERE 
         (NOT EXISTS (SELECT 1 FROM @uNames) OR UserName IN (SELECT StrVal FROM @uNames))
)
SELECT DISTINCT
    c1.UserId, UserName, FullName, Email, Domain,
    PermissionRoleId, RoleId, RoleName,
    c1.CompanyId, c1.BusinessUnitId, c1.ApplicationId, FeatureId,
    ComputedRoleName, PermissionId, PermissionName,
    CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, CompanyCID, CompanyName, FailedAuthCount, IsForcePwdReset
FROM allUsersCte c1;

GO
EXEC sp_addextendedproperty @name = N'DM_RecordType',
    @value = N'[dbo].[ttUserWithCompositeRoleDetail]',
    @level0type = N'SCHEMA',
    @level0name = N'dbo',
    @level1type = N'FUNCTION',
    @level1name = N'GetUsersWithCompositeRolesFromUserNames',
    @level2type = NULL,
    @level2name = NULL
