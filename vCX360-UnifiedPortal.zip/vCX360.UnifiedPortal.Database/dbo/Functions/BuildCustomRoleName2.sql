﻿CREATE FUNCTION [dbo].[BuildCustomRoleName2]
(
	@coId int,
	@buId int,
	@featureId int,
	@featurePartId int,
	@roleId int,
	@applicatioId Int
)
RETURNS varchar(100)
AS
BEGIN
	RETURN 
		(select top 1
			coalesce((select top(1) 'App:' + app.[CID]), '') + '~'+ --as application,
			coalesce((select top(1) 'CO:' + c.Cid), '') + '~' + --as Company,
			coalesce((select top(1) 'BU:' + b.Cid), '') + '~'+ --as BusinessUnit,
			--coalesce((select top(1) 'Suite:' + s.[CID]), '') + '~'+ --as Suite,			
			coalesce((select top(1) f.Cid), '') + '~' + --as Feature,
			coalesce((select top(1) r.[Name]), '') --as [Role]

		from 
		adm.[Application] app 
		Join adm.Suite s on app.SuiteId = s.Id
		Left join adm.CompanyBusinessUnitAppMap cba on cba.ApplicationId = app.Id 
		Left Join adm.Company c on c.Id = cba.CompanyId and c.Id = @coId
		left join adm.BusinessUnit b on b.CompanyId = c.Id and b.Id = @buId
		left join sec.Feature f on f.Id = @featureId
		left join dbo.[Role] r on r.id = dbo.GetPermissionRoleForCustomRole(@roleId)
		where 
			c.Id = @coId and app.Id = @applicatioId
		);
END
