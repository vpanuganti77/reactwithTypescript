﻿CREATE SEQUENCE [dbo].[EntityAuditIdSeq] --not used at this time; for the new table
		AS BIGINT
		START WITH 1
		INCREMENT BY 1
		NO MAXVALUE
		NO CYCLE
		CACHE 50
