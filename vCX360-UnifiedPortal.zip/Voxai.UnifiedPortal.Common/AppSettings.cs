﻿

namespace Voxai.UnifiedPortal;
/// <summary>
/// Represents the application settings for configuration purposes.
/// </summary>
public class AppSettings
{
    /// <summary>
    /// Gets or sets the package used for validation purposes.
    /// </summary>
    public required string Validate_Package { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether local encryption should be used.
    /// </summary>
    public bool UseLocalEncryption { get; set; }

    /// <summary>
    /// Gets or sets the secret key used for generating and validating JSON Web Tokens (JWT).
    /// </summary>
    public required string JWTSecret { get; set; }

    /// <summary>
    /// Gets or sets the expiry time for JWT tokens in minutes.
    /// </summary>
    public int JWTokenExpiryTimeInMins { get; set; }

    /// <summary>
    /// Gets or sets the intended audience for the JWT tokens.
    /// </summary>
    public required string JWTValidAudience { get; set; }

    /// <summary>
    /// Gets or sets the issuer of the JWT tokens.
    /// </summary>
    public required string JWTValidIssuer { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether the Swagger UI for API documentation is enabled.
    /// </summary>
    public bool EnableSwaggerPage { get; set; } = false;

    /// <summary>
    /// Gets or sets the file path for the identity directory, where user data might be stored.
    /// </summary>
    public required string IdentityDirectoryPath { get; set; }

    /// <summary>
    /// Gets or sets the file name for the identity File, where user tenant data might be stored.
    /// </summary>
    public required string IdentityFile { get; set; }

    /// <summary>
    /// Gets or sets the expiry time for Internal Cache in minutes.
    /// </summary>
    public required int DefaultCacheExpirationInMinute { get; set; }
}

