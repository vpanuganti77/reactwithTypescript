﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Voxai.UnifiedPortal.Services
{
    public static class CoreControllerHostingExtensions
    {
        /// <summary>
        /// Adds the <see cref="CoreControllerHostingExtensions"/> assembly to the web service.
        /// </summary>
        /// <param name="builder">The <see cref="IMvcBuilder"/> to use when building the web service.</param>
        /// <returns>The <see cref="IMvcBuilder"/> after adding the <see cref="CoreControllerHostingExtensions"/> assembly to the web service.</returns>
        public static IMvcBuilder AddCoreControllers(this IMvcBuilder builder) => builder.AddApplicationPart(typeof(CoreControllerHostingExtensions).Assembly);
    }
}
