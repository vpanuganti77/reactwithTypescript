﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voxai.UnifiedPortal.Services.Models;
using Voxai.UnifiedPortal.Services.Translators;

namespace Voxai.UnifiedPortal.Services
{
    [ApiController]
    [Route("api/[controller]")]
    public class CompaniesController : ControllerBase
    {
        // Private readonly fields to store injected dependencies
        private readonly ILogger<CompaniesController> _logger;
        private readonly ICompanyRepository _companyRepository;

        // Constructor that initializes the fields
        public CompaniesController(ILogger<CompaniesController> logger, ICompanyRepository companyRepository)
        {
            _logger = logger;  // Initialize logger field
            _companyRepository = companyRepository;  // Initialize company repository field
        }

        /// <summary>
        ///  Retrieves all <see cref="Company"/> from the underlying database.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ActionResult<IAsyncEnumerable<CompanyRequest>>> GetAll(int? id)
        {
            try
            {
                var company = await _companyRepository.GetItems(id.HasValue ? new[] { id.Value } : Enumerable.Empty<int>());
                return Ok(company.ToService());
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        /// <summary>
        /// Adds a <see cref="Company"/> to the UnifiedPortal.
        /// </summary>
        /// <param name="company">The <see cref="Company"/> to add.</param>
        /// <returns>The <see cref="int"/> ID for the new <see cref="Company"/>.</returns>
        [HttpPost]
        public async Task<ActionResult<CompanyRequest>> AddAsync([FromBody] CompanyRequest company)
        {
            var result = await _companyRepository.AddItem(company.ToDomain());
            return Ok(result.ToService());
        }


        /// <summary>
        /// Updates a <see cref="Company"/> to the UnifiedPortal.
        /// </summary>
        /// <param name="company">The <see cref="Company"/> to update.</param>
        /// <returns>The <see cref="int"/> ID for the new <see cref="Company"/>.</returns>
        [HttpPut]
        public async Task<ActionResult<CompanyRequest>> UpdateAsync([FromBody] CompanyRequest company)
        {
            var result = await _companyRepository.UpdateItem(company.ToDomain());
            return Ok(result.ToService());
        }

        /// <summary>
        /// Delete a <see cref="Company"/> from the UnifiedPortal.
        /// </summary>
        /// <param name="company">The <see cref="Company"/> to add.</param>
        /// <returns>The <see cref="int"/> ID for the new <see cref="Company"/>.</returns>
        [HttpDelete]
        public async Task<ActionResult<int>> DeleteAsync(int id)
        {
            var result = await _companyRepository.DeleteItems(new[] {id});
            return Ok(result);
        }
    }
}
