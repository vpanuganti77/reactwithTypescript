using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;
using Voxai.UnifiedPortal;
using Voxai.UnifiedPortal.DataAccess;
using Voxai.UnifiedPortal.Repositories;
using static Common.Util.Crypto.CryptoUtil;
using Voxai.UnifiedPortal.Services;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("DatabaseConnection");
bool IsSecurityEnabled = Convert.ToBoolean(builder.Configuration.GetSection("AppSettings:IsSecurityEnabled").Value);

// Add services to the container.
builder.Services.AddControllers();

// Specified in AppSettings
var appSettings = builder.Configuration.GetSection("AppSettings").Get<AppSettings>();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer("Bearer", options =>
{
    options.Audience = appSettings.JWTValidAudience;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = appSettings.JWTValidIssuer,
        ValidAudience = appSettings.JWTValidAudience,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Decrypt(appSettings.JWTSecret, appSettings.UseLocalEncryption)))
    };
});

// Add dependency injection and other services
builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
builder.Services.AddSingleton<IDbConnectionFactory>(new SqlConnectionFactory(connectionString));
//builder.Services.AddScoped<IReadWriteRepository<Company>, BaseRepository<Company>>();
builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
if (IsSecurityEnabled)
{
        builder.Services.AddControllers(options =>
    {
        options.Filters.Add(new AuthorizeAttribute(appSettings));// Add the global Authorize filter
    })
    .AddCoreControllers();
}
else
{
    builder.Services.AddControllers();
}

builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });
    foreach (var file in Directory.GetFiles(AppContext.BaseDirectory, "Voxai.*.xml"))
    {
        o.IncludeXmlComments(file, true);
    }

    // Define the JWT Bearer security scheme
    o.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Enter 'Bearer' [space] and then your valid token in the text input below.\r\n\r\nExample: \"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\"",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });
    // Add security requirement
    o.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                        }
                    },
                    new string[] {}
                }
            });


});

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseAuthentication();
app.UseAuthorization();
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
    c.RoutePrefix = string.Empty;
});

app.MapControllers();

app.Run();

public class TimeSpanConverter : JsonConverter<TimeSpan>
{
    public override TimeSpan Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.String)
        {
            return TimeSpan.Parse(reader.GetString());
        }
        throw new JsonException();
    }

    public override void Write(Utf8JsonWriter writer, TimeSpan value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(value.ToString("c")); // "c" format specifier for "hh:mm:ss" format
    }
}