﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Voxai.UnifiedPortal.Repositories
{
    //public abstract class UtilBase
    //{

    //    private static readonly Dictionary<Type, string> _spMappingsForCreate = new Dictionary<Type, string>
    //    {
    //        { typeof(Company), "adm.spAddOrUpdateCompany" },             // Example mapping
    //        // Add more type-to-function mappings as needed
    //    };
    //    private static readonly Dictionary<Type, string> _spMappingsForUpdate = new Dictionary<Type, string>
    //    {
    //        { typeof(Company), "adm.spAddOrUpdateCompany" },             // Example mapping
    //        // Add more type-to-function mappings as needed
    //    };
    //    private static readonly Dictionary<Type, string> _spMappingsForDelete = new Dictionary<Type, string>
    //    {
    //        { typeof(Company), "adm.spDeleteCompanies" },             // Example mapping
    //        // Add more type-to-function mappings as needed
    //    };


    //    private static readonly Dictionary<Type, string> _functionMappings = new Dictionary<Type, string>
    //{
    //    { typeof(Company), "adm.GetCompaniesWithBusinessUnitsDetails" },             // Example mapping
    //    // Add more type-to-function mappings as needed
    //};

    //    public static string GetFunctionName<T>()
    //    {
    //        _functionMappings.TryGetValue(typeof(T), out var functionName);
    //        return functionName;
    //    }

    //    public static string GetSPName<T>(Action action)
    //    {
    //        if (action == Action.Create)
    //        {
    //            _spMappingsForCreate.TryGetValue(typeof(T), out var spName);
    //            return spName;
    //        };
    //        if (action == Action.Update)
    //        {
    //            _spMappingsForUpdate.TryGetValue(typeof(T), out var spName);
    //            return spName;
    //        }
    //        else
    //        {
    //            _spMappingsForDelete.TryGetValue(typeof(T), out var spName);
    //            return spName;
    //        };

    //    }



    //}

    public enum Action
    {
        Get,
        Create,
        Update,
        Delete
    }
}
