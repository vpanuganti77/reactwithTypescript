﻿using Dapper;
using System.Data;

namespace Voxai.UnifiedPortal.Repositories
{
    public static class DapperExtensions
    {
        private static int connectiontimeOut;
        //private static IConfiguration configuration;

        //static DapperExtensions()
        //{

        //    configuration = new ConfigurationBuilder()
        //        .SetBasePath(Directory.GetCurrentDirectory())
        //        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
        //        .Build();
        //    connectiontimeOut = int.Parse(configuration.GetValue<string>("connectionTimeOut", "30"));

        //}

        public static DataTable ConvertToDataTable<T>(T item)
        {
            var table = new DataTable();

            // Use reflection to get all the properties of the object
            var properties = typeof(T).GetProperties();

            // Add columns to the DataTable based on the properties of T
            foreach (var property in properties)
            {
                table.Columns.Add(property.Name, Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType);
            }

            // Create a DataRow for the given item and populate it with values from the item
            var row = table.NewRow();
            foreach (var property in properties)
            {
                var value = property.GetValue(item);
                row[property.Name] = value;  // Handle null values
            }

            // Add the row to the DataTable
            table.Rows.Add(row);

            return table;
        }

        public static void AddTableParameter<T>(this DynamicParameters parameters, string name, string ttTypeName, IEnumerable<T> items)
        {
            var dataTable = new DataTable();
            var properties = typeof(T).GetProperties();
            // Create columns in the DataTable based on the properties of T
            foreach (var prop in properties)
            {

                var type = prop.PropertyType;

                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type)!;

                dataTable.Columns.Add(prop.Name, type);
            }
            // Add rows to the DataTable
            foreach (var item in items)
            {

                var row = dataTable.NewRow();
                foreach (var prop in properties)
                {
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                }
                dataTable.Rows.Add(row);
            }

            // Add the DataTable as a parameter
            parameters.Add(name, dataTable.AsTableValuedParameter(ttTypeName));
        }
        public static async Task<IEnumerable<T>> ExecuteSP<T>(this IDbConnection connection, string spName, DynamicParameters parameters)
        {
            try
            {
                var taskResults = await connection.QueryAsync<T>(spName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: connectiontimeOut);
                return taskResults;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// use this to return single value
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="spName"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static async Task<int> ExecuteScalarSP(this IDbConnection connection, string spName, DynamicParameters parameters)
        {
            try
            {
                var taskResults = connection.ExecuteScalar<int>(spName, parameters, commandType: CommandType.StoredProcedure);
                return taskResults;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
