﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Voxai.UnifiedPortal.DataAccess;

namespace Voxai.UnifiedPortal.Repositories
{
    public class CompanyRepository : BaseRepository<Company>, ICompanyRepository, IDbQueryItem
    {
        public CompanyRepository(IDbConnectionFactory connectionFactory)
            : base(connectionFactory)
        {
        }

        // GetItems with optional ids parameter
        public Func<DbQueryItem> GetItems(IEnumerable<int> ids = null)
        {
            return () => new DbQueryItem
            {
                SPName = null,  // Set the stored procedure name
                FunctionName = "adm.GetCompaniesWithBusinessUnitsDetails",  // Set the function name if needed
                DynamicParamters = TableParametersForGetItem(ids)
            };
        }

        // AddItem with generic type T and item parameter
        public Func<DbQueryItem> AddItem<T>(T item)
        {
            return () => new DbQueryItem
            {
                SPName = "adm.spAddOrUpdateCompany",  // Set the stored procedure name
                FunctionName = null,  // Set the function name if needed
                DynamicParamters = GetDynamicParametersForAddEdit(item)
            };
        }

        // UpdateItem with generic type T and item parameter
        public Func<DbQueryItem> UpdateItem<T>(T item)
        {
            return () => new DbQueryItem
            {
                SPName = "adm.spAddOrUpdateCompany",  // Set the stored procedure name
                FunctionName = null,  // Set the function name if needed
                DynamicParamters = GetDynamicParametersForAddEdit(item)
            };
        }

        // DeleteItems with optional ids parameter
        public Func<DbQueryItem> DeleteItems(IEnumerable<int> ids = null)
        {
            return () => new DbQueryItem
            {
                SPName = "adm.spDeleteCompanies",  // Set the stored procedure name
                FunctionName = "DeleteCompanyFunction",  // Set the function name if needed
                DynamicParamters = TableParametersForGetItem(ids)
            };
        }

        // GetTableParameters method that returns the appropriate function based on the action
        public override DbQueryItem GetDbQueryItem(Action action, Company item, IEnumerable<int> ids)
        {
            Func<DbQueryItem> dbQueryItemFunc = action switch
            {
                Action.Get => GetItems(ids),
                Action.Create => AddItem(item),
                Action.Update => UpdateItem(item),
                Action.Delete => DeleteItems(ids),
                _ => throw new ArgumentException("Invalid action type", nameof(action))
            };

            return dbQueryItemFunc();  // Execute the function and get the DbQueryItem
        }

        // Helper method to get DynamicParameters for Add/Edit actions
        internal DynamicParameters GetDynamicParametersForAddEdit<T>(T item)
        {
            var parameters = new DynamicParameters();

            // Convert the item (Company in this case) to a TVP-compatible format
            var companyObj = ToTTCompany(item as Company);

            // Add the DataTable as a TVP parameter
            parameters.AddTableParameter("@ttCompany", "[adm].[ttCompany]", companyObj);
            parameters.Add("@userName", (item as Company)?.CreatedBy);

            return parameters;
        }

        // Converts a Company object to a list of TTCompany for the TVP
        private List<TTCompany> ToTTCompany(Company item)
        {
            return new List<TTCompany>
            {
                new TTCompany
                {
                    Id = item.Id,
                    CID = item.CID,
                    Name = item.Name,
                    Status = item.Status,
                    Description = item.Description,
                    Domain = item.Domain,
                    TenantId = item.TenantId,
                    OrgId = item.OrgId,
                    IsDeleted = item.IsDeleted,
                    IntegrationType = item.IntegrationType,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate
                }
            };
        }
    }
}
