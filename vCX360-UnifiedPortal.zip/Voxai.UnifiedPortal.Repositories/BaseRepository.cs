﻿using System.Data;
using Voxai.UnifiedPortal.DataAccess;
using Dapper;
using Voxai.UnifiedPortal.Domain.Models;

namespace Voxai.UnifiedPortal.Repositories
{
    public class ItemAddException : Exception
    {
        public ItemAddException(string message) : base(message) { }
        public ItemAddException(string message, Exception innerException) : base(message, innerException) { }
    }

    public abstract class BaseRepository<T> : IReadWriteRepository<T> where T : class
    {
        private readonly IDbConnectionFactory _connectionFactory;
        public BaseRepository(IDbConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        private IDbConnection Connection => _connectionFactory.CreateConnection();

        public abstract DbQueryItem GetDbQueryItem(Action action, T item, IEnumerable<int> ids = null);

        public virtual DynamicParameters TableParametersForGetItem(IEnumerable<int> ids)
        {
            // Create the DataTable to represent the table-valued parameter
            var table = new DataTable();
            table.Columns.Add("Value", typeof(int));  // This should match the TVP structure in SQL Server

            // Populate the DataTable with the IEnumerable<int> data
            if (ids != null && ids.Any())
            {
                foreach (var id in ids)
                {
                    table.Rows.Add(id);
                }
            }

            // Use DynamicParameters to add the TVP
            var parameters = new DynamicParameters();
            parameters.Add("@ids", table.AsTableValuedParameter("[dbo].[ttIntValue]")); // TVP type
            return parameters;
        }
        public virtual string QueryForGetItem(IEnumerable<int> ids = null, string functionName = null) =>"SELECT * FROM " + functionName + " (@ids)";
        public virtual string QueryForDeleteItem(IEnumerable<int> ids = null, string functionName = null) => "SELECT * FROM " + functionName + " (@ids)";
        public async Task<IEnumerable<T>> ExecuteStoredProcedure<T>(string storedProcedureName, object parameters = null)
        {
            using (var connection = Connection)
            {
                connection.Open();
                var result=  await connection.QueryAsync<T>(storedProcedureName, parameters, commandType: CommandType.StoredProcedure);
                return result.ToList();
            }
        }


        public async Task<IEnumerable<T>> ExecuteFunction<T>(string query, object parameters = null)
        {
            using (var connection = Connection)
            {
                connection.Open();
                return await connection.QueryAsync<T>(query, parameters, commandType: CommandType.Text);
            }
        }

        public async Task<IEnumerable<T>> GetItems(IEnumerable<int> ids)
        {
            using (var connection = Connection)
            {
                connection.Open();

                // Call the stored procedure or function with the TVP


                // Get the function or stored procedure name dynamically
                var dbQueryItem = GetDbQueryItem(Action.Get, null, ids); // Get Queryparams

                // Execute the query
                try
                {
                    var result = await ExecuteFunction<T>(QueryForGetItem(ids, dbQueryItem.FunctionName), dbQueryItem.DynamicParamters);
                    return result;
                }
                catch (Exception ex)
                {
                    // Log the exception message (optional)
                    Console.WriteLine($"Error occurred while fetching items: {ex.Message}");

                    // Throw custom exception with inner exception
                    throw new ItemAddException("Failed to fetch items. See inner exception for details.", ex);
                }

            }
        }

        Task<T> IReadWriteRepository<T>.GetItem(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<T> AddItem(T item) 
        {
            using (var connection = Connection)
            {
                connection.Open();

                // Get the function or stored procedure name dynamically
                var dbQueryItem = GetDbQueryItem(Action.Create, item); // Get Queryparams

           
                // Execute the query (insert operation)
                try
                {
                    var result = await ExecuteStoredProcedure<T>(dbQueryItem.SPName, dbQueryItem.DynamicParamters);
                    dynamic obj = result.FirstOrDefault();
                    int id = obj?.Id;
                    var itemResult = await GetItems(new[] { id });
                    return itemResult.Single();

                }catch (Exception ex)
                {
                    // Log the exception message (optional)
                    Console.WriteLine($"Error occurred while adding item: {ex.Message}");

                    // Throw custom exception with inner exception
                    throw new ItemAddException("Failed to add the item. See inner exception for details.", ex);
                }
     
            }
        }


        public async Task<T> UpdateItem(T item)
        {
            using (var connection = Connection)
            {
                connection.Open();

                // Get the function or stored procedure name dynamically
                var dbQueryItem = GetDbQueryItem(Action.Update, item); // Get Queryparams

                // Execute the query (insert operation)
                try
                {
                    var result = await ExecuteStoredProcedure<T>(dbQueryItem.SPName, dbQueryItem.DynamicParamters);
                    dynamic obj = result.FirstOrDefault();
                    int id = obj?.Id;
                    var itemResult = await GetItems(new[] { id });
                    return itemResult.Single();
                }
                catch (Exception ex)
                {
                    // Log the exception message (optional)
                    Console.WriteLine($"Error occurred while updating item: {ex.Message}");

                    // Throw custom exception with inner exception
                    throw new ItemAddException("Failed to update the item. See inner exception for details.", ex);
                }

            }
        }

        public async Task<IEnumerable<int>> DeleteItems(IEnumerable<int> ids)
        {
            using (var connection = Connection)
            {
                connection.Open();

                // Get the function or stored procedure name dynamically
                var dbQueryItem = GetDbQueryItem(Action.Delete, null, ids); // Get Queryparams

                // Execute the query (insert operation)
                try
                {
                    var result = await ExecuteStoredProcedure<int>(QueryForDeleteItem(ids, dbQueryItem.FunctionName), dbQueryItem.DynamicParamters);
                    return result;
                }
                catch (Exception ex)
                {
                    // Log the exception message (optional)
                    Console.WriteLine($"Error occurred while deleting item: {ex.Message}");

                    // Throw custom exception with inner exception
                    throw new ItemAddException("Failed to delete the item. See inner exception for details.", ex);
                }
            }
        }

    }

}
