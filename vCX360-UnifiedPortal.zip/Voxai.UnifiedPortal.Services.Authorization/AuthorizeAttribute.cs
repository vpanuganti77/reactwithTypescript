﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.IdentityModel.Tokens.Jwt;

namespace Voxai.UnifiedPortal.Services;
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class AuthorizeAttribute : Attribute, IAuthorizationFilter
{

    private readonly AppSettings appSettingsObj;

    public AuthorizeAttribute(AppSettings appSettings)
    {

        appSettingsObj = appSettings;
    }
    public void OnAuthorization(AuthorizationFilterContext context)
    {

        var user = context.HttpContext.User;
        var token = context.HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
        if (IsTokenExpired(token) && !string.IsNullOrEmpty(token))
        {
            // Return a custom message for token expiration
            context.Result = new ObjectResult(new { title = "Token has expired", status = "498" })
            {
                StatusCode = 498 // Set the status code to 498 for token expiration
            };

        }

        else
        {
            if (user != null && user?.Identity?.IsAuthenticated == false)
                context.Result = new UnauthorizedResult();
        }

        Thread.CurrentPrincipal = user;

    }

    private bool IsTokenExpired(string token)
    {
        var handler = new JwtSecurityTokenHandler();
        try
        {
            var jwtToken = handler.ReadToken(token) as JwtSecurityToken;
            if (jwtToken == null)
                throw new Exception("Invalid JWT token");

            var expClaim = jwtToken?.Claims.FirstOrDefault(c => c.Type == "exp")?.Value;
            if (expClaim == null)
                throw new Exception("Expiration claim not found");

            var expUnix = long.Parse(expClaim);
            var expirationTime = DateTimeOffset.FromUnixTimeSeconds(expUnix).UtcDateTime;

            return expirationTime < DateTime.UtcNow; // Return true if expired
        }
        catch (Exception)
        {
            return true; // If any error occurs, assume the token is expired
        }
    }
}

