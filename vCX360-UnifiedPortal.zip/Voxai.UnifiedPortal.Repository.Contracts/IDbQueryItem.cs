﻿using Dapper;

namespace Voxai.UnifiedPortal
{
    public interface IDbQueryItem
    {
        public Func<DbQueryItem> GetItems(IEnumerable<int> ids=null);
        public Func<DbQueryItem> AddItem<T>(T Item);
        public Func<DbQueryItem> UpdateItem<T>(T Item);
        public Func<DbQueryItem> DeleteItems(IEnumerable<int> ids = null);
    }

    public class DbQueryItem
    {
        public string SPName { get; set; }
        public string FunctionName { get; set; }
        public DynamicParameters DynamicParamters { get; set; }
    }
}
