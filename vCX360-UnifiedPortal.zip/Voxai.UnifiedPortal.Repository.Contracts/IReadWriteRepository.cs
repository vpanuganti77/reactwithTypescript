﻿

namespace Voxai.UnifiedPortal
{
    public interface IReadWriteRepository<T> where T: class
    {
        Task<IEnumerable<T>> GetItems(IEnumerable<int> ids = null);
        Task<T> GetItem(int id);
        Task<T> AddItem(T entity);
        Task<T> UpdateItem(T entity);
        Task<IEnumerable<int>> DeleteItems(IEnumerable<int> ids);
    }
}
