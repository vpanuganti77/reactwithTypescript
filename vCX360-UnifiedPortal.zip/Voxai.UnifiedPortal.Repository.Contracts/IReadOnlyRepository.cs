﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Voxai.UnifiedPortal
{
    public interface IReadOnlyRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetItems(IEnumerable<int> ids = null);
        Task<T> GetItem(int id);
    }
}
