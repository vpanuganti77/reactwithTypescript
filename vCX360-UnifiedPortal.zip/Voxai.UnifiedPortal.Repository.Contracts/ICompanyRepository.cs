﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Voxai.UnifiedPortal.Services.Models;

namespace Voxai.UnifiedPortal
{
    /// <summary>
    /// Represents a specialized repository for the <see cref="Company"/> entity.
    /// </summary>
    public interface ICompanyRepository : IReadWriteRepository<Company>
    {
    }
}
