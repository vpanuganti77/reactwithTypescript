﻿using System.Security.Cryptography;
using System.Xml.Linq;
using Voxai.UnifiedPortal.Domain.Models;
using Voxai.UnifiedPortal.Services.Models;

namespace Voxai.UnifiedPortal.Services.Translators
{
    public static class ComapnyTranslator
    {
        #region Domain
        public static Company ToDomain(this CompanyRequest x)
        {
            return new Company
            {
                Id = x.Id,
                CID = x.Cid,
                Name = x.Name,
                Status = x.Status,
                Description = x.Desc,
                Domain = x.Domain,
                TenantId = x.TenantId,
                OrgId = x.OrgId,
                IsDeleted = x.IsDeleted,
                IntegrationType = x.IntegrationType,
                CreatedBy = x.CreatedBy,
                CreatedDate = x.CreatedDate,
                UpdatedBy = x.ModifiedBy,
                UpdatedDate = x.ModifiedDate
            };
        }

        #endregion

        #region Service

        public static IEnumerable<CompanyRequest> ToService(this IEnumerable<Company> items)
        {
            return items.Select(x => new CompanyRequest
            {
                Id = x.CompanyId,
                Name = x.CompanyName,
                Desc = x.CompanyDescription,
                Domain = x.Domain,
                IsDeleted = x.IsDeleted,
                TenantId = x.TenantId,
                OrgId= x.OrgId,
                IntegrationType = x.IntegrationType,
                CreatedBy  = x.CompanyCreatedBy,
                CreatedDate = x.CompanyCreatedDate,
                ModifiedBy = x.CompanyUpdatedBy,
                ModifiedDate = (DateTime)x.CompanyUpdatedDate
            });
        }

        public static CompanyRequest ToService(this Company x)
        {
            return new CompanyRequest
            {
                Id = x.CompanyId,
                Name = x.CompanyName,
                Desc = x.CompanyDescription,
                Domain = x.Domain,
                IsDeleted = x.IsDeleted,
                TenantId = x.TenantId,
                OrgId = x.OrgId,
                IntegrationType = x.IntegrationType,
                CreatedBy = x.CompanyCreatedBy,
                CreatedDate = x.CompanyCreatedDate,
                ModifiedBy = x.CompanyUpdatedBy,
                ModifiedDate = x.CompanyUpdatedDate
            };
        }

        #endregion
    }
}
